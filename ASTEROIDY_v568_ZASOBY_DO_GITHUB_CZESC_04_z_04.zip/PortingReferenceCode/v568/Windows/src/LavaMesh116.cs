using System;
using System.Collections.Generic;
using System.Drawing;
using P=Asteroidy.PlanetMesh.P;
namespace Asteroidy {
 // Independent immutable volcanic mesh, built ONCE on the unchanged planet.
 // Broad irregular bodies follow the heightfield; fractured rafts are real triangles.
 sealed class LavaMesh116 {
  readonly PlanetMesh ground;
  readonly List<float> data=new List<float>(420000);
  readonly List<int>[] terrainBins=new List<int>[180*360];
    const float PI=3.14159265358979323846f;
  static readonly Color crust=Color.FromArgb(33,30,29),warm=Color.FromArgb(100,43,29),hot=Color.FromArgb(228,101,33);
  public readonly float[] Vertices;
    public int Triangles {get{return Vertices.Length/30;}}
  public int Count {get{return Vertices.Length/10;}}
  public LavaMesh116(PlanetMesh mesh){
   ground=mesh;
   if(mesh.Basalt110){
    IndexTerrain();
    for(int i=0;i<PlanetMesh.BasaltVents114.Length;i++){
     P vent=PlanetMesh.BasaltVents114[i];
     if(mesh.OrbitAtlas242)UnifiedLava252(i,vent);
     else {
      Caldera(i,vent);
      int branches=i==1?2:1;
      for(int k=0;k<branches;k++)River(i,k,vent);
     }
    }
   }
   Vertices=data.ToArray();data.Clear();
  }
  static float Clamp(float x,float a,float b){return Math.Max(a,Math.Min(b,x));}
  static float Dot(P a,P b){return a.X*b.X+a.Y*b.Y+a.Z*b.Z;}
  static P Cross(P a,P b){return new P(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);}
  static P Tangent(P n,P f){return (f-n*Dot(f,n)).Unit;}
  static P Turn(P dir,P side,float angle){return dir*(float)Math.Cos(angle)+side*(float)Math.Sin(angle);}
  static float Smooth(float t){t=Clamp(t,0,1);return t*t*(3-2*t);}
  static int Lat(P n){return Math.Max(0,Math.Min(179,(int)((Math.Asin(Clamp(n.Y,-1,1))/PI+.5)*180)));}
  static int Lon(P n){int v=(int)((Math.Atan2(n.Z,n.X)/(2*PI)+.5)*360);return ((v%360)+360)%360;}
  P TerrainVertex(int index){float[] a=ground.Vertices;int i=index*10;return new P(a[i],a[i+1],a[i+2]);}
  void IndexTerrain(){
   // Spatial lookup for the ACTUALLY RENDERED triangles, rather than analytic noise alone.
   // This avoids saw-tooth intersections when lava crosses the triangulated ground.
   for(int tri=0;tri<ground.TerrainVertices/3;tri++){
    P a=TerrainVertex(tri*3),b=TerrainVertex(tri*3+1),c=TerrainVertex(tri*3+2);
    P n=(a+b+c).Unit;int bin=Lat(n)*360+Lon(n);
    if(terrainBins[bin]==null)terrainBins[bin]=new List<int>(6);
    terrainBins[bin].Add(tri);
   }
  }
  float RenderHeight(P n){
   int lat=Lat(n),lon=Lon(n);float[] v=ground.Vertices;
   for(int oy=-2;oy<=2;oy++)for(int ox=-2;ox<=2;ox++){
    int y=lat+oy;if(y<0||y>=180)continue;int x=(lon+ox+360)%360;
    List<int> group=terrainBins[y*360+x];if(group==null)continue;
    foreach(int triangle in group){
     int idx=triangle*30;
     P a=new P(v[idx],v[idx+1],v[idx+2]);
     P b=new P(v[idx+10],v[idx+11],v[idx+12]);
     P c=new P(v[idx+20],v[idx+21],v[idx+22]);
     P normal=Cross(b-a,c-a);float denom=Dot(normal,n);
     if(Math.Abs(denom)<.00000001f)continue;
     float radius=Dot(normal,a)/denom;
     if(radius<.88f||radius>1.40f)continue;
     P point=n*radius;
     float side0=Dot(Cross(b-a,point-a),normal),side1=Dot(Cross(c-b,point-b),normal),side2=Dot(Cross(a-c,point-c),normal);
     if(side0>=-.0000000001f&&side1>=-.0000000001f&&side2>=-.0000000001f)return radius;
    }
   }
   return ground.Height(n);
  }
  float Surface(P n,float lift){return RenderHeight(n)+lift;}
  P Lift(P n,float z){n=n.Unit;return n*Surface(n,z);}
  void V(P p,P normal,Color c){data.Add(p.X);data.Add(p.Y);data.Add(p.Z);data.Add(normal.X);data.Add(normal.Y);data.Add(normal.Z);data.Add(c.R/255f);data.Add(c.G/255f);data.Add(c.B/255f);data.Add(1);}
  void Tri(P a,P b,P c,Color ca,Color cb,Color cc){
   P n=Cross(b-a,c-a).Unit;
   if(Dot(n,a+b+c)<0){P sw=b;b=c;c=sw;Color sc=cb;cb=cc;cc=sc;n=n*-1;}
   V(a,n,ca);V(b,n,cb);V(c,n,cc);
  }
  void Quad(P a,P b,P c,P d,Color aC,Color bC){Tri(a,b,c,aC,aC,bC);Tri(a,c,d,aC,bC,bC);}
  P Foot(P center,P right,float dx,float dy){return (center+right*dx+center.Unit*dy).Unit;}
  void Caldera(int index,P vent){
   P east=Cross(vent,Math.Abs(vent.Y)<.91f?new P(0,1,0):new P(1,0,0)).Unit,up=Cross(vent,east).Unit;
   const int sectors=44,rings=10;
   P[] previous=null;float radius=.084f+(index==1?.012f:.006f);
   for(int ring=0;ring<=rings;ring++){
    float progress=ring/(float)rings;float r=radius*progress;P[] current=new P[sectors];
    for(int k=0;k<sectors;k++){
     float a=2*PI*k/sectors;
     float irregular=1+.18f*(float)Math.Sin(a*3.0f+index*1.7f)+.09f*(float)Math.Sin(a*7.0f+index*.9f)+.05f*(float)Math.Sin(a*13.0f+index*2.3f);
     P n=(vent+(east*(float)Math.Cos(a)+up*(float)Math.Sin(a))*r*irregular).Unit;
     float lift=.0045f+.0015f*(1f-progress);
     current[k]=Lift(n,lift);
    }
    if(previous!=null)for(int k=0;k<sectors;k++){
     int j=(k+1)%sectors;
     Color c=progress<.34f?hot:progress<.62f?warm:crust;
     Quad(previous[k],previous[j],current[j],current[k],c,c);
    }
    previous=current;
   }
   // Larger crater lakes with dark plates concentrated mostly near the outer basin.
   for(int island=0;island<16;island++){
    float a=(island*2.3999632f+index*.7f),r=radius*(.42f+.42f*((island*11)%19)/19f);
    P center=(vent+(east*(float)Math.Cos(a)+up*(float)Math.Sin(a))*r).Unit;
    float size=.0040f+.0028f*(island%4),orientation=island*.81f;
    P tangent=Cross(center,new P(0,1,0)).Unit;if(tangent.Length<.001f)tangent=new P(1,0,0);P other=Cross(center,tangent).Unit;
    P last=new P(),tip=Lift(center,.0068f);
    for(int j=0;j<=8;j++){
     float angle=orientation+j*2*PI/8;
     P d=(center+(tangent*(float)Math.Cos(angle)+other*(float)Math.Sin(angle))*size*(.74f+.22f*(float)Math.Sin(j*2.2f+island))).Unit;
     P edge=Lift(d,.0062f);
     if(j>0)Tri(tip,last,edge,crust,crust,crust);
     last=edge;
    }
   }
  }

  // v246: orbital-world lava is a spreading sheet, not a fixed-width tube.
  // Both banks have separate widths, occasional bottlenecks, side overflow
  // basins and a thin relief-following edge. Combat lava retains its old mesh.
  static float Peak246(float t,float center,float spread){float d=(t-center)/spread;return (float)Math.Exp(-d*d);}
  static float Peak250(float t,float center,float spread){float d=(t-center)/spread;return (float)Math.Exp(-d*d);}
  static void Project246(P east,P up,P p,out float x,out float y){x=Dot(p,east);y=Dot(p,up);} 
  static float FlowField250(float px,float py,float cx,float cy,float tx,float ty,float halfLen,float left,float right){
   float dx=px-cx,dy=py-cy;
   float u=dx*tx+dy*ty;
   float v=-dx*ty+dy*tx;
   float lane=v<0?left:right;
   lane=Math.Max(.0015f,lane);
   float along=Math.Abs(u)/Math.Max(.0015f,halfLen);
   float across=Math.Abs(v)/lane;
   return 1f-(along*along+across*across);
  }
  static P Patch250(P vent,P east,P up,float x,float y){return (vent+east*x+up*y).Unit;}
  static float Width246(float t,bool left,int vent,int branch){
   float seed=vent*1.71f+branch*2.23f;
   float baseWidth=.0125f+.024f*Smooth(t)+.013f*Smooth((t-.68f)/.32f);
   float basins=.030f*Peak246(t,.24f+branch*.040f,.10f)+.036f*Peak246(t,.59f+vent*.03f,.13f)+.032f*Peak246(t,.84f-branch*.02f,.10f);
   float shore=(left?1f:-1f);
   float irregular=.96f+.22f*(float)Math.Sin(t*17.2f+seed+shore*1.5f)+.12f*(float)Math.Sin(t*37.3f+seed*.64f-shore*.7f)+.06f*(float)Math.Sin(t*73.0f+seed*1.4f+shore*.9f);
   float spread=(baseWidth+basins*(left?1.16f:.84f))*irregular;
   return Math.Max(.0058f,spread);
  }
  void Pool246(P center,P flow,float length,float span,int seed){
   center=center.Unit;flow=Tangent(center,flow);
   P cross=Cross(center,flow).Unit;
   const int rings=9,sides=52;
   P[] prev=null;Color[] prevColors=null;
   for(int i=0;i<=rings;i++){
    float t=i/(float)rings;
    P[] cur=new P[sides];Color[] cols=new Color[sides];
    for(int j=0;j<sides;j++){
     float a=j*2f*PI/sides;
     float coast=1f+.19f*(float)Math.Sin(a*3f+seed*1.13f)
                     +.095f*(float)Math.Sin(a*9f+seed*.79f)
                     +.045f*(float)Math.Sin(a*17f+seed*.53f);
     float wave=t*coast;
     P n=(center+flow*((float)Math.Cos(a)*length*wave)+cross*((float)Math.Sin(a)*span*wave)).Unit;
     float lift=.00115f+.0046f*(1f-t*t)+.0012f*(float)Math.Sin(a*4.2f+seed+t*8.1f)*(1f-t);
     cur[j]=Lift(n,Math.Max(.0010f,lift));
     float mottled=(float)Math.Sin(a*8.3f+t*18f+seed)*.11f;
     float cold=Smooth((t-.69f)/.31f);
     float hotRegion=1f-Smooth((t-.38f)/.55f);
     Color inner=Color.FromArgb(245,116+(int)(42*hotRegion),33);
     Color brown=Color.FromArgb(128,46,28);
     Color edge=Color.FromArgb(39,31,29);
     cols[j]=Mix246(inner,brown,Clamp(cold*.63f+mottled*.16f,0f,.85f));
     cols[j]=Mix246(cols[j],edge,cold*.86f);
    }
    if(prev!=null)for(int j=0;j<sides;j++){
     int next=(j+1)%sides;
     Tri(prev[j],cur[j],cur[next],prevColors[j],cols[j],cols[next]);
     Tri(prev[j],cur[next],prev[next],prevColors[j],cols[next],prevColors[next]);
    }
    prev=cur;prevColors=cols;
   }
  }
  static Color Mix246(Color a,Color b,float t){t=Smooth(t);return Color.FromArgb((int)(a.R+(b.R-a.R)*t),(int)(a.G+(b.G-a.G)*t),(int)(a.B+(b.B-a.B)*t));}
  public int OrbitalOverflowPools246{get;private set;}
  public float MinimumBankWidth246{get;private set;}
  public float MaximumBankWidth246{get;private set;}
  void River246(int volcano,int branch,P vent){
   P east=Cross(vent,Math.Abs(vent.Y)<.9f?new P(0,1,0):new P(1,0,0)).Unit,up=Cross(vent,east).Unit;
   float angle=volcano*1.53f+branch*1.34f+.38f;
   P outward=east*(float)Math.Cos(angle)+up*(float)Math.Sin(angle);
   P origin=(vent+outward*.062f).Unit;
   const int steps=40;
   P[] route=new P[steps+1],travel=new P[steps+1];
   float[] cx=new float[steps+1],cy=new float[steps+1],tx=new float[steps+1],ty=new float[steps+1],lefts=new float[steps+1],rights=new float[steps+1];
   route[0]=origin;travel[0]=Tangent(origin,outward);
   for(int i=0;i<steps;i++){
    P n=route[i],dir=travel[i],side=Cross(n,dir).Unit;
    float bestScore=-1e20f;P best=dir;
    for(int j=-4;j<=4;j++){
     float turn=j*.18f;P cand=Tangent(n,Turn(dir,side,turn));
     P next=(n+cand*.0052f).Unit;
     float loss=ground.Height(n)-ground.Height(next);
     float meander=.005f*(float)Math.Sin(i*.58f+volcano*1.3f+branch*.9f+j*.7f);
     float score=loss*176f+meander-.056f*Math.Abs(j)-.009f*j*j;
     if(score>bestScore){bestScore=score;best=cand;}
    }
    P nextPoint=(n+best*.0052f).Unit;
    travel[i+1]=Tangent(nextPoint,best*.90f+dir*.10f);
    route[i+1]=nextPoint;
   }
   float minX=999f,maxX=-999f,minY=999f,maxY=-999f;
   float minWidth=float.MaxValue,maxWidth=0f;
   for(int i=0;i<=steps;i++){
    float t=i/(float)steps;
    Project246(east,up,route[i],out cx[i],out cy[i]);
    Project246(east,up,Tangent(route[i],travel[i]),out tx[i],out ty[i]);
    float tlen=(float)Math.Sqrt(tx[i]*tx[i]+ty[i]*ty[i]);
    if(tlen<.00001f){tx[i]=1;ty[i]=0;}else{tx[i]/=tlen;ty[i]/=tlen;}
    float baseLeft=Width246(t,true,volcano,branch);
    float baseRight=Width246(t,false,volcano,branch);
    float basinBoost=.022f*Peak250(t,.22f+branch*.03f,.09f)+.028f*Peak250(t,.52f+volcano*.03f,.12f)+.036f*Peak250(t,.84f-branch*.02f,.10f);
    lefts[i]=baseLeft*1.18f+basinBoost*(1.10f+.12f*(float)Math.Sin(t*9f+branch));
    rights[i]=baseRight*1.18f+basinBoost*(.92f+.14f*(float)Math.Sin(t*8f+volcano*.7f));
    minWidth=Math.Min(minWidth,Math.Min(lefts[i],rights[i]));
    maxWidth=Math.Max(maxWidth,Math.Max(lefts[i],rights[i]));
    float reach=Math.Max(lefts[i],rights[i])+.050f;
    if(cx[i]-reach<minX)minX=cx[i]-reach;if(cx[i]+reach>maxX)maxX=cx[i]+reach;
    if(cy[i]-reach<minY)minY=cy[i]-reach;if(cy[i]+reach>maxY)maxY=cy[i]+reach;
   }
   if(MinimumBankWidth246==0||minWidth<MinimumBankWidth246)MinimumBankWidth246=minWidth;
   MaximumBankWidth246=Math.Max(MaximumBankWidth246,maxWidth);
   int[] basinIndex={8,17,28,36};
   float[] basinX=new float[basinIndex.Length+1],basinY=new float[basinIndex.Length+1],basinTX=new float[basinIndex.Length+1],basinTY=new float[basinIndex.Length+1],basinLen=new float[basinIndex.Length+1],basinSpan=new float[basinIndex.Length+1];
   for(int j=0;j<basinIndex.Length;j++){
    int i=basinIndex[j];
    float sideSign=((j+volcano+branch)&1)==0?1f:-1f;
    float bank=sideSign<0?lefts[i]:rights[i];
    float sideX=-ty[i],sideY=tx[i];
    basinX[j]=cx[i]+sideX*sideSign*bank*.52f+tx[i]*(.010f+.003f*j);
    basinY[j]=cy[i]+sideY*sideSign*bank*.52f+ty[i]*(.010f+.003f*j);
    basinTX[j]=tx[i];basinTY[j]=ty[i];
    basinLen[j]=.034f+.010f*(j%2)+.008f*Peak250(j,.5f,1.8f);
    basinSpan[j]=.028f+.013f*((j+1)%3);
    OrbitalOverflowPools246++;
   }
   basinX[basinIndex.Length]=cx[steps-3]+tx[steps-3]*.024f;
   basinY[basinIndex.Length]=cy[steps-3]+ty[steps-3]*.024f;
   basinTX[basinIndex.Length]=tx[steps-3];basinTY[basinIndex.Length]=ty[steps-3];
   basinLen[basinIndex.Length]=.060f;basinSpan[basinIndex.Length]=.050f;OrbitalOverflowPools246++;
   const int gx=56,gy=56;
   P[,] verts=new P[gx+1,gy+1];
   Color[,] cols=new Color[gx+1,gy+1];
   float[,] field=new float[gx+1,gy+1];
   for(int ix=0;ix<=gx;ix++)for(int iy=0;iy<=gy;iy++){
    float fx=ix/(float)gx,fy=iy/(float)gy;
    float x=minX+(maxX-minX)*fx,y=minY+(maxY-minY)*fy;
    float best=-999f,heat=0f,shoreNoise=.0f;
    for(int i=0;i<=steps;i++){
     float t=i/(float)steps;
     float halfLen=.015f+.010f*Peak250(t,.18f,.12f)+.014f*Peak250(t,.53f,.16f)+.020f*Peak250(t,.84f,.10f);
     float val=FlowField250(x,y,cx[i],cy[i],tx[i],ty[i],halfLen,lefts[i],rights[i]);
     if(val>best)best=val;
     if(val>-.25f){
      float dx=x-cx[i],dy=y-cy[i];
      float u=dx*tx[i]+dy*ty[i];
      float v=-dx*ty[i]+dy*tx[i];
      float lane=v<0?lefts[i]:rights[i];
      float cross=1f-Clamp(Math.Abs(v)/Math.Max(.0015f,lane),0f,1f);
      float along=1f-Clamp(Math.Abs(u)/Math.Max(.0015f,halfLen),0f,1f);
      float localHeat=(float)Math.Pow(Math.Max(0f,cross),1.35f)*(.70f+.30f*along);
      if(localHeat>heat)heat=localHeat;
      shoreNoise=Math.Max(shoreNoise,.5f+.5f*(float)Math.Sin(i*1.7f+x*210f+y*170f));
     }
    }
    for(int j=0;j<basinX.Length;j++){
     float dx=x-basinX[j],dy=y-basinY[j];
     float u=dx*basinTX[j]+dy*basinTY[j];
     float v=-dx*basinTY[j]+dy*basinTX[j];
     float val=1f-((u*u)/(basinLen[j]*basinLen[j])+(v*v)/(basinSpan[j]*basinSpan[j]));
     if(val>best)best=val;
     if(val>-.25f){
      float cross=1f-Clamp(Math.Abs(v)/Math.Max(.0015f,basinSpan[j]),0f,1f);
      float along=1f-Clamp(Math.Abs(u)/Math.Max(.0015f,basinLen[j]),0f,1f);
      heat=Math.Max(heat,(float)Math.Pow(Math.Max(0f,cross),1.30f)*(.78f+.22f*along));
      shoreNoise=Math.Max(shoreNoise,.5f+.5f*(float)Math.Sin(j*2.3f+x*150f-y*190f));
     }
    }
    field[ix,iy]=best;
    float edge=Smooth((best+.02f)/.22f);
    float body=(float)Math.Pow(Math.Max(0f,edge),1.55f);
    float glint=.00045f*body*(float)Math.Sin(x*180f+y*160f+volcano*2.1f+branch);
    verts[ix,iy]=Lift(Patch250(vent,east,up,x,y),Math.Max(.00005f,.00010f+.0062f*body+glint));
    Color cold=Color.FromArgb(31,28,28),scarlet=Color.FromArgb(164,44,18),amber=Color.FromArgb(246,118,28),yellow=Color.FromArgb(255,208,82);
    float hotMix=Clamp(heat*.90f+.10f*shoreNoise,0f,1f);
    Color shade=Mix246(cold,scarlet,Clamp(body*1.10f,0f,1f));
    shade=Mix246(shade,amber,Clamp((hotMix-.18f)*1.18f,0f,.94f));
    shade=Mix246(shade,yellow,Clamp((hotMix-.60f)*2.0f,0f,.72f));
    cols[ix,iy]=shade;
   }
   for(int ix=0;ix<gx;ix++)for(int iy=0;iy<gy;iy++){
    float f00=field[ix,iy],f10=field[ix+1,iy],f01=field[ix,iy+1],f11=field[ix+1,iy+1];
    if((f00+f10+f11)/3f>.06f)Tri(verts[ix,iy],verts[ix+1,iy],verts[ix+1,iy+1],cols[ix,iy],cols[ix+1,iy],cols[ix+1,iy+1]);
    if((f00+f11+f01)/3f>.06f)Tri(verts[ix,iy],verts[ix+1,iy+1],verts[ix,iy+1],cols[ix,iy],cols[ix+1,iy+1],cols[ix,iy+1]);
   }
   for(int island=0;island<14;island++){
    int i=5+(island*11+volcano*7+branch*5)%(steps-6);
    float sideSign=((island+branch)&1)==0?1f:-1f;
    float off=sideSign<0?lefts[i]*.18f:rights[i]*.18f;
    float sideX=-ty[i],sideY=tx[i];
    P center=Patch250(vent,east,up,cx[i]+sideX*sideSign*off,cy[i]+sideY*sideSign*off);
    P n=center.Unit,tangent=travel[i],side=Cross(n,tangent).Unit;
    float length=.0014f+.0015f*(island%4)/4f,width=.0012f+.0011f*((island*3)%4)/4f;
    P previous=new P(),root=Lift(n,.0016f);
    for(int j=0;j<=6;j++){
     float a=j*2*PI/6f;
     P dn=(n+tangent*(float)Math.Cos(a)*length+side*(float)Math.Sin(a)*width).Unit;
     P edge=Lift(dn,.0019f);
     if(j>0)Tri(root,previous,edge,crust,crust,crust);
     previous=edge;
    }
   }
  }

  // v252: one union field per vent: crater lake, channels and overflow lobes.
  // Marching squares with a fixed diagonal inside every cell clips both triangles
  // to F>=0. No disconnected fans, overlap meshes or triangles across a hole.
  // The mesh is computed once; render uses one cached VBO, not CPU fluid updates.
  struct Flow252 { public float X,Y,W; }
  struct GridNode252 {public float X,Y,F;public int Id;}
  struct PatchPoint252 {public P Position;public Color Shade;}
  public int UnifiedPatches252 {get;private set;}
  public int UnifiedComponents252 {get;private set;}
  public int UnifiedBoundaryCuts252 {get;private set;}
  public int UnifiedTriangles252 {get;private set;}
  public float UnifiedMinArea252 {get;private set;}
  static float Sqr252(float x){return x*x;}
  static float FieldCapsule252(float px,float py,float ax,float ay,float bx,float by,float width){
   float dx=bx-ax,dy=by-ay,den=dx*dx+dy*dy;
   float t=den<1e-10f?0f:Clamp(((px-ax)*dx+(py-ay)*dy)/den,0,1);
   float x=ax+t*dx,y=ay+t*dy;
   return width-(float)Math.Sqrt(Sqr252(px-x)+Sqr252(py-y));
  }
  static float FieldEllipse252(float px,float py,float cx,float cy,float rx,float ry,float angle){
   float dx=px-cx,dy=py-cy;
   float c=(float)Math.Cos(angle),ss=(float)Math.Sin(angle);
   float ux=dx*c+dy*ss,uy=-dx*ss+dy*c;
   return Math.Min(rx,ry)*(1f-(float)Math.Sqrt(Sqr252(ux/rx)+Sqr252(uy/ry)));
  }
  static float Field252(float x,float y,int index,Flow252[][] paths){
   // Irregular caldera edge AND every branch are part of the same MAX union.
   float angle=(float)Math.Atan2(y,x),dist=(float)Math.Sqrt(x*x+y*y);
   float radius=.083f+(index==1?.010f:0f);
   float r=radius*(1f+.10f*(float)Math.Sin(angle*5+index*1.3f)+.044f*(float)Math.Sin(angle*9-index*.7f));
   float f=r-dist;
   for(int branch=0;branch<paths.Length;branch++){
    Flow252[] path=paths[branch];
    for(int i=0;i<path.Length-1;i++){
     Flow252 a=path[i],b=path[i+1];
     float v=FieldCapsule252(x,y,a.X,a.Y,b.X,b.Y,(a.W+b.W)*.5f);
     if(v>f)f=v;
    }
    // Side overflow bowls are integrated here, not rendered as separate quads.
    int[] basinIndex={8,18,28,38};
    for(int j=0;j<basinIndex.Length;j++){
     int k=basinIndex[j];Flow252 a=path[k],b=path[Math.Min(k+1,path.Length-1)];
     float dx=b.X-a.X,dy=b.Y-a.Y,sl=(float)Math.Sqrt(dx*dx+dy*dy);
     if(sl<1e-6f)continue;
     dx/=sl;dy/=sl;
     float side=((j+index+branch)&1)==0?1f:-1f;
     float cx=a.X-dy*a.W*.59f*side+dx*.007f,cy=a.Y+dx*a.W*.59f*side+dy*.007f;
     float v=FieldEllipse252(x,y,cx,cy,.030f+(j%2)*.009f,.019f+(j%3)*.005f,(float)Math.Atan2(dy,dx));
     if(v>f)f=v;
    }
   }
   // Small smooth edge waviness, not moving random noise or jagged triangles.
   float jitter=.0013f*(float)Math.Sin(x*66f+y*36f+index*.7f)+.0008f*(float)Math.Sin(x*25f-y*81f+index*2.1f);
   return f+jitter;
  }
  static long Key252(int x,int y,int type,int resolution){return (((long)y*(resolution+1)+x)<<2)+type;}
  static long EdgeKey252(int ix,int iy,int a,int b,int res){
   int lo=Math.Min(a,b),hi=Math.Max(a,b);
   if(lo==0&&hi==1)return Key252(ix,iy,1,res); // bottom
   if(lo==1&&hi==2)return Key252(ix+1,iy,2,res); // right
   if(lo==2&&hi==3)return Key252(ix,iy+1,1,res); // top
   if(lo==0&&hi==3)return Key252(ix,iy,2,res); // left
   return Key252(ix,iy,3,res); // shared diagonal 0 -> 2
  }
  static Color LavaShade252(float field,float x,float y){
   // Leave an irregular cooled rim and preserve a warm bright interior.
   float inner=Smooth(field/.021f);
   float patterned=.5f+.5f*(float)Math.Sin(x*69f+y*47f)*(.80f+.20f*(float)Math.Sin(x*37f-y*83f));
   Color cool=Color.FromArgb(57,29,24),red=Color.FromArgb(203,48,17),gold=Color.FromArgb(248,143,34);
   Color c=Mix246(cool,red,Smooth(field/.010f));
   c=Mix246(c,gold,inner*(.60f+.20f*patterned));
   return c;
  }
  PatchPoint252 Point252(GridNode252 g,P vent,P east,P north,Dictionary<long,PatchPoint252> cache,long key){
   PatchPoint252 hit;if(cache.TryGetValue(key,out hit))return hit;
   P n=(vent+east*g.X+north*g.Y).Unit;
   // Consistent terrain sampling on all shared vertices, not per triangle.
   float h=RenderHeight(n);
   float edge=Smooth(g.F/.012f);
   float lift=.0018f+.0033f*edge;
   hit=new PatchPoint252{Position=n*(h+lift),Shade=LavaShade252(g.F,g.X,g.Y)};
   cache[key]=hit;return hit;
  }
  void ClippedTriangle252(GridNode252[] grid,int ix,int iy,int res,P vent,P east,P north,Dictionary<long,PatchPoint252> cache,int[] corners){
   GridNode252[] clipped=new GridNode252[6];long[] keys=new long[6];int len=0;
   for(int i=0;i<3;i++){
    int ai=corners[i],bi=corners[(i+1)%3];GridNode252 a=grid[ai],b=grid[bi];
    bool ina=a.F>=0f,inb=b.F>=0f;
    if(ina&&inb){clipped[len]=b;keys[len]=Key252(ix+(bi==1||bi==2?1:0),iy+(bi>=2?1:0),0,res);len++;}
    else if(ina!=inb){
     float t=a.F/(a.F-b.F);t=Clamp(t,0f,1f);
     GridNode252 g=new GridNode252{X=a.X+(b.X-a.X)*t,Y=a.Y+(b.Y-a.Y)*t,F=0f};
     clipped[len]=g;keys[len]=EdgeKey252(ix,iy,ai,bi,res);len++;UnifiedBoundaryCuts252++;
     if(inb){clipped[len]=b;keys[len]=Key252(ix+(bi==1||bi==2?1:0),iy+(bi>=2?1:0),0,res);len++;}
    }
   }
   if(len<3)return;
   PatchPoint252 first=Point252(clipped[0],vent,east,north,cache,keys[0]);
   PatchPoint252 previous=Point252(clipped[1],vent,east,north,cache,keys[1]);
   for(int i=2;i<len;i++){
    PatchPoint252 next=Point252(clipped[i],vent,east,north,cache,keys[i]);
    float area=Cross(previous.Position-first.Position,next.Position-first.Position).Length;
    if(area>1e-8f){
     Tri(first.Position,previous.Position,next.Position,first.Shade,previous.Shade,next.Shade);
     UnifiedTriangles252++;if(UnifiedMinArea252==0||area<UnifiedMinArea252)UnifiedMinArea252=area;
    }
    previous=next;
   }
  }
  void UnifiedLava252(int volcano,P vent){
   P east=Cross(vent,Math.Abs(vent.Y)<.9f?new P(0,1,0):new P(1,0,0)).Unit,north=Cross(vent,east).Unit;
   const int steps=40;int branches=volcano==1?4:3;
   Flow252[][] paths=new Flow252[branches][];
   for(int k=0;k<branches;k++){
    Flow252[] path=new Flow252[steps+1];
    float angle=volcano*1.53f+k*1.34f+.38f;
    P outDir=east*(float)Math.Cos(angle)+north*(float)Math.Sin(angle);
    P at=(vent+outDir*.053f).Unit;
    P travel=Tangent(at,outDir);
    for(int i=0;i<=steps;i++){
     float t=i/(float)steps;
     path[i]=new Flow252{X=Dot(at,east),Y=Dot(at,north),W=(.012f+.020f*Smooth(t)+.013f*Peak246(t,.57f,.15f))*(.91f+.12f*(float)Math.Sin(i*.26f+k*1.4f+volcano))};
     if(i==steps)break;
     P side=Cross(at,travel).Unit;float best=-999f;P bestDir=travel;
     for(int j=-3;j<=3;j++){
      P direction=Tangent(at,Turn(travel,side,j*.17f)),next=(at+direction*.0050f).Unit;
      float score=(ground.Height(at)-ground.Height(next))*153f-.036f*Math.Abs(j)-.007f*j*j+.005f*(float)Math.Sin(i*.44f+j*.48f+volcano+k);
      if(score>best){best=score;bestDir=direction;}
     }
     P nextAt=(at+bestDir*.0050f).Unit;
     travel=Tangent(nextAt,bestDir*.88f+travel*.12f);at=nextAt;
    }
    paths[k]=path;
   }
   const int resolution=150;
   const float min=-.34f,max=.34f;
   float step=(max-min)/resolution;
   float[,] field=new float[resolution+1,resolution+1];
   for(int y=0;y<=resolution;y++)for(int x=0;x<=resolution;x++)field[x,y]=Field252(min+x*step,min+y*step,volcano,paths);
   // Regression guard: the union must be a SINGLE connected lake for this vent.
   // This catches isolated "lava trash" before mesh vertices are uploaded.
   bool[,] visited=new bool[resolution+1,resolution+1];
   int[] queue=new int[(resolution+1)*(resolution+1)];int components=0;
   for(int sy=0;sy<=resolution;sy++)for(int sx=0;sx<=resolution;sx++){
    if(field[sx,sy]<=0f||visited[sx,sy])continue;
    components++;int head=0,tail=0;queue[tail++]=sy*(resolution+1)+sx;visited[sx,sy]=true;
    while(head<tail){int packed=queue[head++],cx=packed%(resolution+1),cy=packed/(resolution+1);
     for(int oy=-1;oy<=1;oy++)for(int ox=-1;ox<=1;ox++){
      int nx=cx+ox,ny=cy+oy;
      if(nx<0||nx>resolution||ny<0||ny>resolution||visited[nx,ny]||field[nx,ny]<=0f)continue;
      visited[nx,ny]=true;queue[tail++]=ny*(resolution+1)+nx;
     }
    }
   }
   if(components!=1)throw new InvalidOperationException("v252 disconnected volcanic lake components="+components);
   UnifiedComponents252+=components;
   Dictionary<long,PatchPoint252> cache=new Dictionary<long,PatchPoint252>(9000);
   GridNode252[] grid=new GridNode252[4];int[] a={0,1,2},b={0,2,3};
   int trisBefore=UnifiedTriangles252;
   for(int y=0;y<resolution;y++)for(int x=0;x<resolution;x++){
    float f0=field[x,y],f1=field[x+1,y],f2=field[x+1,y+1],f3=field[x,y+1];
    if(f0<=0f&&f1<=0f&&f2<=0f&&f3<=0f)continue;
    grid[0]=new GridNode252{X=min+x*step,Y=min+y*step,F=f0};
    grid[1]=new GridNode252{X=min+(x+1)*step,Y=min+y*step,F=f1};
    grid[2]=new GridNode252{X=min+(x+1)*step,Y=min+(y+1)*step,F=f2};
    grid[3]=new GridNode252{X=min+x*step,Y=min+(y+1)*step,F=f3};
    ClippedTriangle252(grid,x,y,resolution,vent,east,north,cache,a);
    ClippedTriangle252(grid,x,y,resolution,vent,east,north,cache,b);
   }
   if(UnifiedTriangles252<=trisBefore)throw new InvalidOperationException("v252 empty volcanic union");
   UnifiedPatches252++;
   OrbitalOverflowPools246+=5; // integrated lobes rather than overlapping separate meshes
   MinimumBankWidth246=.012f;MaximumBankWidth246=.061f;
  }

  float SiteClear(P n){return 1f;}
  void Pool116(P center,P tangent,float length,float span,int seed){
   center=center.Unit;tangent=Tangent(center,tangent);
   P right=Cross(center,tangent).Unit;
   const int rings=16,sides=84;
   P[,] radial=new P[rings+1,sides];Color[,] color=new Color[rings+1,sides];
   for(int ring=0;ring<=rings;ring++)for(int j=0;j<sides;j++){
    float a=j*2*PI/sides,rad=ring/(float)rings;
    float noise=(float)Math.Sin(a*5.0f+seed*1.7f)*.14f+(float)Math.Sin(a*13f+seed*.71f)*.065f+(float)Math.Sin(a*23f+seed*1.21f)*.03f;
    float rr=rad*(1+noise*rad);
    P n=(center+tangent*((float)Math.Cos(a)*length*rr)+right*((float)Math.Sin(a)*span*rr)).Unit;
    float shoulder=Math.Max(0f,1f-rad);
    radial[ring,j]=Lift(n,.0012f+.0082f*(float)Math.Pow(shoulder,1.45f));
    Color amber=Color.FromArgb(255,124,28),yellow=Color.FromArgb(255,208,82),dark=Color.FromArgb(36,29,28);
    Color shade=Mix246(dark,warm,Clamp((.92f-rad)*1.15f,0f,1f));
    shade=Mix246(shade,amber,Clamp((.72f-rad)*1.45f,0f,.96f));
    shade=Mix246(shade,yellow,Clamp((.42f-rad)*2.05f,0f,.76f));
    color[ring,j]=shade;
   }
   for(int ring=0;ring<rings;ring++)for(int j=0;j<sides;j++){
    int next=(j+1)%sides;
    Tri(radial[ring,j],radial[ring+1,j],radial[ring+1,next],color[ring,j],color[ring+1,j],color[ring+1,next]);
    Tri(radial[ring,j],radial[ring+1,next],radial[ring,next],color[ring,j],color[ring+1,next],color[ring,next]);
   }
  }
  void River(int volcano,int branch,P vent){
   P east=Cross(vent,Math.Abs(vent.Y)<.9f?new P(0,1,0):new P(1,0,0)).Unit,up=Cross(vent,east).Unit;
   float angle=(volcano*1.53f+branch*1.34f+.38f);
   P outward=east*(float)Math.Cos(angle)+up*(float)Math.Sin(angle);
   P origin=(vent+(outward)*.062f).Unit;
   const int steps=30,across=16;
   P[] centerline=new P[steps+1];P[] travel=new P[steps+1];
   centerline[0]=origin;travel[0]=Tangent(origin,outward);
   for(int i=0;i<steps;i++){
    P n=centerline[i],dir=travel[i],side=Cross(n,dir).Unit;
    float bestScore=-1e20f;P best=dir;
    for(int j=-4;j<=4;j++){
     float turn=j*.20f;P candidate=Tangent(n,Turn(dir,side,turn));
     P next=(n+candidate*.0059f).Unit;
     float loss=ground.Height(n)-ground.Height(next);
     float meander=.008f*(float)Math.Sin(i*.63f+volcano*1.2f+branch*.9f+j*.6f);
     float score=loss*172f+meander-.050f*Math.Abs(j)-.008f*j*j;
     if(score>bestScore){bestScore=score;best=candidate;}
    }
    P finalNext=(n+best*.0059f).Unit;
    travel[i+1]=Tangent(finalNext,best*.90f+dir*.10f);
    centerline[i+1]=finalNext;
   }
   P[,] top=new P[steps+1,across+1];Color[,] cols=new Color[steps+1,across+1];
   for(int i=0;i<=steps;i++){
    float t=i/(float)steps;
    float left=(.020f+.018f*Smooth(t)+.010f*Peak246(t,.70f,.22f))*(.94f+.12f*(float)Math.Sin(t*8.0f+volcano*.8f+branch*1.4f));
    float right=(.016f+.014f*Smooth(t)+.012f*Peak246(t,.46f,.18f))*(.96f+.10f*(float)Math.Sin(t*9.7f+volcano*1.1f+branch*1.9f));
    if(i>steps-7){float spread=1.12f+.12f*Smooth((t-.78f)/.22f);left*=spread;right*=spread*.95f;}
    P n=centerline[i],side=Cross(n,travel[i]).Unit;
    for(int k=0;k<=across;k++){
     float u=k/(float)across*2f-1f;
     float f=u<0?u*left:u*right;
     float shoulder=Math.Max(0f,1f-Math.Abs(u));
     float ripple=.0016f*shoulder*(float)Math.Sin(t*19f+u*9f+volcano*1.2f)
                 +.0008f*shoulder*(float)Math.Sin(t*37f-u*15f+branch*2.1f);
     P d=(n+side*(f+ripple)).Unit;
     float lift=.0011f+.0068f*(float)Math.Pow(shoulder,1.65f)+.0005f*(float)Math.Sin(t*12f+u*6f+branch);
     top[i,k]=Lift(d,Math.Max(.0009f,lift));
     Color dark=Color.FromArgb(34,28,27),scarlet=Color.FromArgb(190,50,20),amber=Color.FromArgb(255,122,28),yellow=Color.FromArgb(255,206,76);
     Color shade=Mix246(dark,scarlet,Clamp(shoulder*1.05f,0f,1f));
     shade=Mix246(shade,amber,Clamp((shoulder-.18f)*1.25f,0f,.96f));
     shade=Mix246(shade,yellow,Clamp((shoulder-.55f)*1.90f,0f,.72f));
     cols[i,k]=shade;
    }
   }
   for(int i=0;i<steps;i++)for(int k=0;k<across;k++){
    Tri(top[i,k],top[i+1,k],top[i+1,k+1],cols[i,k],cols[i+1,k],cols[i+1,k+1]);
    Tri(top[i,k],top[i+1,k+1],top[i,k+1],cols[i,k],cols[i+1,k+1],cols[i,k+1]);
   }
   Pool116(centerline[steps-4],travel[steps-4],.080f,.071f,volcano*7+branch*3+1);
   for(int island=0;island<10;island++){
    int i=4+(island*13+branch*7+volcano*11)%(steps-6);
    int k=3+(island*5+volcano*3)%(across-5);
    P center=top[i,k],n=center.Unit;
    P tangent=travel[i],side=Cross(n,tangent).Unit;
    float length=.0018f+.0016f*(island%4)/4f,width=.0016f+.0014f*((island*3)%4)/4f;
    P previous=new P(),root=Lift(n,.0018f);
    for(int j=0;j<=6;j++){
     float ang=j*2*PI/6f;
     P d=(n+tangent*(float)Math.Cos(ang)*length+side*(float)Math.Sin(ang)*width).Unit;
     P edge=Lift(d,.0021f);
     if(j>0)Tri(root,previous,edge,crust,crust,crust);
     previous=edge;
    }
   }
  }
 }
}
