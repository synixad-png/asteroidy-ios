using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
namespace Asteroidy {
 // Actual 20/24-facet modelled firearm bodies and bored muzzles.
 // Every vertex is generated ONCE. No primitive boxes, textures, shaders or
 // per-frame mesh construction; ships in mission reuse the same five meshes.
 sealed partial class GpuRenderer {
  sealed class GunBuild101 {
   internal readonly List<float> V = new List<float>(9000);
   const float PI = (float)Math.PI;
   static float Clamp(float x){return Math.Min(1,Math.Max(0,x));}
   void Vert(float x,float y,float z,float r,float g,float b){V.Add(x);V.Add(y);V.Add(z);V.Add(Clamp(r));V.Add(Clamp(g));V.Add(Clamp(b));V.Add(1);}
   void Tri(float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float r,float g,float b){
    Vert(ax,ay,az,r,g,b);Vert(bx,by,bz,r,g,b);Vert(cx,cy,cz,r,g,b);
   }
   // Frustum along the Y axis with TWO beveled, 20-sided rings. Material variation
   // is face-specific and makes surfaces read as polished metal without textures.
   internal void Tube(float x,float z,float y0,float y1,float radius0,float radius1,
                      float r,float g,float b,int sides=20,float flatten=1){
    for(int i=0;i<sides;i++){
     float a=i*2*PI/sides,c=(i+1)*2*PI/sides;
     float sa=(float)Math.Sin(a),sc=(float)Math.Sin(c),ca=(float)Math.Cos(a),cc=(float)Math.Cos(c);
     float shade=.67f+.33f*Math.Max(0,(ca+cc)*.36f+(sa+sc)*.35f)+.09f*(float)Math.Max(0,(sa+sc)*.45f);
     float cr=Clamp(r*shade),cg=Clamp(g*shade),cb=Clamp(b*shade);
     float ax=x+radius0*ca,az=z+radius0*sa*flatten,bx=x+radius0*cc,bz=z+radius0*sc*flatten;
     float dx=x+radius1*ca,dz=z+radius1*sa*flatten,ex=x+radius1*cc,ez=z+radius1*sc*flatten;
     Tri(ax,y0,az,bx,y0,bz,ex,y1,ez,cr,cg,cb);
     Tri(ax,y0,az,ex,y1,ez,dx,y1,dz,cr,cg,cb);
    }
   }
   internal void Profile(float x,float z,float[] ys,float[] rs,float r,float g,float b,int sides=20){
    for(int i=0;i<ys.Length-1;i++) Tube(x,z,ys[i],ys[i+1],rs[i],rs[i+1],r,g,b,sides);
   }
   internal void Ring(float x,float z,float y,float inner,float outer,float r,float g,float b,int sides=24){
    for(int i=0;i<sides;i++){
     float a=i*2*PI/sides,c=(i+1)*2*PI/sides;
     float ca=(float)Math.Cos(a),sa=(float)Math.Sin(a),cc=(float)Math.Cos(c),sc=(float)Math.Sin(c);
     Tri(x+outer*ca,y,z+outer*sa,x+inner*ca,y,z+inner*sa,x+inner*cc,y,z+inner*sc,r,g,b);
     Tri(x+outer*ca,y,z+outer*sa,x+inner*cc,y,z+inner*sc,x+outer*cc,y,z+outer*sc,r,g,b);
    }
   }
   internal void Muzzle(float x,float z,float y,float bore,float outer,float r,float g,float b){
    Tube(x,z,y-.065f,y+.025f,outer*.89f,outer,r,g,b,24);
    Ring(x,z,y+.026f,bore,outer,.66f,.72f,.76f);
    Tube(x,z,y-.10f,y+.029f,bore,bore,.035f,.045f,.057f,24);
    Ring(x,z,y-.102f,0,bore*.93f,.015f,.024f,.035f);
   }
   internal void Breech(float x,float z,float thickness){
    Profile(x,z,new float[]{-.47f,-.40f,-.29f,-.11f,.075f,.19f},
                  new float[]{.16f*thickness,.21f*thickness,.25f*thickness,.25f*thickness,.20f*thickness,.145f*thickness},
                  .35f,.42f,.48f,24);
    Tube(x,z,-.39f,-.355f,.25f*thickness,.255f*thickness,.69f,.71f,.72f,24);
    Ring(x,z,-.470f,0,.16f*thickness,.18f,.23f,.28f,24);
    // One continuous machined breech, not disconnected decoration cubes.
    Tube(x,z,-.17f,-.135f,.253f*thickness,.257f*thickness,.18f,.26f,.32f,24);
   }
   internal void Barrel(float x,float z,float y0,float y1,float rad,float rr,float gg,float bb){
    Tube(x,z,y0,y0+.065f,rad*.88f,rad*1.09f,.22f,.28f,.33f,24);
    Tube(x,z,y0+.065f,y1-.11f,rad,rad,rr,gg,bb,24);
    Tube(x,z,y1-.11f,y1-.07f,rad,rad*1.13f,.29f,.33f,.36f,24);
    Tube(x,z,y1-.07f,y1-.02f,rad*1.13f,rad*1.03f,.68f,.73f,.76f,24);
    Muzzle(x,z,y1-.015f,rad*.55f,rad*1.14f,rr,gg,bb);
   }
   internal float[] Finish(){return V.ToArray();}
  }
  static readonly float[][] gunVertices101=BuildGuns101();
  readonly uint[] gunBuffers101=new uint[5];
  static float[][] BuildGuns101(){
   float[][] guns=new float[5][];
   for(int kind=0;kind<5;kind++){
    var m=new GunBuild101();
    if(kind==0){ // single pulse / assault cannon; one receiver, one long bored barrel
     m.Breech(0,0,1.0f);
     m.Tube(0,0,.15f,.42f,.145f,.126f,.23f,.33f,.42f,24);
     m.Barrel(0,0,.37f,1.08f,.102f,.52f,.59f,.64f);
     for(int j=0;j<3;j++) m.Tube(0,0,.30f+j*.105f,.313f+j*.105f,.132f,.132f,.65f,.69f,.68f,24);
    }else if(kind==1){ // matched twin-barrel turret with a common machined receiver
     m.Breech(0,0,1.12f);
     for(int s=-1;s<=1;s+=2){
      float x=s*.139f;
      m.Tube(x,0,.035f,.29f,.092f,.093f,.32f,.39f,.44f,20);
      m.Barrel(x,0,.25f,.97f,.079f,.62f,.68f,.70f);
     }
     m.Tube(0,-.10f,-.30f,.17f,.055f,.051f,.13f,.20f,.27f,20);
    }else if(kind==2){ // three real barrels on a compact shotgun/spread receiver
     m.Breech(0,0,1.17f);
     for(int j=-1;j<=1;j++){
      float x=j*.144f;
      float z=j==0?.095f:-.04f;
      m.Barrel(x,z,.12f,.81f,.071f,.64f,.61f,.55f);
     }
     m.Tube(0,0,-.30f,.18f,.092f,.10f,.41f,.30f,.26f,20);
    }else if(kind==3){ // electromagnetic rail gun, twin conductive rails and central bore
     m.Breech(0,0,1.20f);
     m.Barrel(0,0,.16f,1.13f,.094f,.39f,.57f,.65f);
     for(int s=-1;s<=1;s+=2){
      float x=s*.158f;
      m.Tube(x,0,.07f,.98f,.048f,.044f,.62f,.70f,.72f,20);
      m.Muzzle(x,0,.96f,.015f,.065f,.48f,.63f,.74f);
     }
     for(int i=0;i<4;i++){
      float y=.25f+i*.155f;
      m.Tube(0,0,y,y+.028f,.151f,.154f,.15f,.64f,.79f,24);
      m.Ring(0,0,y+.027f,.111f,.154f,.28f,.79f,.94f,24);
     }
    }else{ // compact six-bore missile/launcher cluster (recognizable launcher)
     m.Breech(0,0,1.30f);
     for(int ix=-1;ix<=1;ix++)for(int iz=-1;iz<=1;iz+=2){
      float x=ix*.132f,z=iz*.108f;
      m.Tube(x,z,.04f,.67f,.065f,.065f,.31f,.37f,.42f,20);
      m.Muzzle(x,z,.69f,.042f,.079f,.56f,.60f,.62f);
     }
     m.Tube(0,0,-.36f,.10f,.115f,.135f,.23f,.27f,.33f,24);
    }
    guns[kind]=m.Finish();
   }
   return guns;
  }
  // Keep the mount part of the ship transform so orientation tracks actual flight.
  void DrawCraftModules95(Game game){
   if(game==null)return;
   if(CraftType==1||CraftType==3)return; // Vanguard and imported player ship are self-contained; do not bolt extra weapon meshes onto it
   int kind=Math.Max(0,Math.Min(4,(int)game.Weapon));
   float[] mesh=gunVertices101[kind];
   GCHandle pin=new GCHandle();IntPtr ptr=IntPtr.Zero;
   try{
    bool vbo=genBuffers!=null&&bindBuffer!=null&&bufferData!=null;
    if(vbo){
     if(gunBuffers101[kind]==0){
      genBuffers(1,out gunBuffers101[kind]);
      pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);
      bindBuffer(0x8892,gunBuffers101[kind]);
      bufferData(0x8892,new IntPtr(mesh.Length*4),pin.AddrOfPinnedObject(),0x88E4);
     }else bindBuffer(0x8892,gunBuffers101[kind]);
    }else{pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);ptr=pin.AddrOfPinnedObject();}
    disable(TEX);disable(0x0B50);disable(0x0B44);
    enableClient(0x8074);enableClient(0x8076);
    vertexPointer(3,0x1406,28,ptr);
    colorPointer(4,0x1406,28,new IntPtr(ptr.ToInt64()+12));
    for(int side=-1;side<=1;side+=2){
     planetPush();shipTranslate(side*.89f,.10f,.20f);shipScale(.76f,.82f,.76f);
     // Individual weapons are compact and properly aligned with the craft.
     drawArrays(4,0,mesh.Length/7);
     planetPop();DrawCalls++;SubmittedVertices+=mesh.Length/7;
    }
    disableClient(0x8074);disableClient(0x8076);
    if(vbo)bindBuffer(0x8892,0);
   }finally{if(pin.IsAllocated)pin.Free();}
  }
  void DisposeGuns101(){
   if(deleteBuffers==null)return;
   for(int i=0;i<5;i++)if(gunBuffers101[i]!=0){deleteBuffers(1,ref gunBuffers101[i]);gunBuffers101[i]=0;}
  }
  // Exposed for automated geometry tests: each type has distinct, substantial mesh.
  internal static int GunTriangles101(int weapon){return gunVertices101[weapon].Length/21;}
 }
}
