using System;using System.Drawing;using System.IO;using System.IO.Compression;using System.Reflection;
namespace Asteroidy {
 // v432: two exhaust sockets precisely registered to the real GLB nozzle rings.
 // Replaces only regular VANGUARD (type 1), never VANGUARD X (type 3).
 // Independent GLB UV data is baked without a V flip. Mesh/materials are shared
 // by every GPU view: flight, mission, menu, hangar and shop.
 static class Vanguard431 {
  static readonly object Sync=new object();static bool loaded,ok;
  static ShipMesh.P[] engines;static ShipMesh.Face[] faces;static float[] vertices;static Bitmap skin;
  static Stream Open(string name){return Assembly.GetExecutingAssembly().GetManifestResourceStream(name);}
  static bool Ensure(){lock(Sync){if(loaded)return ok;loaded=true;try{
   using(Stream raw=Open("Asteroidy.Vanguard431.Mesh")){
    if(raw==null)throw new InvalidDataException("v431 Vanguard mesh resource missing");
    using(GZipStream zip=new GZipStream(raw,CompressionMode.Decompress))using(BinaryReader r=new BinaryReader(zip)){
     if(r.ReadInt32()!=4311)throw new InvalidDataException("v431 mesh version");
     int n=r.ReadInt32();if(n!=2)throw new InvalidDataException("v431 engine centers");
     engines=new ShipMesh.P[n];for(int i=0;i<n;i++)engines[i]=new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
     int floats=r.ReadInt32();if(floats<=0||floats>3500000||floats%12!=0)throw new InvalidDataException("v431 GPU mesh length");
     byte[] bytes=r.ReadBytes(floats*4);if(bytes.Length!=floats*4)throw new EndOfStreamException();
     vertices=new float[floats];Buffer.BlockCopy(bytes,0,vertices,0,bytes.Length);
     int triangles=r.ReadInt32();if(triangles<=0||triangles>13000)throw new InvalidDataException("v431 CPU mesh count");
     faces=new ShipMesh.Face[triangles];for(int i=0;i<triangles;i++)faces[i]=new ShipMesh.Face(
      new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),
      new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),
      new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),0);
    }
   }
   return ok=true;
  }catch(Exception ex){engines=null;faces=null;vertices=null;Console.Error.WriteLine("Vanguard431 load failed: "+ex);return ok=false;}}}
  public static bool TryApply(ShipMesh mesh){if(!Ensure())return false;
   mesh.EngineCenters=engines;mesh.Faces=faces;mesh.Vertices=vertices;
   mesh.Start[0]=0;mesh.Count[0]=vertices.Length/12;
   for(int m=1;m<8;m++){mesh.Start[m]=0;mesh.Count[m]=0;}
   mesh.Palette[0]=Color.White;return true;
  }
  public static Bitmap TryLoadSkin(){lock(Sync){
   if(skin==null){using(Stream raw=Open("Asteroidy.Vanguard431.Base")){
    if(raw==null)throw new InvalidDataException("v431 baseColor missing");
    using(Bitmap src=new Bitmap(raw)){
     Bitmap clone=new Bitmap(src.Width,src.Height,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
     using(Graphics g=Graphics.FromImage(clone)){g.CompositingMode=System.Drawing.Drawing2D.CompositingMode.SourceCopy;g.DrawImage(src,0,0,src.Width,src.Height);}
     skin=clone;
    }
   }}return (Bitmap)skin.Clone();
  }}
 }
}
