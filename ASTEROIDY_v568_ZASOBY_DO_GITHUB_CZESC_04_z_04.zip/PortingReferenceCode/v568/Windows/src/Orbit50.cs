using System;using System.IO;using System.Drawing;using System.Runtime.InteropServices;using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {
 // v330: a single source of truth for compact persistent atlas grid and hit testing.
 // Keeping display and hitbox coordinates shared prevents clicking a different mission.
 internal static class OrbitHud330 {
  internal const float GridX=1001f,GridY=55f,StepX=32f,StepY=26f,TileWidth=29f,TileHeight=22f;
  internal static RectangleF Tile(int mission){int i=mission-1;return new RectangleF(GridX+(i%8)*StepX,GridY+(i/8)*StepY,TileWidth,TileHeight);}
  internal static int Hit(float x,float y){
   if(x<GridX||y<GridY||x>=GridX+8*StepX||y>=GridY+4*StepY)return 0;
   int col=(int)((x-GridX)/StepX),row=(int)((y-GridY)/StepY),n=row*8+col+1;
   RectangleF tile=Tile(n);return n<=Game.AtlasMissionCount276&&x>=tile.Left&&x<tile.Right&&y>=tile.Top&&y<tile.Bottom?n:0;
  }
  internal static int Completed(Game g){int n=0;for(int i=1;i<=Game.AtlasMissionCount276;i++)if(g.MissionCompleted50(i))n++;return n;}
 }
 internal static partial class OrbitWorld50 {
  internal const float Radius=100,Floor=122,Ceiling=450;
  internal static int Zone(IP p){p=p.Unit;int row=p.Y>1f/3?1:p.Y< -1f/3?2:0;float a=(float)Math.Atan2(p.Z,p.X);if(a<0)a+=Game.PI*2;return row*8+Math.Min(7,(int)(a/(Game.PI/4)))+1;}
  internal static IP Beacon(int level){IP dir;if(level==26)dir=new IP(-.48f,.87f,-.20f).Unit;else if(level==25)dir=new IP(.38f,.90f,.22f).Unit;else{int n=Math.Max(0,Math.Min(23,level-1)),row=n/8;float y=row==0?0:row==1?2f/3:-2f/3,a=(n%8+.5f)*Game.PI/4,r=(float)Math.Sqrt(1-y*y);dir=new IP((float)Math.Cos(a)*r,y,(float)Math.Sin(a)*r);}return dir*(NewHome290.Enabled?NewHome290.Surface(dir)+4f:125f);}
  // v111: one physically consistent world-space stellar direction used by the
  // rocky surface shader and by fixed-function illumination of close objects.
  // ~134 seconds per revolution, gently inclined above/below the equator.
  internal static IP SunDirection111(float seconds){
   float angle=.62f+Math.Max(0,seconds)*.047f;
   return new IP((float)Math.Cos(angle),.25f+(float)Math.Sin(angle*.33f)*.13f,(float)Math.Sin(angle)).Unit;
  }
  internal static float SunExposure111(IP surface,float seconds){
   float facing=IntroScene41.Dot(surface.Unit,SunDirection111(seconds));
   float x=Math.Max(0,Math.Min(1,(facing+.20f)/.42f));
   return x*x*(3-2*x);
  }
  internal static IP Rotate(IP v,IP axis,float angle){float c=(float)Math.Cos(angle),s=(float)Math.Sin(angle);return v*c+IntroScene41.Cross(axis,v)*s+axis*(IntroScene41.Dot(axis,v)*(1-c));}
  internal static void View(IP eye,IP target,IP up,float[] m){IP f=(target-eye).Unit,s=IntroScene41.Cross(f,up).Unit;if(s.Length<.1f)s=IntroScene41.Cross(f,Math.Abs(f.Y)<.9f?new IP(0,1,0):new IP(1,0,0)).Unit;IP u=IntroScene41.Cross(s,f);m[0]=s.X;m[1]=u.X;m[2]=-f.X;m[3]=0;m[4]=s.Y;m[5]=u.Y;m[6]=-f.Y;m[7]=0;m[8]=s.Z;m[9]=u.Z;m[10]=-f.Z;m[11]=0;m[12]=-IntroScene41.Dot(s,eye);m[13]=-IntroScene41.Dot(u,eye);m[14]=IntroScene41.Dot(f,eye);m[15]=1;}
  internal static bool Visible(IP eye,IP point){IP delta=point-eye;float length=delta.Length;IP ray=delta.Unit;
   if(NewHome290.Enabled){for(int k=1;k<22;k++){IP p=eye+delta*(k/22f);if(p.Length<NewHome290.Surface(p)+.6f)return false;}return true;}
float b=IntroScene41.Dot(eye,ray),c=IntroScene41.Dot(eye,eye)-102*102,d=b*b-c;if(d<0)return true;float hit=-b-(float)Math.Sqrt(d);return hit<0||hit>length;}
 }
 public partial class Game {
  public const int AtlasMissionCount276=26;public bool PlanetHub50,HubMission50;public int CompletedMissions50,OrbitTarget50=1;public float OrbitTime50,OrbitSpeed50,OrbitBank50,OrbitDistance50;bool orbitFire50;public float OrbitLookYaw53,OrbitLookPitch53;
  internal IP OrbitPosition50,OrbitForward50,OrbitCamera50,OrbitVelocity51,OrbitRight51;
  public bool OrbitVisible50{get{return Mode==Mode.Orbit||Mode==Mode.Paused&&PausedFrom==Mode.Orbit;}}
  public bool MissionCompleted50(int level){return level>=1&&level<=AtlasMissionCount276&&(CompletedMissions50&(1<<(level-1)))!=0;}
  public bool MissionUnlocked50(int level){return level>=1&&level<=AtlasMissionCount276&&(DevEnabled||level==1||MissionCompleted50(level)||(level==26?MissionCompleted50(24):MissionCompleted50(level-1)));}
  static string ProgressPath50{get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Asteroidy","planet-progress50.txt");}}
  public void LoadProgress50(){try{int value;int mask=(1<<AtlasMissionCount276)-1;if(int.TryParse(File.ReadAllText(ProfilePath61("planet-progress50.txt")),out value)&&value>=0)CompletedMissions50|=(value&mask)|((value&(1<<26))!=0?1:0);}catch{}}
  void CompleteMission50(){string ProgressPath50=ProfilePath61("planet-progress50.txt");if(DevEnabled||Level<1||Level>AtlasMissionCount276)return;CompletedMissions50|=1<<(Level-1);try{Directory.CreateDirectory(Path.GetDirectoryName(ProgressPath50));string tmp=ProgressPath50+".tmp";File.WriteAllText(tmp,CompletedMissions50.ToString());if(File.Exists(ProgressPath50))File.Replace(tmp,ProgressPath50,null);else File.Move(tmp,ProgressPath50);}catch{} }
  public void EnterOrbit50(bool reset=false){if(!PlanetHub50)return;if(DeferScene(delegate{EnterOrbit50(reset);}))return;MiningDetached389=false;ResetPadHeading297();VisualPower298=0;motionAcceleration298=new V();Rocks.Clear();Bugs.Clear();Bullets.Clear();CombatPieces125.Clear();BossProjectiles.Clear();Pickups.Clear();ResetBossSpecial();BossHealth=0;Mode=Mode.Orbit;TalentOpen78=false;HangarOpen=false;IntroTime=IntroExitFade=0;OrbitSpeed50=0;OrbitVelocity51=new IP();Thrusting=false;orbitFire50=true;
   if(reset||OrbitPosition50.Length<1){OrbitLookYaw53=OrbitLookPitch53=0;OrbitTarget50=1;for(int i=1;i<=AtlasMissionCount276;i++)if(MissionUnlocked50(i)&&!MissionCompleted50(i)){OrbitTarget50=i;break;}IP n=OrbitWorld50.Beacon(OrbitTarget50).Unit,t=IntroScene41.Cross(new IP(0,1,0),n).Unit;OrbitPosition50=NewHome290.Enabled?NewHome290.SpawnPosition((n-t*.20f).Unit):n*132-t*48;OrbitForward50=t*-1;OrbitRight51=IntroScene41.Cross(OrbitForward50,n).Unit;OrbitCamera50=OrbitPosition50-OrbitForward50*16+n*9;}
   if(NewHome290.Enabled)InitializeHomeFlight291();
   if(!reset&&MissionCompleted50(OrbitTarget50))for(int i=1;i<=AtlasMissionCount276;i++)if(MissionUnlocked50(i)&&!MissionCompleted50(i)){OrbitTarget50=i;break;}OrbitDistance50=OrbitWorld50.SurfaceDistance51(OrbitPosition50,OrbitTarget50);DockDistance90=(OrbitPosition50-DockPosition90).Length;UiRevision++;RefreshCheckpoint61();
  }
  // v261: one mission-start path for entering a beacon from orbit or advancing directly
  // from the post-mission service shop. Keep the full wave/intro initialization identical.
  public void LaunchOrbitMission50(){if(Mode!=Mode.Orbit||SceneBusy||TalentOpen78)return;if(MiningDetached389){Notice="WRÓĆ PROMEM DO MAMMOTHA PRZED STARTEM MISJI";NoticeTime=4;UiRevision++;return;}
   int selected=OrbitEntryMission56;if(selected==0)return;
   OrbitTarget50=selected;OrbitDistance50=(OrbitPosition50-OrbitWorld50.Beacon(selected)).Length;
   StartHubMission261(selected,false);
  }
  void StartHubMission261(int selected,bool moveOrbit){
   if(selected<1||selected>AtlasMissionCount276||!MissionUnlocked50(selected))return;
   Action start=delegate{
    if(moveOrbit){
     IP n=OrbitWorld50.Beacon(selected).Unit,t=IntroScene41.Cross(new IP(0,1,0),n).Unit;
     OrbitPosition50=NewHome290.Enabled?NewHome290.SpawnPosition((n-t*.20f).Unit):n*132-t*48;OrbitForward50=t*-1;
     OrbitRight51=IntroScene41.Cross(OrbitForward50,n).Unit;
     OrbitCamera50=OrbitPosition50-OrbitForward50*16+n*9;
     OrbitDistance50=OrbitWorld50.SurfaceDistance51(OrbitPosition50,selected);
    }
    MiningDetached389=false;OrbitTarget50=selected;HubMission50=true;Level=selected;Mode=Mode.Playing;
    ResetVitals78();BossLevel=BossDefeatedAt=0;BossSpawned=BossDefeated=false;BossHealth=0;
    TunnelCompleted=TunnelSummary=ArrivalShop=false;ResetBossSpecial();ResetFlightMotion();
    Rocks.Clear();Bugs.Clear();Bullets.Clear();Pickups.Clear();BossProjectiles.Clear();
    ResetMissionTrophies78();if(Lives<=0)Lives=StartingLives;
    Ship=new V(W/2,H/2);Velocity=new V();Angle=-PI/2;ResetPadHeading297();ResetSphereCamera67();VisualReady81=false;
    Time=SectorTime=Cooldown=0;Invincible=selected<=4?4.5f:3f;
    Wave();BeginLevelIntro();
   };
   if(!DeferScene(start))start();
  }
  // This selection exists only after a recorded success. Boss tunnels must
  // still be completed before the player may advance to the following mission.
  public bool CanNextHubMission261{get{return PlanetHub50&&HubMission50&&Mode==Mode.Shop&&
   Level>=1&&Level<CampaignLength&&!ArrivalShop&&MissionCompleted50(Level)&&
   MissionUnlocked50(Level+1)&&(!IsBossSector||TunnelCompleted);}}
  public void NextHubMission261(){
   if(!CanNextHubMission261||SceneBusy)return;
   SaveShopProfile56();SaveTalentProfile78();
   StartHubMission261(Level+1,true);
  }
  public int OrbitEntryMission56{get{if(MissionUnlocked50(OrbitTarget50)&&OrbitWorld50.MissionArea51(OrbitPosition50,OrbitTarget50))return OrbitTarget50;for(int i=1;i<=AtlasMissionCount276;i++)if(MissionUnlocked50(i)&&OrbitWorld50.MissionArea51(OrbitPosition50,i))return i;return 0;}}
  public bool OrbitMissionReady51{get{return MissionUnlocked50(OrbitTarget50)&&OrbitWorld50.MissionArea51(OrbitPosition50,OrbitTarget50);}}
  public void CycleOrbitTarget51(){for(int i=1;i<=AtlasMissionCount276;i++){int n=(OrbitTarget50-1+i)%AtlasMissionCount276+1;if(MissionUnlocked50(n)){OrbitTarget50=n;break;}}UiRevision++;}
  public void OrbitClick51(float x,float y){if(Mode!=Mode.Orbit||TalentOpen78)return;if(x>=490&&x<=790&&y>=560&&y<=605&&OrbitEntryMission56>0){LaunchOrbitMission50();return;}int n=OrbitHud330.Hit(x,y);if(n>0&&MissionUnlocked50(n)){OrbitTarget50=n;UiRevision++;}}
  internal void OrbitAim53(out IP forward,out IP up){up=IntroScene41.Cross(OrbitRight51,OrbitForward50).Unit;if(up.Length<.1f)up=OrbitPosition50.Unit;forward=OrbitWorld50.Rotate(OrbitForward50,up,-OrbitLookYaw53).Unit;IP right=IntroScene41.Cross(forward,up).Unit;forward=OrbitWorld50.Rotate(forward,right,OrbitLookPitch53).Unit;up=IntroScene41.Cross(right,forward).Unit;}
  void StepOrbit50(float dt,Input input){if(NewHome290.Enabled){StepHomeFlight291(dt,input);return;}if(TalentOpen78)return;dt=Math.Max(0,Math.Min(.05f,dt));OrbitTime50+=dt;if(input.Recenter53)OrbitLookYaw53=OrbitLookPitch53=0;else{OrbitLookYaw53+=input.LookX53*dt*1.8f;if(OrbitLookYaw53>PI)OrbitLookYaw53-=2*PI;if(OrbitLookYaw53< -PI)OrbitLookYaw53+=2*PI;OrbitLookPitch53=Math.Max(-1.05f,Math.Min(1.05f,OrbitLookPitch53+input.LookY53*dt*1.3f));}IP up=OrbitPosition50.Unit;float yaw=(input.Right?1:0)-(input.Left?1:0);
   float orbitTurn=ShipType==CustomShipType368?.58f:ShipType==HeavyShipType387?.52f:ShipType==TransportShipType388?(MiningDetached389?1.25f:.40f):1f;
   OrbitForward50=OrbitWorld50.Rotate(OrbitForward50,up,(-(NewHome290.Enabled&&input.SurfaceDirect67?0:yaw*dt*1.05f)-input.OrbitMouseYaw67)*orbitTurn).Unit;OrbitRight51=OrbitWorld50.Rotate(OrbitRight51,up,(-(NewHome290.Enabled&&input.SurfaceDirect67?0:yaw*dt*1.05f)-input.OrbitMouseYaw67)*orbitTurn).Unit;
   IP right=IntroScene41.Cross(OrbitForward50,up).Unit;if(right.Length<.1f)right=(OrbitRight51-OrbitForward50*IntroScene41.Dot(OrbitRight51,OrbitForward50)).Unit;if(right.Length<.1f)right=IntroScene41.Cross(OrbitForward50,Math.Abs(OrbitForward50.Y)<.9f?new IP(0,1,0):new IP(1,0,0)).Unit;if(IntroScene41.Dot(right,OrbitRight51)<0)right=right*-1;OrbitRight51=right;
   OrbitForward50=OrbitWorld50.Rotate(OrbitForward50,right,(input.Pitch*dt*.8f+input.OrbitMousePitch67)*(ShipType==CustomShipType368?.65f:ShipType==HeavyShipType387?.60f:ShipType==TransportShipType388?(MiningDetached389?1.25f:.52f):1f)).Unit;
   float strafe=(input.StrafeRight?1:0)-(input.StrafeLeft?1:0);
   float lift=(input.AscendOrbit133?1:0)-(input.DescendOrbit133?1:0);
   float speed=(NewHome290.Enabled?32f:46f)*(ShipType==0?1.12f:ShipType==2?.86f:ShipType==CustomShipType368?.93f:ShipType==HeavyShipType387?.76f:ShipType==TransportShipType388?(MiningDetached389?1.18f:.70f):1);
   IP wanted;
   if(NewHome290.Enabled&&input.SurfaceDirect67){
    // Combat-level control scheme: WASD/stick moves the craft directly in
    // surface-tangent directions, while aim stick controls its heading.
    float mx=input.MoveX67,my=input.MoveY67,magnitude=(float)Math.Sqrt(mx*mx+my*my);
    if(magnitude>1f){mx/=magnitude;my/=magnitude;}else if(magnitude<.03f){mx=my=0;}
    wanted=right*(mx*speed)-OrbitForward50*(my*speed)+up*(lift*20);
    float ax=input.AimX67,ay=input.AimY67;
    if(ax*ax+ay*ay>.09f){
     // Stable global tangent frame: held right-stick aim must never make
     // the fighter spin by 90 degrees every simulation step.
     IP screenRight=IntroScene41.Cross(new IP(0,1,0),up).Unit;
     if(screenRight.Length<.1f)screenRight=IntroScene41.Cross(new IP(1,0,0),up).Unit;
     IP screenUp=IntroScene41.Cross(up,screenRight).Unit;
     IP facing=screenRight*ax-screenUp*ay;
     if(facing.Length>.01f)OrbitForward50=facing.Unit;
    }
   }else wanted=input.Brake?new IP():OrbitForward50*(input.Thrust?speed:0)+right*(strafe*(NewHome290.Enabled?16:20))+up*(lift*20);
   OrbitVelocity51+=(wanted-OrbitVelocity51)*Math.Min(1,dt*(ShipType==CustomShipType368?(input.Brake?8:input.Thrust||strafe!=0||lift!=0?1.8f:3.2f):ShipType==HeavyShipType387?(input.Brake?7:input.Thrust||strafe!=0||lift!=0?1.6f:2.8f):ShipType==TransportShipType388?(MiningDetached389?(input.Brake?14f:input.Thrust||strafe!=0||lift!=0?5.1f:7f):(input.Brake?6.2f:input.Thrust||strafe!=0||lift!=0?1.25f:2.2f)):(input.Brake?12:input.Thrust||strafe!=0||lift!=0?3:5)));if(OrbitVelocity51.Length<.02f)OrbitVelocity51=new IP();
   IP next=OrbitWorld50.Move51(OrbitPosition50,ref OrbitVelocity51,dt);OrbitPosition50=next;OrbitSpeed50=OrbitVelocity51.Length;up=next.Unit;
   if(NewHome290.Enabled){ // stay tangent to spherical terrain, as in combat-level flight
    IP tangent=OrbitForward50-up*IntroScene41.Dot(OrbitForward50,up);
    if(tangent.Length>.001f)OrbitForward50=tangent.Unit;
    IP transverse=IntroScene41.Cross(OrbitForward50,up).Unit;
    if(transverse.Length>.001f)OrbitRight51=transverse;
   }OrbitBank50+=(-yaw*.28f-OrbitBank50)*Math.Min(1,dt*6);IP aim53,viewUp53;OrbitAim53(out aim53,out viewUp53);IP camera=next-aim53*16+viewUp53*9;OrbitCamera50+=(camera-OrbitCamera50)*Math.Min(1,dt*8);if(OrbitCamera50.Length<(NewHome290.Enabled?NewHome290.Surface(OrbitCamera50)+5f:126f))OrbitCamera50=OrbitCamera50.Unit*(NewHome290.Enabled?NewHome290.Surface(OrbitCamera50)+5f:126f);Thrusting=NewHome290.Enabled&&input.SurfaceDirect67?Math.Abs(input.MoveX67)+Math.Abs(input.MoveY67)>.04f:input.Thrust&&!input.Brake;SideThrust=NewHome290.Enabled&&input.SurfaceDirect67?input.MoveX67:strafe;
   // Selection is persistent. Locked goals are never selected by proximity or cycling.
   if(!MissionUnlocked50(OrbitTarget50)){OrbitTarget50=1;for(int i=1;i<=AtlasMissionCount276;i++)if(MissionUnlocked50(i)&&!MissionCompleted50(i)){OrbitTarget50=i;break;}}
   OrbitDistance50=OrbitWorld50.SurfaceDistance51(next,OrbitTarget50);DockDistance90=(next-DockPosition90).Length;
   if(input.Fire&&!orbitFire50)LaunchOrbitMission50();orbitFire50=input.Fire;
  }

 }
 public sealed partial class Renderer {
  // v330 minimalist atlas HUD: readable text over the real world; only the 26
  // small mission tiles use a filled background to encode campaign progression.
  void DrawOrbit50(Canvas c,Game game){
   if(c.IsGpu){c.Gpu.OrbitScene50(game,GlowEnabled,NebulaEnabled,SolarRaysEnabled);c.Gpu.FinishWorldPost104();}
   else c.Clear(Color.FromArgb(7,14,24));
   // The existing planet, beacons, orbit selection and gameplay remain unchanged.
   StyleFrame58(c);
   int target=game.OrbitTarget50;bool unlocked=game.MissionUnlocked50(target);
   Color status=game.MissionCompleted50(target)?Color.FromArgb(106,233,175):unlocked?Cyan:Soft;
   // Top-left: navigation, target, range and bearing — no opaque panels.
   Line(c,new V(34,35),new V(54,35),Cyan,1.3f);
   Line(c,new V(34,52),new V(34,153),Color.FromArgb(122,Cyan),1);
   Text(c,"ATLAS "+target.ToString("00")+" · "+Game.ShipNames[game.ShipType].ToUpperInvariant(),55,38,1,Paper,515,StringAlignment.Near);
   Text(c,"CEL: "+PlanetBiome.ForLevel(target).Name,56,80,0,Paper,470,StringAlignment.Near);
   Text(c,"ODL: "+(int)game.OrbitDistance50+" m",56,106,0,status,330,StringAlignment.Near);
   IP bearing=OrbitWorld50.Route51(game.OrbitPosition50,target),tangent=(bearing-game.OrbitPosition50.Unit*IntroScene41.Dot(bearing,game.OrbitPosition50.Unit)).Unit,side=IntroScene41.Cross(game.OrbitForward50,game.OrbitPosition50.Unit).Unit;
   float course=(float)Math.Atan2(IntroScene41.Dot(tangent,side),IntroScene41.Dot(tangent,game.OrbitForward50))*180/Game.PI;
   string courseText=unlocked?(int)Math.Abs(course)+"° "+(course<0?"W LEWO":"W PRAWO"):"NIEDOSTĘPNA";
   Text(c,"KURS: "+courseText,56,132,0,Soft,460,StringAlignment.Near);
   if(game.MissionCompleted50(target))Text(c,"UKOŃCZONA · MOŻNA POWTÓRZYĆ",56,159,0,status,435,StringAlignment.Near);
   else if(!unlocked)Text(c,"ODBLOCKUJ POPRZEDNIĄ MISJĘ",56,159,0,status,435,StringAlignment.Near);
   // Compact flight data, kept clear of the selectable grid at x=1001+.
   Text(c,"STREFA "+OrbitWorld50.Zone(game.OrbitPosition50).ToString("00"),817,31,0,Soft,168,StringAlignment.Near);
   Text(c,"PUŁAP "+(int)(game.OrbitPosition50.Length-NewHome290.Surface(game.OrbitPosition50)),817,54,0,Cyan,168,StringAlignment.Near);
   Text(c,"PRĘDKOŚĆ "+(int)game.OrbitSpeed50,817,77,0,Cyan,168,StringAlignment.Near);
   // The progress number counts completed missions, not merely the selected stage.
   Text(c,"POSTĘP "+OrbitHud330.Completed(game).ToString("00")+" / "+Game.AtlasMissionCount276.ToString("00"),OrbitHud330.GridX,25,0,Cyan,254,StringAlignment.Near);
   for(int i=1;i<=Game.AtlasMissionCount276;i++){
    RectangleF r=OrbitHud330.Tile(i);
    bool completed=game.MissionCompleted50(i),selected=i==target;
    Color fill=completed?Color.FromArgb(174,65,168,139):game.MissionUnlocked50(i)?Color.FromArgb(170,28,75,98):Color.FromArgb(165,17,30,43);
    Box(c,r,fill);
    if(selected){Line(c,new V(r.Left,r.Bottom),new V(r.Right,r.Bottom),Cyan,2);Line(c,new V(r.Left,r.Top),new V(r.Right,r.Top),Color.FromArgb(160,Cyan),1);}
    Text(c,i.ToString("00"),r.Left,r.Top+3,0,Paper,r.Width,StringAlignment.Center);
   }
   // Contextual dock label, without the former 425x176 filled card.
   Text(c,"JEDYNY HANGAR",982,243,1,Paper,275,StringAlignment.Near);
   Line(c,new V(982,273),new V(1054,273),Cyan,1);
   Text(c,(int)game.DockDistance90+" m",982,281,0,Cyan,265,StringAlignment.Near);
   Text(c,game.CanDock90?"MOŻNA DOKOWAĆ":"POZA STREFĄ DOKOWANIA",982,307,0,game.CanDock90?Olive:Soft,287,StringAlignment.Near);
   // Preserve original clickable mission and docking hot zones, with discreet prompts.
   int entry=game.OrbitEntryMission56;
   if(entry>0){
    Text(c,"MISJA "+entry.ToString("00")+" · "+PlanetBiome.ForLevel(entry).Name,480,526,0,Paper,320,StringAlignment.Center);
    Text(c,game.MissionCompleted50(entry)?"ENTER / A · ZAGRAJ PONOWNIE":"ENTER / A · ROZPOCZNIJ MISJĘ",484,568,0,Cyan,310,StringAlignment.Center);
   }
   if(game.CanDock90){
    Text(c,"E / ENTER / A · WEJDŹ DO HANGARU",452,389,0,Olive,376,StringAlignment.Center);
   }
   // No permanent large help bar; same actions, rendered in one unobtrusive line.
   string help=NewHome290.Enabled?"LPM / RT STRZAŁ   ·   ENTER / A MISJA   ·   E HANGAR":
    Controls.OrbitMouse67?(OrbitMouseFree67?"TAB: LOT   ·   MYSZ: WYBÓR MISJI   ·   ENTER / A: MISJA":"MYSZ: KIERUNEK   ·   TAB: KURSOR   ·   ENTER / A: MISJA"):
    "LEWY DRĄŻEK: LOT   ·   PRAWY: KAMERA   ·   ENTER / A: MISJA";
   Line(c,new V(35,681),new V(64,681),Cyan,1);
   Text(c,help,69,671,0,Soft,874,StringAlignment.Near);
   // Actual mission markers, beacons, world effects and click logic are unchanged.
   if(c.IsGpu)c.Gpu.OrbitNavigation50(c,game);
  }

 }
 sealed partial class GpuRenderer {
  float[] orbitVertices50;uint orbitBuffer50;uint orbitLavaBuffer114;float[] orbitLavaVertices114;public int OrbitLavaUploads114{get;private set;}readonly PointF[] beaconScreens50=new PointF[Game.AtlasMissionCount276];readonly bool[] beaconVisible50=new bool[Game.AtlasMissionCount276];public int OrbitUploads50{get;private set;}
  U orbitMipmap51;bool orbitMipReady51;void InitOrbit51(Func<string,IntPtr> resolve){orbitMipmap51=Optional<U>(resolve,"glGenerateMipmap");}
  // Two immutable GPU buffers: detailed close atlas, 4x fewer terrain faces at a distance.
  float[] orbitFarVertices110;uint orbitFarBuffer110;int orbitFarTerrain110,orbitFarWater110;
  bool orbitFarActive110;public int OrbitFarUploads110{get;private set;}
  Bitmap orbitTexture51;int orbitTerrainCount51;public int OrbitTriangles51{get{return orbitVertices50==null?0:orbitVertices50.Length/36;}}public int OrbitTextureSize51{get{return orbitTexture51==null?0:orbitTexture51.Width;}}
  void PrepareOrbit50(){if(orbitVertices50!=null)return;System.Diagnostics.Stopwatch timer134=System.Diagnostics.Stopwatch.StartNew();StartupLog.Write("v134 atlas resource initialization START");PlanetMesh mesh=new PlanetMesh(1,7);orbitMesh52=mesh;PrepareLife52(mesh);if(mesh.Basalt110)orbitLavaVertices114=new LavaMesh116(mesh).Vertices;else if(mesh.LavaVertices>0){orbitLavaVertices114=new float[mesh.LavaVertices*10];Array.Copy(mesh.Vertices,mesh.LavaStart*10,orbitLavaVertices114,0,orbitLavaVertices114.Length);}orbitTerrainCount51=mesh.TerrainVertices+mesh.WaterVertices;orbitTexture51=OrbitWorld50.Texture51(mesh);float[] source=new float[orbitTerrainCount51*10];Array.Copy(mesh.Vertices,source,source.Length);orbitVertices50=new float[source.Length/10*12];for(int v=0;v<source.Length/10;v++){int i=v*10,j=v*12;Array.Copy(source,i,orbitVertices50,j,10);IP p=new IP(source[i],source[i+1],source[i+2]);if(v>=orbitTerrainCount51){float surface=mesh.Height(new PlanetMesh.P(p.Unit.X,p.Unit.Y,p.Unit.Z));IP smaller=p.Unit*(surface+(p.Length-surface)*.30f);orbitVertices50[j]=smaller.X;orbitVertices50[j+1]=smaller.Y;orbitVertices50[j+2]=smaller.Z;}if(v<orbitTerrainCount51){orbitVertices50[j+6]=orbitVertices50[j+7]=orbitVertices50[j+8]=1;}orbitVertices50[j+10]=(float)(Math.Atan2(p.Z,p.X)/(2*Math.PI)+.5);orbitVertices50[j+11]=(float)(Math.Asin(p.Unit.Y)/Math.PI+.5);}
   // Unwrap triangles crossing the longitude seam. Texture wrapping is enabled below.
   for(int i=0;i<orbitTerrainCount51;i+=3){int j=i*12;float low=Math.Min(orbitVertices50[j+10],Math.Min(orbitVertices50[j+22],orbitVertices50[j+34])),high=Math.Max(orbitVertices50[j+10],Math.Max(orbitVertices50[j+22],orbitVertices50[j+34]));if(high-low>.5f)for(int k=0;k<3;k++)if(orbitVertices50[j+k*12+10]<.5f)orbitVertices50[j+k*12+10]+=1;}
   // Created once: no geometry generation or GPU allocation per frame.
   PlanetMesh far110=new PlanetMesh(1,6);orbitFarTerrain110=far110.TerrainVertices;orbitFarWater110=far110.WaterVertices;
   orbitFarVertices110=BuildFarOrbit110(far110);StartupLog.Write("v134 atlas resource initialization COMPLETE: "+timer134.ElapsedMilliseconds+" ms");
  }
  static float[] BuildFarOrbit110(PlanetMesh source){
   int n=source.TerrainVertices+source.WaterVertices;float[] result=new float[n*12];
   for(int v=0;v<n;v++){
    int j=v*12,k=v*10;
    for(int a=0;a<10;a++)result[j+a]=source.Vertices[k+a];
    PlanetMesh.P p=new PlanetMesh.P(result[j],result[j+1],result[j+2]);
    float radius=Math.Max(.0001f,p.Length);PlanetMesh.P dir=p*(1/radius);
    result[j+6]=result[j+7]=result[j+8]=1;
    result[j+10]=(float)(Math.Atan2(dir.Z,dir.X)/(2*Math.PI)+.5);
    result[j+11]=(float)(Math.Asin(dir.Y)/Math.PI+.5);
   }
   // Same seam handling as the full-resolution globe.
   for(int v=0;v<n;v+=3){int j=v*12;float lo=Math.Min(result[j+10],Math.Min(result[j+22],result[j+34])),hi=Math.Max(result[j+10],Math.Max(result[j+22],result[j+34]));if(hi-lo>.5f)for(int k=0;k<3;k++)if(result[j+k*12+10]<.5f)result[j+k*12+10]+=1;}
   return result;
  }
  void OrbitSurface50(){
   bool far=orbitFarActive110&&orbitFarVertices110!=null;
   float[] vertices=far?orbitFarVertices110:orbitVertices50;
   uint gpuBuffer=far?orbitFarBuffer110:orbitBuffer50;
   int terr=far?orbitFarTerrain110:orbitMesh52.TerrainVertices;
   int water=far?orbitFarWater110:orbitMesh52.WaterVertices;
   int count=terr+water;
   GCHandle pin=new GCHandle();IntPtr address=IntPtr.Zero;
   try{
    if(genBuffers!=null){
     if(gpuBuffer==0){genBuffers(1,out gpuBuffer);pin=GCHandle.Alloc(vertices,GCHandleType.Pinned);bindBuffer(0x8892,gpuBuffer);bufferData(0x8892,new IntPtr(vertices.Length*4),pin.AddrOfPinnedObject(),0x88E4);if(far){orbitFarBuffer110=gpuBuffer;OrbitFarUploads110++;}else{orbitBuffer50=gpuBuffer;OrbitUploads50++;}}
     else bindBuffer(0x8892,gpuBuffer);
    }else{pin=GCHandle.Alloc(vertices,GCHandleType.Pinned);address=pin.AddrOfPinnedObject();}
    enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);enableClient(0x8078);
    vertexPointer(3,0x1406,48,address);shipNormal(0x1406,48,new IntPtr(address.ToInt64()+12));colorPointer(4,0x1406,48,new IntPtr(address.ToInt64()+24));uvPointer(2,0x1406,48,new IntPtr(address.ToInt64()+40));
    enable(TEX);bindTexture(TEX,Texture(orbitTexture51));
    // v121: longitude repeats, latitude clamps at both poles.
    // Triangle UVs already unwrap the seam in PrepareOrbit50 / BuildFarOrbit110.
    texParameter(TEX,0x2802,0x2901);texParameter(TEX,0x2803,0x812F);
    if(orbitMipmap51!=null&&!orbitMipReady51){orbitMipmap51(TEX);orbitMipReady51=true;}
    if(orbitMipReady51)texParameter(TEX,0x2801,0x2703);
    BeginToon60(true,true);if(orbitMesh52.Basalt110)SetBasalt110(true,true);drawArrays(4,0,terr);EndToon60();
    if(water>0){BeginWater65(weatherTime65,true);drawArrays(4,terr,water);EndToon60();}
    disable(TEX);disableClient(0x8078);
    // Ground rocks are drawn from the separate, batched Life52 geometry buffer.
    DrawCalls+=water>0?2:1;SubmittedVertices+=count;
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);
    if(gpuBuffer!=0)bindBuffer(0x8892,0);
   }finally{if(pin.IsAllocated)pin.Free();}
  }

  void DrawOrbitLava114(){
   if(orbitLavaVertices114==null||orbitLavaVertices114.Length==0)return;
   GCHandle pinned=new GCHandle();IntPtr addr=IntPtr.Zero;
   try{
    if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){
     if(orbitLavaBuffer114==0){genBuffers(1,out orbitLavaBuffer114);pinned=GCHandle.Alloc(orbitLavaVertices114,GCHandleType.Pinned);bindBuffer(0x8892,orbitLavaBuffer114);bufferData(0x8892,new IntPtr(orbitLavaVertices114.Length*4),pinned.AddrOfPinnedObject(),0x88E4);OrbitLavaUploads114++;}
     else bindBuffer(0x8892,orbitLavaBuffer114);
    }else{pinned=GCHandle.Alloc(orbitLavaVertices114,GCHandleType.Pinned);addr=pinned.AddrOfPinnedObject();}
    disable(TEX);enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);
    vertexPointer(3,0x1406,40,addr);shipNormal(0x1406,40,new IntPtr(addr.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(addr.ToInt64()+24));
    shipMaterial(0x0408,0x1202,none);
    BeginLava113(weatherTime65);drawArrays(4,0,orbitLavaVertices114.Length/10);EndToon60();
    DrawCalls++;SubmittedVertices+=orbitLavaVertices114.Length/10;
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);
    if(orbitLavaBuffer114!=0)bindBuffer(0x8892,0);
   }finally{if(pinned.IsAllocated)pinned.Free();}
  }

  // v242: three tiny, emissive base lamps embedded in the real orbital globe,
  // at offsets from the hangar landing normal. Decorative only: no physics.
  void DrawAtlasLights242(float time){
   if(orbitMesh52==null||!orbitMesh52.OrbitAtlas242)return;
   IP beacon=OrbitWorld50.Beacon(1).Unit,side=IntroScene41.Cross(new IP(0,1,0),beacon).Unit;
   IP site=(beacon*132-side*90).Unit,r,f;PlanetLife52.Basis(site,out r,out f);
   disable(TEX);disable(0x0B50);disable(0x0B44);enable(DEPTH);depthMask(0);
   enable(BLEND);blendFunc(0x0302,1);
   begin(4);
   for(int k=0;k<3;k++){
    float a=1.1f+k*2.094395f,spread=.14f+(k==1?.05f:0);
    IP n=(site+r*((float)Math.Cos(a)*spread)+f*((float)Math.Sin(a)*spread)).Unit;
    float height=orbitMesh52.Height(new PlanetMesh.P(n.X,n.Y,n.Z))+.0038f;
    IP center=n*height,right,front;PlanetLife52.Basis(n,out right,out front);
    float pulse=.82f+.18f*(float)Math.Sin(time*(1.25f+k*.28f)+k*1.9f);
    for(int ring=0;ring<2;ring++){
     float rad=ring==0?.023f:.0075f;
     float alpha=(ring==0?.075f:.77f)*pulse;
     float red=k==2?1f:.35f,green=k==2?.59f:.79f,blue=k==2?.28f:1f;
     for(int j=0;j<16;j++){
      float t=j*(float)Math.PI/8f,u=(j+1)*(float)Math.PI/8f;
      IP x=center+right*((float)Math.Cos(t)*rad)+front*((float)Math.Sin(t)*rad);
      IP y=center+right*((float)Math.Cos(u)*rad)+front*((float)Math.Sin(u)*rad);
      color(red,green,blue,alpha);vertex(center.X,center.Y,center.Z);
      color(red,green,blue,0);vertex(x.X,x.Y,x.Z);
      color(red,green,blue,0);vertex(y.X,y.Y,y.Z);
     }
    }
   }
   end();DrawCalls++;SubmittedVertices+=3*2*16*3;
   disable(BLEND);depthMask(1);enable(0x0B50);
  }
  void OrbitLine50(IP a,IP b){vertex(a.X,a.Y,a.Z);vertex(b.X,b.Y,b.Z);SubmittedVertices+=2;}
  public void OrbitScene50(Game game,bool glow,bool nebula,bool rays){if(NewHome290.Enabled){HomeScene291(game,glow,nebula,rays);return;}weatherTime65=game.OrbitTime50;if(NewHome290.Enabled)PrepareNewHome290();else PrepareOrbit50();
   float distance110=game.OrbitCamera50.Length;
   // Hysteresis prevents LOD flapping while maintaining detailed terrain around SynixAd.
   if(!NewHome290.Enabled)orbitFarActive110=orbitFarActive110?distance110>198f:distance110>219f;
   PrepareIntroBelt();EnsureIntroPlanet(1);CraftType=game.ActiveCraft389;deepSpaceTime55=game.OrbitTime50;IP eye=game.OrbitCamera50,ship=game.OrbitPosition50,up=ship.Unit,forward=game.OrbitForward50;IP viewUp,aim53;game.OrbitAim53(out aim53,out viewUp);OrbitWorld50.View(eye,ship+aim53*13,viewUp,introView);Flush2D();clearColor(.012f,.021f,.04f,1);depthMask(1);clear(0x4000|0x0100);IntroSky(glow,nebula,rays,true);if(!NewHome290.Enabled)DrawMainWorldWreck208(glow);IntroProjection();enable(DEPTH);depthMask(1);disable(BLEND);disable(TEX);disable(0x0B44);FighterLight(false);LifeLighting52(game.OrbitTime50);UpdateBasaltSun111(game.OrbitTime50);shipMaterial(0x0408,0x1600,none);planetPush();shipScale(100,100,100);if(NewHome290.Enabled){DrawNewHome290();}else{ConfigureOrbitAtlas243(game.OrbitTime50);OrbitSurface50();DrawOrbitLava114();DrawLife52(game.OrbitTime50);DrawBaseLights243(game.OrbitTime50);DrawOrbitDust243(game.OrbitTime50);}orbitAtlasFx243=false;planetPop();planetPush();shipScale(3.2f,3.2f,3.2f);DrawIntroBelt(true);planetPop();
   // v223: the derelict uses the same time-dependent world sunlight as asteroids.
   FighterLight(false);LifeLighting52(game.OrbitTime50);
   DrawOrbitResearchWreck209();DrawTraffic52(game);DrawHubBeacon90(game);
   disable(0x0B50);disable(TEX);enable(BLEND);blendFunc(0x0302,1);depthMask(0);color(.26f,.7f,.8f,.32f);begin(1);for(int meridian=0;meridian<(NewHome290.Enabled?0:8);meridian++){float a=meridian*Game.PI/4;for(int j=0;j<96;j++){float lat=-Game.PI/2+j*Game.PI/96,next=lat+Game.PI/96;OrbitLine50(new IP((float)Math.Cos(lat)*(float)Math.Cos(a),(float)Math.Sin(lat),(float)Math.Cos(lat)*(float)Math.Sin(a))*108,new IP((float)Math.Cos(next)*(float)Math.Cos(a),(float)Math.Sin(next),(float)Math.Cos(next)*(float)Math.Sin(a))*108);}}for(int sign=NewHome290.Enabled?2:-1;sign<=1;sign+=2){float y=sign/3f,r=(float)Math.Sqrt(1-y*y);for(int j=0;j<128;j++){float a=j*Game.PI/64,b=a+Game.PI/64;OrbitLine50(new IP((float)Math.Cos(a)*r,y,(float)Math.Sin(a)*r)*108,new IP((float)Math.Cos(b)*r,y,(float)Math.Sin(b)*r)*108);}}
   for(int i=1;i<=Game.AtlasMissionCount276;i++){IP p=OrbitWorld50.Beacon(i),n=p.Unit;Color tint=game.MissionCompleted50(i)?Color.FromArgb(95,236,161):game.MissionUnlocked50(i)?Color.FromArgb(82,217,255):Color.FromArgb(110,124,139);color(tint.R/255f,tint.G/255f,tint.B/255f,i==game.OrbitTarget50?1:.6f);OrbitLine50(n*(NewHome290.Enabled?NewHome290.Surface(n)-1:108),p);IP right=IntroScene41.Cross(n,new IP(0,1,0)).Unit;if(right.Length<.1f)right=IntroScene41.Cross(n,new IP(1,0,0)).Unit;IP side=IntroScene41.Cross(n,right).Unit;for(int j=0;j<64;j++){float a=j*Game.PI/32,b=a+Game.PI/32,ring=i==game.OrbitTarget50?(NewHome290.Enabled?8f:26f):2.5f;OrbitLine50(p+(right*(float)Math.Cos(a)+side*(float)Math.Sin(a))*ring,p+(right*(float)Math.Cos(b)+side*(float)Math.Sin(b))*ring);}}
   end();DrawCalls++;depthMask(1);disable(BLEND);
   if(glow)MissionSignal58(game);else MissionSignalVertices58=0;FighterLight(false);planetPush();shipTranslate(ship.X,ship.Y,ship.Z);IP craftRight=(game.OrbitRight51-forward*IntroScene41.Dot(game.OrbitRight51,forward)).Unit;if(craftRight.Length<.1f)craftRight=IntroScene41.Cross(forward,Math.Abs(forward.Y)<.9f?new IP(0,1,0):new IP(1,0,0)).Unit;IP craftUp=IntroScene41.Cross(craftRight,forward).Unit;introCraft[0]=craftRight.X;introCraft[1]=craftRight.Y;introCraft[2]=craftRight.Z;introCraft[3]=0;introCraft[4]=forward.X;introCraft[5]=forward.Y;introCraft[6]=forward.Z;introCraft[7]=0;introCraft[8]=craftUp.X;introCraft[9]=craftUp.Y;introCraft[10]=craftUp.Z;introCraft[11]=0;introCraft[12]=introCraft[13]=introCraft[14]=0;introCraft[15]=1;planetMultiply(introCraft);shipRotate(game.OrbitBank50*180/Game.PI,0,1,0);planetPush();shipScale(OrbitShipScale472,OrbitShipScale472,OrbitShipScale472);DrawFighterMesh(game.OrbitTime50,game.Thrusting?1:.15f,game.SideThrust,false);DrawCraftModules95(game);planetPop();planetPop();
   if(game.MiningDetached389&&game.ShipType==Game.TransportShipType388){
    planetPush();shipTranslate(game.MiningCarrierOrbit389.X,game.MiningCarrierOrbit389.Y,game.MiningCarrierOrbit389.Z);
    IP f=game.MiningCarrierForward389,r=game.MiningCarrierRight389;
    IP u=IntroScene41.Cross(r,f).Unit;
    introCraft[0]=r.X;introCraft[1]=r.Y;introCraft[2]=r.Z;introCraft[3]=0;
    introCraft[4]=f.X;introCraft[5]=f.Y;introCraft[6]=f.Z;introCraft[7]=0;
    introCraft[8]=u.X;introCraft[9]=u.Y;introCraft[10]=u.Z;introCraft[11]=0;
    introCraft[12]=introCraft[13]=introCraft[14]=0;introCraft[15]=1;
    planetMultiply(introCraft);CraftType=7;DrawFighterMesh(game.OrbitTime50,.10f,0,false);planetPop();
   }
   // v256: illuminated limb at the true planet radius; no planetary fog.
   if(glow)DrawAtmosphere47(new PlanetCrawler.P(),new PlanetCrawler.P(eye.X,eye.Y,eye.Z),NewHome290.Enabled?137f:100f);disable(0x0B50);disable(0x0B57);disable(0x0BA1);disable(0x4000);disable(0x4001);disable(0x0B44);shipMaterial(0x0408,0x1600,none);Begin2D();for(int i=0;i<Game.AtlasMissionCount276;i++){IP p=OrbitWorld50.Beacon(i+1);float depth;beaconVisible50[i]=OrbitWorld50.Visible(eye,p)&&IntroProject(p,out beaconScreens50[i],out depth);}
  }
  public void OrbitNavigation50(Canvas c,Game game){for(int i=0;i<Game.AtlasMissionCount276;i++)if(beaconVisible50[i]){PointF p=beaconScreens50[i];if(p.X>20&&p.X<1260&&p.Y>250&&p.Y<625)c.DrawString((i+1).ToString("00"),SystemFonts.DefaultFont,Brushes.White,new RectangleF(p.X-20,p.Y-12,40,24),StringFormat.GenericDefault);}
   if(game.OrbitMissionReady51)return;IP goal=OrbitWorld50.Beacon(game.OrbitTarget50);PointF pgoal;float depth;bool visible=IntroProject(goal,out pgoal,out depth)&&OrbitWorld50.Visible(game.OrbitCamera50,goal);
   if(!visible){IP route=OrbitWorld50.Route51(game.OrbitPosition50,game.OrbitTarget50);goal=game.OrbitPosition50+route*36+game.OrbitPosition50.Unit*3;IntroProject(goal,out pgoal,out depth);}
   float dx=pgoal.X-640,dy=pgoal.Y-360;if(depth<=.4f){IP route=OrbitWorld50.Route51(game.OrbitPosition50,game.OrbitTarget50);dx=(introView[0]*route.X+introView[4]*route.Y+introView[8]*route.Z)*500;dy=-(introView[1]*route.X+introView[5]*route.Y+introView[9]*route.Z)*245;if(Math.Abs(dx)+Math.Abs(dy)<20)dx=500;}
   float scale=Math.Max(1,Math.Max(Math.Abs(dx)/540,Math.Abs(dy)/245));float x=640+dx/scale,y=360+dy/scale;y=Math.Max(255,Math.Min(605,y));float len=(float)Math.Sqrt(dx*dx+dy*dy);if(len<1){dx=0;dy=-1;len=1;}dx/=len;dy/=len;Color col=Color.FromArgb(110,240,255);PointF tip=new PointF(x+dx*14,y+dy*14),left=new PointF(x-dx*9-dy*9,y-dy*9+dx*9),right=new PointF(x-dx*9+dy*9,y-dy*9-dx*9);Line2D(left,tip,col,3);Line2D(tip,right,col,3);Line2D(left,right,col,2);c.DrawString("CEL "+game.OrbitTarget50.ToString("00"),SystemFonts.DefaultFont,Brushes.Cyan,new RectangleF(x-30,y+20,80,24),StringFormat.GenericDefault);
  }
  void DisposeOrbit50(){DisposeNewHome290();DisposeLife52();if(orbitLavaBuffer114!=0){deleteBuffers(1,ref orbitLavaBuffer114);orbitLavaBuffer114=0;}orbitLavaVertices114=null;if(orbitBuffer50!=0){deleteBuffers(1,ref orbitBuffer50);orbitBuffer50=0;}orbitVertices50=null;orbitFarVertices110=null;if(orbitFarBuffer110!=0){deleteBuffers(1,ref orbitFarBuffer110);orbitFarBuffer110=0;}orbitFarActive110=false;if(orbitTexture51!=null){orbitTexture51.Dispose();orbitTexture51=null;}}
 }
}
