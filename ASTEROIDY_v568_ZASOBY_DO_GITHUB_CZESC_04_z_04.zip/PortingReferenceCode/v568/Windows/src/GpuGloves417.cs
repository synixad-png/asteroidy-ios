// Asteroidy v417: independent GPU viewmodel of both supplied GLBs.
// GPU draws are separate from the hangar's world depth; original models retain every face.
using System;
using System.IO;
using System.IO.Compression;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  public GlovesSettings417 GloveConfig417;
  uint[] gloveBuffers417=new uint[2];
  uint[] gloveRigBuffers426=new uint[2];
  int gloveRigAttrib426=-1;
  AttribPointer75 gloveRigPointer426; U gloveRigEnable426,gloveRigDisable426;
  int[,] gloveCount417=new int[2,2];
  int[,] gloveStart417=new int[2,2];
  public int GlovePreviewMode420; public int GloveSelected420=-1; public int GloveHover423=-1;
  uint gloveShader417;
  int gloveTexLoc417=-1,gloveMrLoc417=-1,gloveHasTex417=-1,gloveTimeLoc417=-1,gloveSelect420=-1;
  // v429 reuses the ALREADY EXISTING engine settings; these are not a second
  // material configuration. The same controls affect the live preview and FPS view.
  int glovePolishLoc429=-1,glovePbrLoc429=-1,gloveRimLoc429=-1,glovePbrOnLoc429=-1,gloveRimOnLoc429=-1;
  int curlLoc425=-1, modelLoc425=-1, handLoc425=-1;
  int rigBonesLoc428=-1, rigBoundsLoc428=-1;
  GloveUniformMatrix4fv428 matrix4fv428;GloveUniform4fv428 vector4fv428;
  delegate void GloveUniformMatrix4fv428(int loc,int count,byte transpose,float[] data);
  delegate void GloveUniform4fv428(int loc,int count,float[] data);
  public float FingerPreviewTime425=-1f;
  Bitmap[] gloveBase417=new Bitmap[1],gloveMr417=new Bitmap[1];
  bool[] gloveFailed417=new bool[2];
  int[] gloveUploads417=new int[2];
  public int GloveDraws417{get;private set;}
  public int[] GloveUploads417{get{return gloveUploads417;}}
  static byte[] ReadGloveAsset417(string name){
   using(Stream s=Assembly.GetExecutingAssembly().GetManifestResourceStream(name)){
    if(s==null)throw new InvalidDataException("Brakuje zasobu rękawic: "+name);
    using(MemoryStream m=new MemoryStream()){s.CopyTo(m);return m.ToArray();}
   }
  }
  static Bitmap GloveImage417(string name){
   byte[] raw=ReadGloveAsset417(name);
   using(MemoryStream stream=new MemoryStream(raw))using(Bitmap temp=new Bitmap(stream))return new Bitmap(temp);
  }
  bool EnsureGloveModel417(int model){
   if(gloveBuffers417[model]!=0)return true;
   if(gloveFailed417[model])return false;
   try{
    byte[] raw=ReadGloveAsset417(model==0?"Asteroidy.Gloves417.Parted":"Asteroidy.Gloves417.Monolith");
    using(MemoryStream input=new MemoryStream(raw))using(GZipStream zip=new GZipStream(input,CompressionMode.Decompress))using(BinaryReader read=new BinaryReader(zip)){
     if(System.Text.Encoding.ASCII.GetString(read.ReadBytes(8))!="GLV41700")throw new InvalidDataException("Nagłówek danych rękawic");
     int left=read.ReadInt32(),right=read.ReadInt32();
     if(left<=0||right<=0||left+right>1000000||left%3!=0||right%3!=0)throw new InvalidDataException("Liczba wierzchołków rękawic");
     float[] vertices=new float[(left+right)*11];
     byte[] floats=read.ReadBytes(vertices.Length*4);
     if(floats.Length!=vertices.Length*4||read.BaseStream.ReadByte()!=-1)throw new InvalidDataException("Długość danych rękawic");
     Buffer.BlockCopy(floats,0,vertices,0,floats.Length);
     if(genBuffers==null||bindBuffer==null||bufferData==null)throw new InvalidOperationException("OpenGL VBO niedostępne");
     GCHandle pinned=GCHandle.Alloc(vertices,GCHandleType.Pinned);
     try{
      genBuffers(1,out gloveBuffers417[model]);bindBuffer(0x8892,gloveBuffers417[model]);
      bufferData(0x8892,new IntPtr(floats.Length),pinned.AddrOfPinnedObject(),0x88E4);
      bindBuffer(0x8892,0);
     }finally{pinned.Free();}
     // MONOLIT GLB is separated on original Y; its geometric halves are
     // opposite the anatomical left/right assignment of TRIPO PBR.
     // Swap only the monolith VBO ranges; keep model 0 and all user poses untouched.
     gloveStart417[model,0]=model==1?left:0;gloveCount417[model,0]=model==1?right:left;
     gloveStart417[model,1]=model==1?0:left;gloveCount417[model,1]=model==1?left:right;
     // Companion per-vertex finger influence streams: independent of original GLB data.
     byte[] rigRaw=ReadGloveAsset417(model==0?"Asteroidy.Gloves426.RigTripo":"Asteroidy.Gloves426.RigMonolit");
     using(MemoryStream rigInput=new MemoryStream(rigRaw))
     using(GZipStream rigZip=new GZipStream(rigInput,CompressionMode.Decompress))
     using(BinaryReader rigReader=new BinaryReader(rigZip)){
      if(System.Text.Encoding.ASCII.GetString(rigReader.ReadBytes(8))!="GLV42600")throw new InvalidDataException("Rig426 signature");
      int rl=rigReader.ReadInt32(),rr=rigReader.ReadInt32();
      if(rl!=left||rr!=right)throw new InvalidDataException("Rig426 finger weights count mismatch");
      byte[] rigBytes=rigReader.ReadBytes((left+right)*16);
      if(rigBytes.Length!=(left+right)*16||rigReader.BaseStream.ReadByte()!=-1)throw new InvalidDataException("Rig426 finger stream size");
      GCHandle rigPin=GCHandle.Alloc(rigBytes,GCHandleType.Pinned);
      try{
       genBuffers(1,out gloveRigBuffers426[model]);bindBuffer(0x8892,gloveRigBuffers426[model]);
       bufferData(0x8892,new IntPtr(rigBytes.Length),rigPin.AddrOfPinnedObject(),0x88E4);
       bindBuffer(0x8892,0);
      }finally{rigPin.Free();}
     }
     gloveUploads417[model]++;
     gpuLog66("GLOVES v417: model "+model+" uploaded GPU hands "+left+" / "+right+", original glTF triangles preserved");
    }
    if(model==0){gloveBase417[0]=GloveImage417("Asteroidy.Gloves417.Base");gloveMr417[0]=GloveImage417("Asteroidy.Gloves417.MR");}
    return true;
   }catch(Exception ex){gloveFailed417[model]=true;gpuLog66("GLOVES v417 load failed for model "+model+": "+ex);return false;}
  }
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]
  delegate int GloveAttribLocation426(uint program,[MarshalAs(UnmanagedType.LPStr)]string name);
  void BindGloveRig426(int model){
   bindBuffer(0x8892,gloveRigBuffers426[model]);
   gloveRigEnable426((uint)gloveRigAttrib426);
   gloveRigPointer426((uint)gloveRigAttrib426,4,0x1406,0,16,IntPtr.Zero);
   bindBuffer(0x8892,gloveBuffers417[model]);
  }
  void UnbindGloveRig426(){
   if(gloveRigAttrib426>=0&&gloveRigDisable426!=null)gloveRigDisable426((uint)gloveRigAttrib426);
  }
  bool EnsureGloveShader417(){
   if(gloveShader417!=0)return true;
   try{
    var r=introResolve135;
    var create=Fn<CreateShader60>(r,"glCreateShader");var source=Fn<Source60>(r,"glShaderSource");
    var compile=Fn<U>(r,"glCompileShader");var statusShader=Fn<Status60>(r,"glGetShaderiv");
    var logShader=Fn<Log60>(r,"glGetShaderInfoLog");var delShader=Fn<U>(r,"glDeleteShader");
    var createProgram=Fn<CreateProgram60>(r,"glCreateProgram");var attach=Fn<UU>(r,"glAttachShader");
    var link=Fn<U>(r,"glLinkProgram");var statusProg=Fn<Status60>(r,"glGetProgramiv");
    var logProg=Fn<Log60>(r,"glGetProgramInfoLog");
    const string vs=@"#version 120
attribute vec4 rig426; // finger id, soft influence, joint-centre transverse Y, transverse Z
varying vec3 eyeN;varying vec3 eyeP;varying vec2 uv;varying vec3 tone;
uniform vec4 fingerCurl425;uniform vec2 fingerExtra425;
uniform int gloveModel425;
uniform mat4 fingerBones428[15];
uniform vec4 fingerBounds428[5];
float selectCurl426(float id){
 if(id<0.5)return fingerCurl425.x;
 if(id<1.5)return fingerCurl425.y;
 if(id<2.5)return fingerCurl425.z;
 if(id<3.5)return fingerCurl425.w;
 return fingerExtra425.x;
}
vec3 animateFingers425(vec3 original){
 float influence=clamp(rig426.y,0.0,1.0)*clamp(fingerExtra425.y,0.0,1.0);
 if(influence<0.00001)return original;
 int digit=int(clamp(floor(rig426.x+0.5),0.0,4.0));
 vec3 p=gloveModel425==0?vec3(original.y,original.x,original.z):vec3(-original.x,original.y,original.z);
 // Localized to the individual finger's transverse centre, rather than
 // bending all fingers around the world origin.
 vec3 q=vec3(p.x,p.y-rig426.z,p.z-rig426.w);
 vec4 v=vec4(q,1.0);
 vec4 bounds=fingerBounds428[digit];
 float s1=smoothstep(bounds.y-0.012,bounds.y+0.017,p.x);
 float s2=smoothstep(bounds.z-0.010,bounds.z+0.014,p.x);
 int offset=digit*3;
 vec3 b0=(fingerBones428[offset]*v).xyz;
 vec3 b1=(fingerBones428[offset+1]*v).xyz;
 vec3 b2=(fingerBones428[offset+2]*v).xyz;
 vec3 skinned=mix(mix(b0,b1,s1),b2,s2);
 vec3 finalP=mix(q,skinned,influence)+vec3(0.0,rig426.z,rig426.w);
 return gloveModel425==0?vec3(finalP.y,finalP.x,finalP.z):vec3(-finalP.x,finalP.y,finalP.z);
}
void main(){vec3 original=gl_Vertex.xyz;vec3 animated=animateFingers425(original);
 vec4 p=gl_ModelViewMatrix*vec4(animated,1.0);eyeP=p.xyz;
 vec3 nearby=animateFingers425(original+gl_Normal.xyz*0.004);
 eyeN=normalize(gl_NormalMatrix*normalize(nearby-animated));
 uv=gl_MultiTexCoord0.st;tone=gl_Color.rgb;gl_Position=gl_ProjectionMatrix*p;}";
    const string fs=@"#version 120
uniform sampler2D baseTex;uniform sampler2D mrTex;uniform int hasTex;uniform float frameTime;uniform int isSelected420;
// The actual global Graphics menu (v395 / v106) controls glove PBR too.
uniform float glovePolish429,glovePbr429,gloveRim429;
uniform int glovePbrOn429,gloveRimOn429;
varying vec3 eyeN;varying vec3 eyeP;varying vec2 uv;varying vec3 tone;
float Dggx(float nh,float rough){float a=rough*rough;float a2=a*a;float d=nh*nh*(a2-1.0)+1.0;return a2/(3.14159265*d*d+0.0001);}
void main(){vec3 base=tone;float metal=0.08,rough=0.66;
 if(hasTex==1){base*=pow(texture2D(baseTex,uv).rgb,vec3(2.2));vec3 mr=texture2D(mrTex,uv).rgb;metal=mr.b;rough=clamp(mr.g,0.19,1.0);}
 // Existing global polished-metal control, 0 = original material.
 float polish=clamp(glovePolish429,0.0,1.0);
 metal=mix(metal,max(metal,0.93),polish);
 rough=mix(rough,max(0.09,rough*0.18),polish);
 vec3 n=normalize(eyeN);if(!gl_FrontFacing)n=-n;
 vec3 v=normalize(-eyeP);vec3 l=normalize(vec3(-0.56,0.84,0.75));vec3 h=normalize(l+v);
 float ndl=max(dot(n,l),0.0),ndv=max(dot(n,v),0.001),ndh=max(dot(n,h),0.0),vdh=max(dot(v,h),0.0);
 vec3 f0=mix(vec3(0.045),base,metal);vec3 F=f0+(vec3(1.0)-f0)*pow(1.0-vdh,5.0);
 float D=Dggx(ndh,rough);float k=pow(rough+1.0,2.0)/8.0;
 float G=(ndv/(ndv*(1.0-k)+k))*(ndl/(ndl*(1.0-k)+k));
 vec3 brdf=F*D*G/(4.0*ndv*ndl+0.002);
 vec3 fill=base*(0.20+0.22*max(n.y,0.0));
 float brdfLevel=(glovePbrOn429==1)?clamp(glovePbr429,0.0,1.0)*2.0:0.0;
 vec3 c=fill+(base*(1.0-metal)/3.14159+brdf*brdfLevel)*ndl*vec3(2.1,2.3,2.65);
 vec3 lamp=normalize(vec3(0.8,0.25,0.65));vec3 rh=normalize(lamp+v);
 c+=vec3(0.5,0.75,1.0)*pow(max(dot(n,rh),0.0),mix(48.0,140.0,1.0-rough))*mix(0.04,0.54,metal)*brdfLevel;
 if(gloveRimOn429==1)c+=vec3(0.33,0.56,0.76)*pow(1.0-ndv,3.0)*0.36*clamp(gloveRim429,0.0,1.0);
 if(isSelected420==1)c+=vec3(0.08,0.22,0.34)*pow(1.0-ndv,2.0);
 // v489: polished metal must have a room reflection, as in H55Renderer v395.
 // Without it, raising metallic merely removes diffuse colour unless a point light aligns with the normal.
 // At polish=0 this is exactly zero, retaining original viewmodel material and v487 live lighting.
 vec3 refl=reflect(-v,n);
 float width489=max(0.045,0.12+rough*0.24);
 float boxA489=exp(-pow((refl.y-0.70)/width489,2.0));
 float boxB489=exp(-pow((refl.x+0.62)/(width489*0.78),2.0))*smoothstep(-0.4,0.5,refl.y);
 float boxC489=pow(max(0.0,dot(refl,normalize(vec3(0.16,0.66,0.73)))),max(6.0,55.0*(1.0-rough)));
 vec3 room489=vec3(0.22,0.31,0.45)*(0.20+0.65*max(0.0,refl.y))
    +vec3(3.0,2.8,2.54)*boxA489+vec3(0.65,1.4,2.25)*boxB489
    +vec3(1.9,1.85,1.6)*boxC489;
 vec3 fresnel489=f0+(vec3(1.0)-f0)*pow(1.0-ndv,5.0);
 vec3 reflected489=room489*fresnel489*(1.0-rough*0.60)*polish*(0.35+0.65*metal);
 c+=reflected489;
 c=c/(1.0+c);c=pow(c,vec3(1.0/2.2));gl_FragColor=vec4(c,1.0);
}";
    gloveShader417=BuildPostProgram103(vs,fs,create,source,compile,statusShader,logShader,delShader,createProgram,attach,link,statusProg,logProg);
    var loc=Fn<Location60>(r,"glGetUniformLocation");
    gloveTexLoc417=loc(gloveShader417,"baseTex");gloveMrLoc417=loc(gloveShader417,"mrTex");gloveHasTex417=loc(gloveShader417,"hasTex");gloveTimeLoc417=loc(gloveShader417,"frameTime");gloveSelect420=loc(gloveShader417,"isSelected420");
    glovePolishLoc429=loc(gloveShader417,"glovePolish429");glovePbrLoc429=loc(gloveShader417,"glovePbr429");gloveRimLoc429=loc(gloveShader417,"gloveRim429");
    glovePbrOnLoc429=loc(gloveShader417,"glovePbrOn429");gloveRimOnLoc429=loc(gloveShader417,"gloveRimOn429");
    if(glovePolishLoc429<0||glovePbrLoc429<0||gloveRimLoc429<0||glovePbrOnLoc429<0||gloveRimOnLoc429<0)
     throw new InvalidOperationException("v429 existing PBR/RIM/polish uniforms missing");
    curlLoc425=loc(gloveShader417,"fingerCurl425");modelLoc425=loc(gloveShader417,"gloveModel425");handLoc425=loc(gloveShader417,"gloveHand425");extraLoc425=loc(gloveShader417,"fingerExtra425");
    var rigAttrLoc426=Fn<GloveAttribLocation426>(r,"glGetAttribLocation");
    gloveRigAttrib426=rigAttrLoc426(gloveShader417,"rig426");
    rigBonesLoc428=loc(gloveShader417,"fingerBones428[0]");
    rigBoundsLoc428=loc(gloveShader417,"fingerBounds428[0]");
    if(rigBonesLoc428<0||rigBoundsLoc428<0)throw new InvalidOperationException("V428 bone uniforms missing");
    matrix4fv428=Fn<GloveUniformMatrix4fv428>(r,"glUniformMatrix4fv");
    vector4fv428=Fn<GloveUniform4fv428>(r,"glUniform4fv");
    if(gloveRigAttrib426<0)throw new InvalidOperationException("Rig426 vertex shader attribute missing");
    gloveRigPointer426=Fn<AttribPointer75>(r,"glVertexAttribPointer");
    gloveRigEnable426=Fn<U>(r,"glEnableVertexAttribArray");
    gloveRigDisable426=Fn<U>(r,"glDisableVertexAttribArray");
    return true;
   }catch(Exception ex){gpuLog66("GLOVES v417 GPU shader fail: "+ex);return false;}
  }
  void ApplyExistingGloveMaterial429(){
   // All settings are already shared by Renderer.Draw and Program.cs.
   // No extra per-glove settings or second shader is created.
   waterFloat65(glovePolishLoc429,0.40f); // v490: glove baseline independent of the weapon-only F8 metal slider
   waterFloat65(glovePbrLoc429,Math.Max(0,Math.Min(100,AdvancedPower106[0]))*0.01f);
   waterFloat65(gloveRimLoc429,Math.Max(0,Math.Min(100,AdvancedPower106[1]))*0.01f);
   uniform60(glovePbrOnLoc429,AdvancedOn106[0]?1:0);
   uniform60(gloveRimOnLoc429,AdvancedOn106[1]?1:0);
  }
  // v430: Walking sway depends ONLY on the user's BOB setting and actual
  // grounded movement. Finger articulation is completely independent.
  // Both the live H72 viewmodel and the editor preview use this formula.
  // Bob input is already damped by HubWalkUpdate400 and derived from actual
  // distance covered, so a blocked player does not shake in place.
  public static void GloveWalkOffsets430(float phase,float movement,float visualIntensity,int hand,
                                          out float x,out float y,out float yaw){
   float strength=Math.Max(0f,Math.Min(1.4f,movement))*Math.Max(0f,Math.Min(1f,visualIntensity));
   float alternating=phase+(hand==0?0f:(float)Math.PI);
   x=(float)Math.Sin(alternating)*.019f*strength;
   y=(float)Math.Sin(alternating*2f)*.011f*strength;
   yaw=(float)Math.Sin(alternating)*1.35f*strength;
  }
  public void RenderGloves417(Game game){
   GlovesSettings417 setting=GloveConfig417;
   if(setting==null||!setting.Enabled||!game.HubWalk375||game.HubArriving92)return;
   if(!setting.Visible[0]&&!setting.Visible[1])return;
   int model=setting.Model;
   if(!EnsureGloveModel417(model)||!EnsureGloveShader417())return;
   Flush2D();
   // Viewmodel draws AFTER the hangar post-process, with its own depth and FOV.
   // Never clear world colour or alter the gameplay collision system.
   enable(DEPTH);depthMask(1);clear(0x0100);disable(BLEND);disable(0x0B50);disable(0x0BA1);disable(0x0B57);
   matrixMode(0x1701);loadIdentity();
   const float near=0.06f;float half=near*(float)Math.Tan(GloveFov422*Math.PI/360.0);
   frustum(-half*1.7777778,half*1.7777778,-half,half,near,20);
   matrixMode(0x1700);loadIdentity();
   useToon60(gloveShader417);
   ApplyExistingGloveMaterial429();
   uniform60(gloveHasTex417,model==0?1:0);
   if(modelLoc425>=0)uniform60(modelLoc425,model);
   if(gloveTimeLoc417>=0)waterFloat65(gloveTimeLoc417,game.HubTime90);
   if(gloveSelect420>=0)uniform60(gloveSelect420,0);
   if(model==0){
    activeTexture103(TEXTURE0_103);enable(TEX);bindTexture(TEX,Texture(gloveBase417[0]));uniform60(gloveTexLoc417,0);
    activeTexture103(TEXTURE0_103+1);enable(TEX);bindTexture(TEX,Texture(gloveMr417[0]));uniform60(gloveMrLoc417,1);
    activeTexture103(TEXTURE0_103);
   }
   BindGloveRig426(model);
   enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);enableClient(0x8078);
   vertexPointer(3,0x1406,44,IntPtr.Zero);
   shipNormal(0x1406,44,new IntPtr(12));
   uvPointer(2,0x1406,44,new IntPtr(24));
   colorPointer(3,0x1406,44,new IntPtr(32));
   // Hand sway and finger articulation are separate independent systems.
   // v429 incorrectly conditioned entire hand motion on !FingerAnimation425.
   float walking430=setting.Bob?game.HubWalkBobAmount400:0f;
   float intensity430=HangarBob400*.01f;
   for(int hand=0;hand<2;hand++){
    if(!setting.Visible[hand])continue;
    float sway,step,yaw;
    GloveWalkOffsets430(game.HubWalkBobPhase400,walking430,intensity430,hand,out sway,out step,out yaw);
    // Optional breathing at rest remains subtle and independent of finger motion.
    float idle=setting.IdleMotion?(float)Math.Sin(game.HubTime90*0.82f+hand*1.3f)*0.003f:0f;
    ApplyFingerUniform425(setting,game.HubTime90,hand);
    UploadSkeletalRig428(setting,game.HubTime90,hand);
    planetPush();
    ApplyGlovePose422(setting,hand,sway,step,idle,yaw);
    drawArrays(4,gloveStart417[model,hand],gloveCount417[model,hand]);
    SubmittedVertices+=gloveCount417[model,hand];DrawCalls++;GloveDraws417++;
    planetPop();
   }
   disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);disableClient(0x8078);
   UnbindGloveRig426();bindBuffer(0x8892,0);useToon60(0);
   activeTexture103(TEXTURE0_103+1);bindTexture(TEX,0);disable(TEX);
   activeTexture103(TEXTURE0_103);bindTexture(TEX,0);disable(TEX);
   disable(DEPTH);depthMask(1);Begin2D();
  }
  // Native, live 3D preview inside W3 / RĘKAWICE settings. This uses the SAME
  // VBO, GLSL material and independent hand transforms as the walking viewmodel.
  // v421: editing uses a 3D proxy hand with five solid fingers, NOT the full GLB.
  // v424: the preview renders the actual, ORIGINAL model VBO and shader, NOT the
  // approximate proxy. Proxy meshes remain exclusively as fast click/picking colliders.
  // There is exactly one camera/FOV and one ApplyGlovePose422 transform for editor and game.
  public void RenderGlovesPreview417(GlovesSettings417 setting){RenderGlovesReal424(setting);}
  public void RenderGlovesReal424(GlovesSettings417 setting){
   if(setting==null||!setting.Enabled)return;
   int model=setting.Model;
   if(!EnsureGloveModel417(model)||!EnsureGloveShader417())return;
   Flush2D();
   int vx=viewX,vy=outputH-viewY-viewH,vw=viewW,vh=viewH;
   int px=vx+(int)(GlovePreviewX422*vw/1280f);
   int py=vy+(int)((720f-GlovePreviewY422-GlovePreviewH422)*vh/720f);
   int pw=Math.Max(1,(int)(GlovePreviewW422*vw/1280f));
   int ph=Math.Max(1,(int)(GlovePreviewH422*vh/720f));
   try{
    viewport(px,py,pw,ph);
    enable(DEPTH);depthMask(1);clear(0x0100);disable(BLEND);
    disable(0x0B50);disable(0x0BA1);disable(0x0B57);
    matrixMode(0x1701);loadIdentity();
    const float near=.06f;float half=near*(float)Math.Tan(GloveFov422*Math.PI/360.0);
    // The inset is exactly 16:9, the very same viewmodel camera as H72.
    frustum(-half*GlovePreviewW422/GlovePreviewH422,half*GlovePreviewW422/GlovePreviewH422,-half,half,near,20);
    matrixMode(0x1700);loadIdentity();
    useToon60(gloveShader417);ApplyExistingGloveMaterial429();uniform60(gloveHasTex417,model==0?1:0);
    if(modelLoc425>=0)uniform60(modelLoc425,model);
    if(gloveTimeLoc417>=0)waterFloat65(gloveTimeLoc417,0);
    if(model==0){
     activeTexture103(TEXTURE0_103);enable(TEX);bindTexture(TEX,Texture(gloveBase417[0]));uniform60(gloveTexLoc417,0);
     activeTexture103(TEXTURE0_103+1);enable(TEX);bindTexture(TEX,Texture(gloveMr417[0]));uniform60(gloveMrLoc417,1);
     activeTexture103(TEXTURE0_103);
    }
    BindGloveRig426(model);
    enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);enableClient(0x8078);
    vertexPointer(3,0x1406,44,IntPtr.Zero);
    shipNormal(0x1406,44,new IntPtr(12));
    uvPointer(2,0x1406,44,new IntPtr(24));
    colorPointer(3,0x1406,44,new IntPtr(32));
    for(int hand=0;hand<2;hand++){
     if(!setting.Visible[hand])continue;
     float sway,lift,idle,yaw;
     ProxyPreviewMotion421(hand,setting,out sway,out lift,out idle,out yaw);
     if(gloveSelect420>=0)uniform60(gloveSelect420,(GloveSelected420==hand||GloveSelected420==2||GloveHover423==hand)?1:0);
     float fingerTime428=FingerPreviewTime425>=0?FingerPreviewTime425:(float)(Environment.TickCount/1000.0);
     ApplyFingerUniform425(setting,fingerTime428,hand);
     UploadSkeletalRig428(setting,fingerTime428,hand);
     planetPush();
     // Preview movement must not disappear when fingers are animated.
     ApplyGlovePose422(setting,hand,sway,lift,idle,yaw);
     drawArrays(4,gloveStart417[model,hand],gloveCount417[model,hand]);
     planetPop();DrawCalls++;GloveDraws417++;
    }
   }finally{
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);disableClient(0x8078);
    UnbindGloveRig426();bindBuffer(0x8892,0);useToon60(0);
    activeTexture103(TEXTURE0_103+1);bindTexture(TEX,0);disable(TEX);
    activeTexture103(TEXTURE0_103);bindTexture(TEX,0);disable(TEX);
    depthMask(1);disable(DEPTH);viewport(vx,vy,vw,vh);Begin2D();
   }
  }
  // v425: smooth finger-only cycle; no animated skeleton is falsely assumed in the source GLB.
  // Using available OpenGL uniforms avoids CPU updates to 200k triangles every frame.
  static float Ease425(float v){v=Math.Max(0,Math.Min(1,v));return v*v*(3-2*v);}
  public static float[] FingerPose425(float time,float period,float maxCurl,int hand){
   // v427: fingers close in a slightly staggered sequence, linger briefly and
   // reopen; the wrist/palm never moves. Small, desynchronised microflexes
   // replace the visibly repetitive simultaneous five-finger pulse.
   float cycle=((time+hand*.81f)/Math.Max(2f,period));cycle-=(float)Math.Floor(cycle);
   float[] amplitudes={.72f,.89f,1.00f,.95f,.78f};
   float[] delays={.040f,.015f,0f,.022f,.049f};
   float[] outPose=new float[5];
   for(int i=0;i<5;i++){
    float shift=delays[i];
    float close=Ease425((cycle-(.34f+shift))/.16f);
    float open=Ease425((cycle-(.62f+shift*.35f))/.22f);
    float grip=close*(1f-open);
    float idle=.025f+.020f*(float)Math.Sin(time*(.42f+i*.07f)+i*1.7f+hand*.8f);
    outPose[i]=Math.Max(0,Math.Min(1,(grip*amplitudes[i]+idle*(1f-grip))*maxCurl));
   }
   return outPose;
  }
  void ApplyFingerUniform425(GlovesSettings417 config,float time,int hand){
   if(modelLoc425>=0)uniform60(modelLoc425,config.Model);
   if(handLoc425>=0)uniform60(handLoc425,hand);
   bool on=config.FingerAnimation425;
   float[] pose=on?FingerPose425(time,config.FingerPeriod425/10f,config.FingerIntensity425/100f,hand):new float[5];
   if(on&&FingerPreviewTime425>=0){
    if(config.FingerTestPose425==1){for(int i=0;i<5;i++)pose[i]=config.FingerIntensity425/100f;}
    if(config.FingerTestPose425==2){for(int i=0;i<5;i++)pose[i]=0;}
   }
   // vec4 + vec2 OpenGL 2.1 uniform setters (GLSL 1.20).
   if(curlLoc425>=0)Finger4f425(curlLoc425,pose[0],pose[1],pose[2],pose[3]);
   if(extraLoc425>=0)Finger2f425(extraLoc425,pose[4],on?1f:0f);
  }
  // v428: three real bind-pose-aware skeletal matrices for each finger, calculated
  // every frame on the CPU. The GLSL shader applies linear blend skinning to
  // the original glTF vertices using the existing per-vertex anatomical zones.
  // The palm, wrist, material UVs and per-model transforms remain untouched.
  static float[] Identity428(){return new float[]{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};}
  static float[] Multiply428(float[] a,float[] b){
   float[] c=new float[16];
   for(int col=0;col<4;col++)for(int row=0;row<4;row++){
    float v=0;for(int k=0;k<4;k++)v+=a[k*4+row]*b[col*4+k];
    c[col*4+row]=v;
   }
   return c;
  }
  static float[] Pivot428(float x,float radians){
   // Y-axis rotation around a real rest-pose joint centre at local (x,0,0).
   float c=(float)Math.Cos(radians),s=(float)Math.Sin(radians);
   float[] m=Identity428();
   m[0]=c;m[2]=-s;m[8]=s;m[10]=c;
   m[12]=x*(1f-c);m[14]=x*s;
   return m;
  }
  public static float[] FingerSkeleton428(float[] curl,int model,out float[] bounds){
   bounds=new float[20];float[] all=new float[15*16];
   for(int i=0;i<5;i++){
    // Different segment lengths for little/thumb fingers. These are
    // calibrated to the ORIGINAL gloves' vertex-space dimensions.
    float ratio=i==0?.80f:i==4?.82f:i==1?.93f:1f;
    float root=model==0?.028f:.082f;
    float pip=root+(model==0?.041f:.103f)*ratio;
    float dip=pip+(model==0?.039f:.109f)*ratio;
    float c=Math.Max(0,Math.Min(1,curl[i]));
    float a0=-c*(i==0?.17f:.24f);
    float a1=-c*(i==0?.22f:.32f);
    float a2=-c*(i==0?.16f:.24f);
    float[] b0=Pivot428(root,a0);
    float[] b1=Multiply428(b0,Pivot428(pip,a1));
    float[] b2=Multiply428(b1,Pivot428(dip,a2));
    Array.Copy(b0,0,all,(i*3)*16,16);
    Array.Copy(b1,0,all,(i*3+1)*16,16);
    Array.Copy(b2,0,all,(i*3+2)*16,16);
    bounds[i*4]=root;bounds[i*4+1]=pip;bounds[i*4+2]=dip;bounds[i*4+3]=1;
   }
   return all;
  }
  void UploadSkeletalRig428(GlovesSettings417 cfg,float time,int hand){
   float[] pose=cfg.FingerAnimation425?FingerPose425(time,cfg.FingerPeriod425/10f,cfg.FingerIntensity425/100f,hand):new float[5];
   if(cfg.FingerAnimation425&&FingerPreviewTime425>=0){
    if(cfg.FingerTestPose425==1)for(int i=0;i<5;i++)pose[i]=cfg.FingerIntensity425/100f;
    if(cfg.FingerTestPose425==2)for(int i=0;i<5;i++)pose[i]=0;
   }
   // Source hands are already curled into a near-fist in their bind pose. Do
   // not fold them beyond that pose: extend the fingers for the relaxed state
   // and return them to the original geometry for the closing phase.
   // Zero animation intensity (or disabled mode) leaves the mesh untouched.
   float strength=cfg.FingerAnimation425?cfg.FingerIntensity425/100f:0f;
   for(int i=0;i<5;i++)pose[i]=Math.Max(0f,strength-pose[i]);
   float[] bounds;float[] boneMatrices=FingerSkeleton428(pose,cfg.Model,out bounds);
   matrix4fv428(rigBonesLoc428,15,0,boneMatrices);
   vector4fv428(rigBoundsLoc428,5,bounds);
  }
  int extraLoc425=-1;
  delegate void GlUniform4f425(int location,float a,float b,float c,float d);
  delegate void GlUniform2f425(int location,float a,float b);
  GlUniform4f425 finger4f425;GlUniform2f425 finger2f425;
  void Finger4f425(int loc,float a,float b,float c,float d){if(finger4f425==null)finger4f425=Fn<GlUniform4f425>(introResolve135,"glUniform4f");finger4f425(loc,a,b,c,d);}
  void Finger2f425(int loc,float a,float b){if(finger2f425==null)finger2f425=Fn<GlUniform2f425>(introResolve135,"glUniform2f");finger2f425(loc,a,b);}
  public int PickGlove420(float sx,float sy,GlovesSettings417 setting){return PickGloveProxy421(sx,sy,setting);}
  struct Vec3Pick420 {
   public double X,Y,Z;public Vec3Pick420(double x,double y,double z){X=x;Y=y;Z=z;}
   public static Vec3Pick420 operator+(Vec3Pick420 a,Vec3Pick420 b){return new Vec3Pick420(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}
   public static Vec3Pick420 operator-(Vec3Pick420 a,Vec3Pick420 b){return new Vec3Pick420(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}
   public static Vec3Pick420 operator*(Vec3Pick420 a,double k){return new Vec3Pick420(a.X*k,a.Y*k,a.Z*k);}
   public static Vec3Pick420 operator/(Vec3Pick420 a,double k){return a*(1.0/k);}
   public static double Dot(Vec3Pick420 a,Vec3Pick420 b){return a.X*b.X+a.Y*b.Y+a.Z*b.Z;}
   public static Vec3Pick420 Cross(Vec3Pick420 a,Vec3Pick420 b){return new Vec3Pick420(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);}
  }
  static Vec3Pick420 ReadPos420(float[] p,int idx){int i=idx*11;return new Vec3Pick420(p[i],p[i+1],p[i+2]);}
  static Vec3Pick420 RotateX420(Vec3Pick420 p,double r){double c=Math.Cos(r),s=Math.Sin(r);return new Vec3Pick420(p.X,p.Y*c-p.Z*s,p.Y*s+p.Z*c);}
  static Vec3Pick420 RotateY420(Vec3Pick420 p,double r){double c=Math.Cos(r),s=Math.Sin(r);return new Vec3Pick420(p.X*c+p.Z*s,p.Y,-p.X*s+p.Z*c);}
  static Vec3Pick420 RotateZ420(Vec3Pick420 p,double r){double c=Math.Cos(r),s=Math.Sin(r);return new Vec3Pick420(p.X*c-p.Y*s,p.X*s+p.Y*c,p.Z);}
  static double RayTri420(Vec3Pick420 o,Vec3Pick420 d,Vec3Pick420 a,Vec3Pick420 b,Vec3Pick420 c){
   Vec3Pick420 e1=b-a,e2=c-a,p=Vec3Pick420.Cross(d,e2);
   double det=Vec3Pick420.Dot(e1,p);if(Math.Abs(det)<1e-10)return -1;
   double inv=1.0/det;Vec3Pick420 t=o-a;
   double u=Vec3Pick420.Dot(t,p)*inv;if(u<0||u>1)return -1;
   Vec3Pick420 q=Vec3Pick420.Cross(t,e1);double v=Vec3Pick420.Dot(d,q)*inv;
   if(v<0||u+v>1)return -1;
   double hit=Vec3Pick420.Dot(e2,q)*inv;return hit>0.0001?hit:-1;
  }
  void DisposeGloves417(){
   for(int i=0;i<2;i++)if(gloveBuffers417[i]!=0)deleteBuffers(1,ref gloveBuffers417[i]);
   for(int i=0;i<2;i++)if(gloveRigBuffers426[i]!=0)deleteBuffers(1,ref gloveRigBuffers426[i]);
   if(gloveShader417!=0)deleteProgram60(gloveShader417);
   for(int i=0;i<gloveBase417.Length;i++)if(gloveBase417[i]!=null){InvalidateTexture(gloveBase417[i]);gloveBase417[i].Dispose();}
   for(int i=0;i<gloveMr417.Length;i++)if(gloveMr417[i]!=null){InvalidateTexture(gloveMr417[i]);gloveMr417[i].Dispose();}
  }
 }
}
