using System;using System.Drawing;using System.Drawing.Drawing2D;using System.Collections.Generic;
namespace Asteroidy {
 // Authored solid geometry, shared by every camera. X: wings, Y: nose, Z: dorsal.
 sealed class ShipMesh {
  public struct P {public float X,Y,Z;public P(float x,float y,float z){X=x;Y=y;Z=z;}public static P operator -(P a,P b){return new P(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}}
  public struct Face {public P A,B,C,N;public int Material;public Face(P a,P b,P c,int m){A=a;B=b;C=c;Material=m;P u=b-a,v=c-a;N=new P(u.Y*v.Z-u.Z*v.Y,u.Z*v.X-u.X*v.Z,u.X*v.Y-u.Y*v.X);float d=(float)Math.Sqrt(N.X*N.X+N.Y*N.Y+N.Z*N.Z);if(d>0)N=new P(N.X/d,N.Y/d,N.Z/d);}}
  public static readonly Color[] Colors={Color.FromArgb(213,220,219),Color.FromArgb(38,48,57),Color.FromArgb(40,108,122),Color.FromArgb(121,144,157),Color.FromArgb(229,143,72),Color.FromArgb(114,249,239),Color.FromArgb(197,244,255),Color.FromArgb(184,95,43)};
  readonly int kind;public readonly Color[] Palette;public P[] EngineCenters;public Face[] Faces;public float[] Vertices;public readonly int[] Start=new int[8],Count=new int[8];readonly List<Face> build=new List<Face>();readonly Dictionary<string,List<P>> normals=new Dictionary<string,List<P>>();
  // v172: purely visual 6% growth, shared by CPU previews and GPU geometry.
  public const float VisualSize172=1.06f;
  static P Enlarge172(P p){return new P(p.X*VisualSize172,p.Y*VisualSize172,p.Z*VisualSize172);}
  void T(P a,P b,P c,int material){Face f=new Face(Enlarge172(a),Enlarge172(b),Enlarge172(c),material);if(f.N.X*f.N.X+f.N.Y*f.N.Y+f.N.Z*f.N.Z>.5f)build.Add(f);}
  void Q(P a,P b,P c,P d,int material){T(a,b,c,material);T(a,c,d,material);}
  void Poly(P[] p,int m,bool reverse){for(int i=1;i<p.Length-1;i++)if(reverse)T(p[0],p[i+1],p[i],m);else T(p[0],p[i],p[i+1],m);}
  void Box(float x,float y,float z,float w,float l,float h,int m){P a=new P(x-w/2,y-l/2,z),b=new P(x+w/2,y-l/2,z),c=new P(x+w/2,y+l/2,z),d=new P(x-w/2,y+l/2,z);P aa=new P(a.X,a.Y,z+h),bb=new P(b.X,b.Y,z+h),cc=new P(c.X,c.Y,z+h),dd=new P(d.X,d.Y,z+h);Q(aa,bb,cc,dd,m);Q(a,d,c,b,m);Q(a,b,bb,aa,m);Q(b,c,cc,bb,m);Q(c,d,dd,cc,m);Q(d,a,aa,dd,m);}
  const int BodySides172=24; // 3 smooth samples per original octagonal section.
  static P Mix172(P a,P b,float t){return new P(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,a.Z+(b.Z-a.Z)*t);}
  static P CurveRing172(P before,P a,P b,P after,float t){
   // Centripetal-like reduced tangents retain the old hull proportions without sharp corners.
   float t2=t*t,t3=t2*t,tension=.72f;
   return new P(
    (2*t3-3*t2+1)*a.X+(t3-2*t2+t)*tension*(b.X-before.X)*.5f+(-2*t3+3*t2)*b.X+(t3-t2)*tension*(after.X-a.X)*.5f,
    a.Y+(b.Y-a.Y)*t,
    (2*t3-3*t2+1)*a.Z+(t3-2*t2+t)*tension*(b.Z-before.Z)*.5f+(-2*t3+3*t2)*b.Z+(t3-t2)*tension*(after.Z-a.Z)*.5f);
  }
  P[] Ring(float y,float w,float bottom,float top){
   P[] baseRing={new P(-w*.62f,y,bottom),new P(-w,y,bottom*.52f),new P(-w,y,top*.52f),new P(-w*.58f,y,top),new P(w*.58f,y,top),new P(w,y,top*.52f),new P(w,y,bottom*.52f),new P(w*.62f,y,bottom)};
   P[] smooth=new P[BodySides172];for(int i=0;i<8;i++)for(int j=0;j<3;j++){
    smooth[i*3+j]=CurveRing172(baseRing[(i+7)%8],baseRing[i],baseRing[(i+1)%8],baseRing[(i+2)%8],j/3f);
   }return smooth;
  }
  void WingPlate172(P[] outline,int sign,float thickness){
   // Rounded perimeter, double curved section and gently crowned upper aerodynamic skin.
   int perimeter=outline.Length*4;
   P[] edge=new P[perimeter],lower=new P[perimeter];P center=new P();
   for(int i=0;i<outline.Length;i++){center.X+=outline[i].X;center.Y+=outline[i].Y;center.Z+=outline[i].Z;}
   center=new P(center.X/outline.Length,center.Y/outline.Length,center.Z/outline.Length);
   float crown=kind==2?.065f:kind==0?.034f:.045f;
   center.Z+=crown;
   for(int i=0;i<outline.Length;i++)for(int sub=0;sub<4;sub++){
    P sample=CurveRing172(outline[(i+outline.Length-1)%outline.Length],outline[i],outline[(i+1)%outline.Length],outline[(i+2)%outline.Length],sub/4f);
    // Keep the span from overshooting the original silhouette in the x direction.
    edge[i*4+sub]=sample;
    lower[i*4+sub]=new P(sample.X,sample.Y,sample.Z-thickness);
   }
   P[] inner=new P[perimeter],middle=new P[perimeter];
   for(int i=0;i<perimeter;i++){
    inner[i]=Mix172(center,edge[i],.48f);inner[i].Z+=crown*.22f;
    middle[i]=Mix172(center,edge[i],.78f);middle[i].Z+=crown*.07f;
   }
   for(int i=0;i<perimeter;i++){
    int j=(i+1)%perimeter;
    if(sign>0){T(center,inner[j],inner[i],0);Q(inner[i],inner[j],middle[j],middle[i],0);Q(middle[i],middle[j],edge[j],edge[i],0);}
    else {T(center,inner[i],inner[j],0);Q(inner[i],middle[i],middle[j],inner[j],0);Q(middle[i],edge[i],edge[j],middle[j],0);}
    if(sign>0){T(new P(center.X,center.Y,center.Z-thickness),lower[i],lower[j],1);Q(edge[i],edge[j],lower[j],lower[i],3);}
    else {T(new P(center.X,center.Y,center.Z-thickness),lower[j],lower[i],1);Q(edge[j],edge[i],lower[i],lower[j],3);}
   }
  }
  void Body(){float[] y={-1.08f,-.72f,-.22f,.38f,1.02f,1.48f,1.94f},w={.30f,.43f,.44f,.34f,.23f,.13f,.012f},top={.16f,.24f,.25f,.27f,.18f,.09f,.006f};if(kind==0){y=new[]{-1.12f,-.72f,-.22f,.48f,1.16f,1.72f,2.14f};w=new[]{.20f,.27f,.29f,.24f,.15f,.075f,.008f};top=new[]{.14f,.20f,.24f,.26f,.15f,.07f,.005f};}else if(kind==2){y=new[]{-1.14f,-.86f,-.38f,.16f,.54f,.90f,1.24f};w=new[]{.46f,.61f,.59f,.50f,.37f,.27f,.035f};top=new[]{.23f,.35f,.37f,.34f,.29f,.17f,.028f};}P[] last=Ring(y[0],w[0],-.13f,top[0]);Poly(last,1,true);for(int r=1;r<y.Length;r++)for(int step=1;step<=4;step++){float t=step/4f;P[] next=Ring(Curve55(y,r,t),Math.Max(.006f,Curve55(w,r,t)),-.13f*(1-(r-1+t)/7f),Math.Max(.004f,Curve55(top,r,t)));for(int i=0;i<BodySides172;i++){int j=(i+1)%BodySides172;int band=i/3;Q(last[i],last[j],next[j],next[i],band==3?0:band==7?1:3);}last=next;}Poly(last,0,false);}
  void Wing(int sign){if(kind!=1){VariantWing(sign);return;}P[] outline={new P(.27f,.64f,.025f),new P(1.19f,-.23f,-.03f),new P(1.32f,-.83f,-.055f),new P(.95f,-.99f,-.04f),new P(.29f,-.76f,.025f)};P[] lo=new P[outline.Length];for(int i=0;i<outline.Length;i++){outline[i].X*=sign;lo[i]=new P(outline[i].X,outline[i].Y,outline[i].Z-.085f);}WingPlate172(outline,sign,.085f);
   // Angular titanium inlay, orange recognition stripe, recessed access panel.
   P a=new P(sign*.49f,.24f,.038f),b=new P(sign*1.12f,-.38f,-.012f),c=new P(sign*1.16f,-.57f,-.026f),d=new P(sign*.45f,-.02f,.044f);if(sign>0)Q(a,d,c,b,4);else Q(a,b,c,d,4);
   Box(sign*.78f,-.66f,-.016f,.28f,.20f,.025f,1);Box(sign*.78f,-.66f,.011f,.19f,.11f,.008f,3);for(int k=0;k<3;k++)Box(sign*(.65f+k*.065f),-.80f,-.005f,.034f,.095f,.008f,4);
   Box(sign*1.21f,-.76f,.004f,.055f,.20f,.04f,1);Box(sign*1.21f,-.72f,.044f,.035f,.075f,.012f,sign<0?4:5);
  }
  void Tube(float x,float z,float[] y,float[] radius,int material,int sides){P[] last=null;for(int r=0;r<y.Length;r++){P[] ring=new P[sides];for(int i=0;i<sides;i++){float a=i*(float)Math.PI*2/sides;ring[i]=new P(x+(float)Math.Cos(a)*radius[r],y[r],z+(float)Math.Sin(a)*radius[r]);}if(last!=null)for(int i=0;i<sides;i++){int j=(i+1)%sides;Q(last[i],ring[i],ring[j],last[j],material);}last=ring;}}
  void Engine(int sign){float x=sign*(kind==2?.88f:.43f),z=.035f;Tube(x,z,new[]{-.42f,-.64f,-.94f,-1.17f},new[]{.14f,.22f,.205f,.18f},1,32);Tube(x,z,new[]{-.76f,-.90f,-1.07f,-1.18f},new[]{.221f,.217f,.193f,.182f},3,32);Tube(x,z,new[]{-1.18f,-1.19f,-1.00f},new[]{.182f,.125f,.10f},7,32);
   P center=new P(x,-1.001f,z);for(int i=0;i<32;i++){float a=i*(float)Math.PI/16,b=(i+1)*(float)Math.PI/16;T(center,new P(x+(float)Math.Cos(b)*.104f,-1.006f,z+(float)Math.Sin(b)*.104f),new P(x+(float)Math.Cos(a)*.104f,-1.006f,z+(float)Math.Sin(a)*.104f),6);}
   Tube(x,z,new[]{-1.18f,-1.191f},new[]{.126f,.124f},5,32);
   // Shell retaining ribs and small dorsal service casing.
   for(int k=0;k<8;k++){float a=k*(float)Math.PI/4;Box(x+(float)Math.Cos(a)*.208f,-.91f,z+(float)Math.Sin(a)*.208f,.018f,.17f,.018f,7);}
   Box(x,-.46f,.17f,.14f,.28f,.065f,0);
  }
  void Gun(int sign){float x=sign*(kind==0?.62f:.93f);Tube(x,.045f,new[]{.48f,.37f,.14f,-.17f,-.43f,-.66f},new[]{.025f,.05f,.075f,.085f,.065f,.03f},1,16);Tube(x,.045f,new[]{.35f,.37f,.40f},new[]{.066f,.066f,.044f},3,16);Box(x,-.11f,.10f,.09f,.26f,.04f,4);Tube(x,.045f,new[]{.43f,.485f},new[]{.026f,.026f},5,16);}
  void Canopy(){P[] low={new P(0,.98f,.194f),new P(-.18f,.58f,.265f),new P(-.21f,.10f,.270f),new P(-.12f,-.20f,.270f),new P(.12f,-.20f,.270f),new P(.21f,.10f,.270f),new P(.18f,.58f,.265f)};
   P[] high={new P(0,.83f,.34f),new P(-.125f,.48f,.49f),new P(-.145f,.14f,.515f),new P(-.085f,-.11f,.39f),new P(.085f,-.11f,.39f),new P(.145f,.14f,.515f),new P(.125f,.48f,.49f)};for(int i=0;i<low.Length;i++){int j=(i+1)%low.Length;Q(low[i],low[j],high[j],high[i],i==3?1:2);}Poly(high,2,false);
   // Narrow canopy frame runs across the crown instead of a glowing flat window.
   Q(new P(-.146f,.13f,.518f),new P(.146f,.13f,.518f),new P(.146f,.163f,.518f),new P(-.146f,.163f,.518f),3);
   Box(0,-.16f,.28f,.21f,.045f,.018f,7);
  }
  void Fin(int sign){P a=new P(sign*.26f,-.90f,.19f),b=new P(sign*.26f,-.23f,.23f),c=new P(sign*.40f,-.76f,.69f);P aa=new P(a.X+sign*.045f,a.Y,a.Z),bb=new P(b.X+sign*.045f,b.Y,b.Z),cc=new P(c.X+sign*.045f,c.Y,c.Z);T(a,b,c,0);T(aa,cc,bb,1);Q(a,c,cc,aa,3);Q(b,bb,cc,c,3);Q(a,aa,bb,b,1);Q(new P(c.X,-.77f,.60f),new P(c.X+sign*.046f,-.77f,.60f),cc,c,4);}
  public ShipMesh(int type=1,bool playableShip=true){int rawType=type;if(playableShip&&(rawType<0||rawType>=Game.ShipNames.Length))throw new ArgumentOutOfRangeException("type");kind=Math.Max(0,Math.Min(2,rawType));Palette=(Color[])Colors.Clone();if(rawType==Game.TransportShipType388||rawType==6||rawType==7){
     Palette[0]=Color.FromArgb(175,157,119);Palette[1]=Color.FromArgb(28,42,49);
     Palette[2]=Color.FromArgb(53,132,151);Palette[3]=Color.FromArgb(103,118,121);
     Palette[4]=Color.FromArgb(232,157,49);Palette[5]=Color.FromArgb(91,220,236);
     Palette[6]=Color.FromArgb(188,248,255);Palette[7]=Color.FromArgb(76,112,120);
    }else if(rawType==Game.HeavyShipType387){
     Palette[0]=Color.FromArgb(113,128,138);Palette[1]=Color.FromArgb(28,38,48);
     Palette[2]=Color.FromArgb(66,92,109);Palette[3]=Color.FromArgb(153,169,172);
     Palette[4]=Color.FromArgb(199,135,59);Palette[5]=Color.FromArgb(83,212,232);
     Palette[6]=Color.FromArgb(178,247,255);Palette[7]=Color.FromArgb(82,121,132);
    }else if(rawType==3){Palette[0]=Color.FromArgb(226,229,232);Palette[1]=Color.FromArgb(43,45,54);Palette[3]=Color.FromArgb(120,16,21);Palette[4]=Color.FromArgb(233,44,52);Palette[5]=Color.FromArgb(255,96,120);Palette[7]=Color.FromArgb(167,34,43);}else if(kind==0){Palette[0]=Color.FromArgb(132,178,198);Palette[3]=Color.FromArgb(53,98,132);Palette[4]=Color.FromArgb(84,225,230);Palette[7]=Color.FromArgb(34,139,169);}else if(kind==2){Palette[0]=Color.FromArgb(119,128,139);Palette[3]=Color.FromArgb(69,76,89);Palette[4]=Color.FromArgb(231,62,73);Palette[5]=Color.FromArgb(255,79,83);Palette[7]=Color.FromArgb(142,42,52);}if(rawType==1&&playableShip){if(!Vanguard431.TryApply(this))throw new System.IO.InvalidDataException("Brak lub uszkodzony model GLB Vanguard431.");return;}if(rawType==3&&playableShip){if(!PlayerShip363.TryApply(this))throw new System.IO.InvalidDataException("Brak lub uszkodzony model gracza GLB PlayerShip363 — nie można zastąpić go starym statkiem.");return;}
   if(rawType==6){Miner389();}else if(rawType==7){Transport388(false);}else if(rawType==Game.TransportShipType388){Transport388(true);}else if(rawType==Game.HeavyShipType387){Heavy387();}else{EngineCenters=new[]{Enlarge172(new P(-(kind==2?.88f:.43f),-1.18f,.035f)),Enlarge172(new P(kind==2?.88f:.43f,-1.18f,.035f))};Body();for(int s=-1;s<=1;s+=2){Wing(s);Engine(s);Gun(s);Fin(s);Box(s*.31f,.02f,.205f,.12f,.45f,.05f,1);for(int k=0;k<5;k++)Box(s*.31f,-.15f+k*.078f,.263f,.12f,.019f,.021f,3);Box(s*.30f,.73f,.12f,.035f,.12f,.01f,5);}Canopy();if(kind==2){for(int sign=-1;sign<=1;sign+=2){Box(sign*.53f,-.35f,.28f,.18f,.78f,.20f,0);Box(sign*.88f,-.67f,.20f,.38f,.56f,.10f,1);Box(sign*.88f,-.67f,.31f,.18f,.34f,.016f,4);GunPod(sign*1.17f);}}else if(kind==0){Box(0,-.66f,.30f,.055f,.42f,.30f,3);}Box(0,1.30f,.11f,.07f,.22f,.018f,4);Box(0,-.63f,.247f,.075f,.38f,.025f,7);
   Detail55();}Faces=build.ToArray();foreach(Face f in Faces){CacheNormal(f.A,f.N,f.Material);CacheNormal(f.B,f.N,f.Material);CacheNormal(f.C,f.N,f.Material);}List<float> vertices=new List<float>();for(int m=0;m<8;m++){Start[m]=vertices.Count/12;foreach(Face f in Faces)if(f.Material==m){Add(vertices,f.A,f.N,m);Add(vertices,f.B,f.N,m);Add(vertices,f.C,f.N,m);}Count[m]=vertices.Count/12-Start[m];}Vertices=vertices.ToArray();build.Clear();normals.Clear();}
  
  static float Curve55(float[] a,int r,float t){float p=a[Math.Max(0,r-2)],q=a[r-1],v=a[r],w=a[Math.Min(a.Length-1,r+1)];return .5f*((2*q)+(-p+v)*t+(2*p-5*q+4*v-w)*t*t+(-p+3*q-3*v+w)*t*t*t);}
  void Detail55(){for(int sign=-1;sign<=1;sign+=2){float x=sign*(kind==2?.88f:.43f);
   // Rounded intake collars, shaded recessed compressor vanes and hub.
   Tube(x,.035f,new[]{-.41f,-.39f,-.37f},new[]{.143f,.147f,.126f},3,32);
   Tube(x,.035f,new[]{-.38f,-.44f},new[]{.122f,.111f},1,32);
   for(int i=0;i<24;i++){float a=i*(float)Math.PI/12,c=a+.14f;Q(new P(x+(float)Math.Cos(a)*.04f,-.425f,.035f+(float)Math.Sin(a)*.04f),new P(x+(float)Math.Cos(c)*.12f,-.43f,.035f+(float)Math.Sin(c)*.12f),new P(x+(float)Math.Cos(c+.06f)*.12f,-.43f,.035f+(float)Math.Sin(c+.06f)*.12f),new P(x+(float)Math.Cos(a+.1f)*.04f,-.425f,.035f+(float)Math.Sin(a+.1f)*.04f),3);}
   Tube(x,.035f,new[]{-.43f,-.34f,-.32f},new[]{.042f,.018f,.002f},3,24);
   for(int i=0;i<4;i++)Tube(x,.035f,new[]{-.72f-i*.085f,-.73f-i*.085f},new[]{.225f-i*.009f,.225f-i*.009f},7,32);
   float dorsal=kind==2?.37f:.25f;for(int i=0;i<6;i++){Box(sign*.23f,-.73f+i*.075f,dorsal,.075f,.025f,.024f,1);Box(sign*.23f,-.73f+i*.075f,dorsal+.025f,.06f,.009f,.006f,3);}
   Box(sign*(kind==0?.55f:1.05f),-.82f,.065f,.08f,.15f,.035f,3);Box(sign*(kind==0?.55f:1.05f),-.8f,.102f,.045f,.03f,.01f,sign<0?4:5);
   Box(sign*.14f,.62f,.23f,.026f,.23f,.018f,3);
  }Box(0,-.46f,kind==2?.38f:.27f,.035f,.18f,.18f,3);Tube(0,.18f,new[]{1.12f,1.26f,1.32f},new[]{.04f,.028f,.005f},1,16);}
  void VariantWing(int sign){P[] top=kind==0?new[]{new P(.19f,.40f,.05f),new P(.88f,-.84f,.01f),new P(.73f,-1.10f,.02f),new P(.20f,-.82f,.09f)}:new[]{new P(.43f,.56f,.12f),new P(1.33f,.27f,.10f),new P(1.40f,-.79f,.04f),new P(.79f,-1.06f,.09f),new P(.39f,-.83f,.15f)};P[] low=new P[top.Length];for(int i=0;i<top.Length;i++){top[i].X*=sign;low[i]=new P(top[i].X,top[i].Y,top[i].Z-(kind==0?.07f:.18f));}WingPlate172(top,sign,kind==0?.07f:.18f);if(kind==0){Box(sign*.50f,-.62f,.056f,.07f,.54f,.018f,4);Box(sign*.72f,-.84f,.025f,.10f,.20f,.025f,5);}else{Box(sign*1.13f,-.33f,.12f,.28f,.69f,.075f,3);Box(sign*1.13f,-.18f,.20f,.10f,.20f,.018f,4);for(int k=0;k<3;k++)Box(sign*1.13f,-.62f+k*.065f,.20f,.21f,.028f,.01f,1);}}
  void GunPod(float x){Tube(x,.24f,new[]{.78f,.46f,.21f,-.11f},new[]{.06f,.08f,.095f,.10f},1,10);Tube(x,.24f,new[]{.72f,.79f},new[]{.065f,.06f},5,10);Box(x,.03f,.21f,.15f,.22f,.12f,3);}


  // v389: distinct compact mining craft with a tapered hull, articulated drilling spindle,
  // side thrusters and safety wings. Not a re-scaled carrier fighter.
  void Miner389(){
   EngineCenters=new[]{Enlarge172(new P(-.28f,-.54f,.01f)),Enlarge172(new P(.28f,-.54f,.01f))};
   Tube(0,-.06f,new[]{-.82f,-.52f,.22f,.68f,.95f},new[]{.20f,.34f,.30f,.17f,.018f},0,20);
   Tube(0,-.06f,new[]{-.74f,-.60f,.16f},new[]{.21f,.26f,.12f},1,20);
   for(int sign=-1;sign<=1;sign+=2){
    P[] wing={new P(sign*.18f,.42f,-.06f),new P(sign*.70f,.10f,-.10f),new P(sign*.81f,-.46f,-.09f),new P(sign*.27f,-.64f,.03f)};
    WingPlate172(wing,sign,.085f);
    Tube(sign*.28f,.01f,new[]{-.20f,-.46f,-.62f,-.72f},new[]{.09f,.16f,.15f,.11f},1,16);
    Tube(sign*.28f,.01f,new[]{-.71f,-.73f},new[]{.098f,.092f},5,16);
    Box(sign*.62f,-.26f,.04f,.075f,.46f,.09f,3);
    for(int i=0;i<5;i++)Box(sign*.62f,-.46f+i*.10f,.15f,.11f,.026f,.015f,i%2==0?4:1);
    Box(sign*.22f,.14f,.28f,.14f,.25f,.08f,2);
   }
   // The bore and cutting head are visibly protruding in front.
   Tube(0,-.12f,new[]{.59f,.84f,1.02f,1.28f},new[]{.14f,.12f,.065f,.006f},3,20);
   Tube(0,-.12f,new[]{.83f,.91f,1.03f},new[]{.15f,.16f,.10f},4,20);
   for(int i=0;i<12;i++){float a=i*(float)Math.PI/6;Box((float)Math.Cos(a)*.13f,.92f,-.12f+(float)Math.Sin(a)*.13f,.045f,.18f,.035f,1);}
   Box(0,-.02f,.26f,.30f,.40f,.055f,2);
  }
  // v391: two long, distinct, genuinely rounded cargo hulls, with open-air
  // clearance beside the slim command spine. NOT the TITAN armored fighter planform.
  // Curved longitudinal lofts have separate structural bands, recessed panels,
  // side cradles and azimuthal locks rather than one large rectangular slab.
  void CargoLoft391(float centerX,float centerZ){
   const int sides=24;
   float[] ys={-2.38f,-2.25f,-2.02f,-1.56f,-.98f,-.36f,.32f,.94f,1.38f,1.62f,1.75f};
   float[] widths={.025f,.24f,.39f,.44f,.48f,.49f,.47f,.43f,.34f,.20f,.01f};
   P[] previous=null;
   for(int station=0;station<ys.Length;station++){
    P[] ring=new P[sides];
    for(int j=0;j<sides;j++){
     float angle=(float)(j*Math.PI*2/sides);
     float xf=(float)Math.Cos(angle),zf=(float)Math.Sin(angle);
     // Slight pod crown and crescent cross-section, to avoid boxy profile.
     float waist=1f+.035f*(float)Math.Sin((ys[station]+2.3f)*2.4f);
     ring[j]=new P(centerX+xf*widths[station]*waist,ys[station],centerZ+zf*widths[station]*.69f+zf*zf*.025f);
    }
    if(previous!=null){
     for(int j=0;j<sides;j++){
      int next=(j+1)%sides;
      int m=station==1||station==ys.Length-1?1:station==2||station==ys.Length-2?4:j>=4&&j<=8?0:j>=9&&j<=12?3:0;
      Q(previous[j],previous[next],ring[next],ring[j],m);
     }
    }
    previous=ring;
   }
   // Independent cargo frames, curved metal retention collars and pressure joints.
   for(int k=0;k<6;k++){
    float y=-1.95f+k*.62f;
    Tube(centerX,centerZ,new[]{y-.025f,y+.025f},new[]{.500f,.500f},k==0||k==5?4:1,24);
    // Interspersed luminous pressure / seal indicators.
    for(int side=-1;side<=1;side+=2){
     Box(centerX+side*.486f,y,centerZ+.09f,.038f,.11f,.10f,k%2==0?5:4);
    }
   }
   // Vented longitudinal cargo-cover spine and service ladder.
   Box(centerX,-.33f,centerZ+.339f,.20f,2.62f,.018f,1);
   for(int i=0;i<22;i++){
    float y=-1.70f+i*.145f;
    Box(centerX,y,centerZ+.359f,.29f,.023f,.017f,i%5==0?4:3);
   }
  }
  void Transport388(bool shuttleDocked){
   EngineCenters=new[]{Enlarge172(new P(-2.14f,-2.45f,.02f)),Enlarge172(new P(-.79f,-2.35f,.04f)),Enlarge172(new P(.79f,-2.35f,.04f)),Enlarge172(new P(2.14f,-2.45f,.02f))};
   // MAMMOTH's shape reads as a flying industrial catamaran. Four huge
   // cavities separate its cargo rail hulls from the central control spine.
   CargoLoft391(-1.83f,-.02f);CargoLoft391(1.83f,-.02f);
   Tube(0,.00f,new[]{-2.38f,-1.95f,-1.15f,-.25f,.80f,1.55f,2.18f,2.86f},
    new[]{.15f,.32f,.34f,.29f,.31f,.27f,.16f,.008f},1,24);
   Tube(0,.045f,new[]{-1.48f,-.88f,-.15f,.64f,1.38f,1.92f,2.60f},
    new[]{.27f,.30f,.31f,.27f,.26f,.20f,.016f},0,24);
   // Forward panoramic bridge: slanted diamond canopy with curved reinforcements.
   Tube(0,.23f,new[]{.82f,1.25f,1.60f,1.85f,2.06f},
    new[]{.26f,.26f,.23f,.15f,.005f},2,24);
   for(int i=0;i<6;i++){
    Box(0,.98f+i*.19f,.44f,.36f,.028f,.035f,i%3==0?4:1);
   }
   // Cross-braces have real open space on both sides of the center spine.
   for(int sign=-1;sign<=1;sign+=2){
    P[] forwardBrace={new P(sign*.20f,1.84f,-.01f),new P(sign*.57f,1.49f,-.04f),new P(sign*1.48f,1.14f,-.10f),new P(sign*1.57f,.88f,-.10f),new P(sign*.46f,1.04f,-.03f)};
    WingPlate172(forwardBrace,sign,.11f);
    P[] aftBrace={new P(sign*.29f,-1.43f,-.03f),new P(sign*1.48f,-1.74f,-.10f),new P(sign*1.60f,-1.91f,-.10f),new P(sign*.35f,-1.77f,-.03f)};
    WingPlate172(aftBrace,sign,.15f);
    // Rails and diagonally supported gantry beams, open rather than massive wing slabs.
    Box(sign*.96f,-.48f,.17f,.13f,1.05f,.10f,3);
    Box(sign*.98f,-.44f,.28f,.08f,.83f,.07f,4);
    for(int k=0;k<4;k++){
     float y=-.77f+k*.29f;
     Box(sign*1.20f,y,-.08f,.52f,.047f,.065f,1);
     Box(sign*1.14f,y+.08f,.06f,.26f,.047f,.031f,3);
    }
    // Overslung mining gantry, antennae and clamp pistons.
    Tube(sign*1.16f,.15f,new[]{-.98f,-.38f,.28f,.57f},
     new[]{.047f,.06f,.045f,.012f},3,12);
    Tube(sign*1.18f,.15f,new[]{-.53f,-.32f},new[]{.082f,.071f},4,16);
    Box(sign*1.40f,-1.35f,-.22f,.12f,.94f,.12f,1);
    for(int k=0;k<5;k++)Box(sign*1.40f,-1.66f+k*.17f,-.07f,.11f,.032f,.027f,4);
    // Outboard stabilizer tips at the nose make the transporter recognisable.
    P[] fin={new P(sign*2.17f,1.42f,.03f),new P(sign*2.62f,.91f,-.06f),new P(sign*2.72f,-.56f,-.05f),new P(sign*2.36f,-.95f,-.06f),new P(sign*2.22f,.55f,.02f)};
    WingPlate172(fin,sign,.08f);
    Box(sign*2.50f,-.41f,.03f,.08f,.57f,.035f,4);
    // Four distinct deeply recessed thrusters. Two shielded by the cargo pods.
    for(int m=0;m<2;m++){
     float x=sign*(m==0?.79f:2.14f),y=m==0?-2.35f:-2.45f,r=m==0?.24f:.30f;
     Tube(x,.02f,new[]{y+.73f,y+.29f,y+.07f,y-.09f},new[]{r*.55f,r,r*.94f,r*.80f},1,24);
     Tube(x,.02f,new[]{y-.07f,y-.11f,y+.03f},new[]{r*.80f,r*.56f,r*.42f},7,24);
     Tube(x,.02f,new[]{y-.12f,y-.13f},new[]{r*.56f,r*.54f},5,24);
     for(int k=0;k<8;k++){
      float a=k*(float)Math.PI/4;
      Box(x+(float)Math.Cos(a)*r*.86f,y+.10f,.02f+(float)Math.Sin(a)*r*.86f,.047f,.20f,.044f,3);
     }
    }
   }
   // Actual removable shuttle garage suspended under the narrow carrier spine.
   // Empty variant retains only the cradle / clamps.
   Box(0,-.64f,-.37f,.63f,1.12f,.14f,1);
   for(int sign=-1;sign<=1;sign+=2){
    Box(sign*.30f,-.58f,-.23f,.05f,.72f,.09f,4);
    Box(sign*.32f,-.94f,-.18f,.15f,.16f,.10f,3);
   }
   if(shuttleDocked){
    Tube(0,-.24f,new[]{-.98f,-.67f,-.24f,.15f,.51f},new[]{.08f,.22f,.20f,.12f,.006f},3,16);
    Tube(0,-.24f,new[]{.31f,.52f,.70f},new[]{.11f,.055f,.005f},4,16);
    for(int sign=-1;sign<=1;sign+=2){
     Box(sign*.20f,-.57f,-.18f,.17f,.38f,.06f,0);
     Tube(sign*.21f,-.16f,new[]{-.79f,-.96f},new[]{.088f,.075f},5,12);
    }
   }
   // Dock ribs and electrical connectors along the exposed center channel.
   for(int i=0;i<12;i++){
    Box(0,-1.64f+i*.28f,.31f,.31f,.033f,.040f,i%4==0?4:3);
   }
  }

  // v387: bespoke heavy gunship geometry, not a scaled Bastion or Vanguard X.
  // Broad armored fuselage, sloped nose, paired shoulder armor and four exhausts.
  // Built once by the existing mesh builder; no GLB parsing or per-frame geometry cost.
  void Heavy387(){
   EngineCenters=new[]{Enlarge172(new P(-1.47f,-1.50f,.01f)),Enlarge172(new P(-.55f,-1.61f,.06f)),Enlarge172(new P(.55f,-1.61f,.06f)),Enlarge172(new P(1.47f,-1.50f,.01f))};
   // Thick double-layer central hull and angular reinforced prow.
   Box(0,-.02f,-.22f,1.35f,2.94f,.54f,1);
   Box(0,-.03f,.29f,1.20f,2.62f,.13f,0);
   Box(0,-.27f,.43f,.89f,1.58f,.13f,3);
   Box(0,-.92f,-.32f,1.21f,.94f,.16f,3);
   P a=new P(-.64f,1.02f,-.23f),b=new P(.64f,1.02f,-.23f);
   P c=new P(0,2.14f,-.10f),d=new P(-.51f,1.01f,.35f),e=new P(.51f,1.01f,.35f);
   T(a,b,c,1);T(e,d,c,0);Q(a,c,d,a,3);T(b,e,c,3);
   Box(0,1.17f,.03f,.56f,.61f,.29f,0);
   // Raised reinforced bridge instead of a lightweight fighter canopy.
   Box(0,.19f,.51f,.74f,.75f,.27f,1);
   Box(0,.28f,.76f,.55f,.53f,.08f,2);
   Box(0,.60f,.65f,.58f,.055f,.16f,4);
   Box(0,-.19f,.70f,.69f,.055f,.12f,3);
   for(int sign=-1;sign<=1;sign+=2){
    P[] armor={new P(sign*.47f,.89f,.18f),new P(sign*1.42f,.34f,.16f),new P(sign*2.07f,-.52f,.09f),new P(sign*1.85f,-1.12f,.07f),new P(sign*.50f,-1.15f,.20f)};
    WingPlate172(armor,sign,.21f);
    // Paired slab shoulder armor over the main nacelles.
    Box(sign*1.36f,-.58f,-.14f,.72f,1.63f,.39f,1);
    Box(sign*1.36f,-.52f,.28f,.66f,1.36f,.10f,0);
    Box(sign*1.36f,-.30f,.39f,.41f,.79f,.05f,3);
    Box(sign*1.76f,-.62f,.27f,.23f,.94f,.11f,3);
    Box(sign*1.69f,-.40f,.40f,.08f,.37f,.03f,4);
    // Side radiators: ten separate slots give real depth rather than a flat decal.
    for(int i=0;i<10;i++){
     Box(sign*1.41f,-1.12f+i*.118f,.395f,.41f,.042f,.026f,i%3==0?4:1);
    }
    // Outboard stabilizers / armored keel and heavy nose guns.
    Box(sign*1.88f,-.49f,-.23f,.19f,1.22f,.28f,1);
    Box(sign*2.07f,-.62f,.02f,.12f,.91f,.21f,3);
    Box(sign*1.99f,-1.06f,.26f,.14f,.11f,.08f,5);
    Box(sign*.74f,.74f,.09f,.20f,1.06f,.17f,1);
    Tube(sign*.78f,.12f,new[]{1.58f,1.21f,.75f,.42f},new[]{.045f,.095f,.126f,.16f},3,16);
    Tube(sign*.78f,.12f,new[]{1.55f,1.65f},new[]{.049f,.048f},5,16);
    Box(sign*.79f,.93f,.28f,.28f,.52f,.07f,0);
    // Outer and inner engines are physically distinct, with recessed exhaust cones.
    for(int engine=0;engine<2;engine++){
     float x=sign*(engine==0?.55f:1.47f),y=engine==0?-1.61f:-1.50f,r=engine==0?.21f:.27f;
     Tube(x,.06f,new[]{y+.89f,y+.39f,y+.09f,y-.09f},new[]{r*.72f,r,r*.95f,r*.83f},1,20);
     Tube(x,.06f,new[]{y-.07f,y-.10f,y+.07f},new[]{r*.81f,r*.56f,r*.45f},7,20);
     Tube(x,.06f,new[]{y-.102f,y-.11f},new[]{r*.57f,r*.54f},5,20);
     for(int k=0;k<6;k++){
      float az=k*(float)Math.PI/3f;
      Box(x+(float)Math.Cos(az)*r*.83f,y+.12f,.06f+(float)Math.Sin(az)*r*.83f,.055f,.16f,.055f,3);
     }
    }
    // Impact-resistant armor plates and service access rows.
    Box(sign*.37f,-.44f,.54f,.14f,.85f,.045f,4);
    for(int k=0;k<7;k++)Box(sign*.46f,-.81f+k*.18f,.61f,.035f,.08f,.022f,1);
   }
   // Dorsal command spine, central ventilation and red/amber beacon ribs.
   Box(0,-.67f,.51f,.24f,1.25f,.15f,1);
   for(int k=0;k<12;k++)Box(0,-1.14f+k*.145f,.68f,.39f,.059f,.035f,k%4==0?4:3);
   for(int k=0;k<4;k++)Box(0,1.00f+k*.21f,.13f,.35f,.05f,.10f,k==3?5:0);
  }
  static string Key(P p,int m){return ((int)Math.Round(p.X*10000))+"/"+((int)Math.Round(p.Y*10000))+"/"+((int)Math.Round(p.Z*10000))+"/"+m;}
  void CacheNormal(P p,P n,int m){string k=Key(p,m);List<P> values;if(!normals.TryGetValue(k,out values)){values=new List<P>();normals.Add(k,values);}values.Add(n);}
  void Add(List<float> v,P p,P n,int m){if(m==1||m==2||m==3||m==7){P sum=new P();foreach(P q in normals[Key(p,m)])if(n.X*q.X+n.Y*q.Y+n.Z*q.Z>.74f){sum.X+=q.X;sum.Y+=q.Y;sum.Z+=q.Z;}float length=(float)Math.Sqrt(sum.X*sum.X+sum.Y*sum.Y+sum.Z*sum.Z);if(length>0)n=new P(sum.X/length,sum.Y/length,sum.Z/length);}Color c=Palette[m];v.AddRange(new[]{p.X,p.Y,p.Z,n.X,n.Y,n.Z,c.R/255f,c.G/255f,c.B/255f,1f,.5f+p.X/2.8f,.51f-p.Y/4.5f});}
  public static Bitmap Skin(int type=1){if(type==1)return Vanguard431.TryLoadSkin();if(type<0||type>7)throw new ArgumentOutOfRangeException("type");if(type==3){Bitmap imported=PlayerShip363.TryLoadSkin();if(imported==null)throw new System.IO.InvalidDataException("Brak tekstury kadłuba modelu GLB PlayerShip363.");return imported;}Bitmap b=new Bitmap(512,512);Random noise=new Random(811);using(Graphics g=Graphics.FromImage(b)){g.Clear((type==Game.TransportShipType388||type==7)?Color.FromArgb(155,138,101):type==6?Color.FromArgb(116,126,133):type==Game.HeavyShipType387?Color.FromArgb(98,112,119):type==0?Color.FromArgb(171,206,222):type==2?Color.FromArgb(154,164,180):Color.FromArgb(225,228,225));using(Pen seam=new Pen(Color.FromArgb(158,165,166),1))using(Pen shine=new Pen(Color.FromArgb(247,249,244),1)){for(int y=24;y<512;y+=61){g.DrawLine(seam,0,y,512,y);g.DrawLine(shine,0,y+1,512,y+1);}for(int x=17;x<512;x+=83){g.DrawLine(seam,x,0,x,512);g.DrawLine(shine,x+1,0,x+1,512);}}using(Brush dark=new SolidBrush(Color.FromArgb(80,91,101)))for(int y=40;y<512;y+=61)for(int x=31;x<512;x+=83){g.FillEllipse(dark,x,y,2,2);g.FillEllipse(dark,x+49,y,2,2);}using(Font f=new Font("DejaVu Sans",14,FontStyle.Bold))using(Brush paint=new SolidBrush(Color.FromArgb(62,80,86))){g.DrawString(type==0?"K / 01":type==2?"B / 03":type==Game.HeavyShipType387?"T / 05":(type==Game.TransportShipType388||type==7)?"M / 06":type==6?"DRILL":"V / 02",f,paint,278,294);using(Font small=new Font("DejaVu Sans",5))g.DrawString("FLIGHT DIVISION",small,paint,276,319);}for(int i=0;i<950;i++){int x=noise.Next(512),y=noise.Next(512);using(Pen p=new Pen(Color.FromArgb(noise.Next(8,22),50,57,62)))g.DrawLine(p,x,y,x+noise.Next(2,6),y);}}return b;}
 }
}
