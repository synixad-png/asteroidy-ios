using System;
using System.IO;
using System.IO.Compression;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  uint weaponBuffer474,weaponShader474;
  int weaponPbrToggle484=-1,weaponRimToggle484=-1,weaponPbrPower484=-1,weaponRimPower484=-1,weaponPolish484=-1;
  int[] weaponFirst474,weaponCount474,weaponTextureIndex474;
  Bitmap[] weaponBitmaps474;
  int weaponSampler474=-1,weaponHasTexture474=-1;
  // v487: original GLB PBR factors retained for each contiguous material run.
  float[] weaponMetal487,weaponRough487,weaponEmission487;
  readonly float[] weaponEmissionUpload487=new float[3];
  int weaponMetalLoc487=-1,weaponRoughLoc487=-1,weaponEmissionLoc487=-1;
  bool weaponFailed474;
  int weaponLightsPos482=-1,weaponLightsRgb482=-1;
  float[] currentWeaponLightPos482=new float[12],currentWeaponLightRgb482=new float[12];
  static byte[] WeaponResource474(string key){
   using(Stream stream=typeof(GpuRenderer).Assembly.GetManifestResourceStream(key)){
    if(stream==null)throw new FileNotFoundException("Missing weapon resource "+key);
    using(MemoryStream m=new MemoryStream()){stream.CopyTo(m);return m.ToArray();}
   }
  }
  bool EnsureWeapon474(){
   if(weaponBuffer474!=0&&weaponShader474!=0)return true;
   if(weaponFailed474)return false;
   try{
    byte[] bytes=WeaponResource474("Asteroidy.Weapon474.Mesh");
    byte[] unpacked;
    using(MemoryStream b=new MemoryStream(bytes))using(GZipStream gzip=new GZipStream(b,CompressionMode.Decompress))using(MemoryStream output=new MemoryStream()){gzip.CopyTo(output);unpacked=output.ToArray();}
    using(MemoryStream s=new MemoryStream(unpacked))using(BinaryReader read=new BinaryReader(s)){
     int count=read.ReadInt32(),verts=read.ReadInt32();
     if(count<1||count>100||verts<1||verts>3000000)throw new InvalidDataException("weapon geometry header");
     weaponFirst474=new int[count];weaponCount474=new int[count];weaponTextureIndex474=new int[count];
     for(int i=0;i<count;i++){weaponTextureIndex474[i]=read.ReadInt32();weaponFirst474[i]=read.ReadInt32();weaponCount474[i]=read.ReadInt32();if(weaponFirst474[i]<0||weaponCount474[i]<0||weaponFirst474[i]+weaponCount474[i]>verts)throw new InvalidDataException("weapon batch");}
     byte[] mesh=read.ReadBytes(verts*44);if(mesh.Length!=verts*44)throw new EndOfStreamException("weapon vertex data");
     GCHandle pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);
     try{genBuffers(1,out weaponBuffer474);bindBuffer(0x8892,weaponBuffer474);bufferData(0x8892,new IntPtr(mesh.Length),pin.AddrOfPinnedObject(),0x88E4);bindBuffer(0x8892,0);}finally{pin.Free();}
    }
    // v487: load the author-derived material runs without modifying the baked VBO.
    using(BinaryReader mr=new BinaryReader(new MemoryStream(WeaponResource474("Asteroidy.Weapon487.Materials")))){
     if(mr.ReadInt32()!=487)throw new InvalidDataException("Weapon PBR material metadata version");
     int count=mr.ReadInt32(),expected=mr.ReadInt32();
     if(count<1||count>300||expected<1||expected>3000000)throw new InvalidDataException("Weapon PBR run count");
     int[] first=new int[count],num=new int[count],tex=new int[count];
     weaponMetal487=new float[count];weaponRough487=new float[count];weaponEmission487=new float[count*3];
     int cursor=0;
     for(int i=0;i<count;i++){
      first[i]=mr.ReadInt32();num[i]=mr.ReadInt32();tex[i]=mr.ReadInt32();
      weaponMetal487[i]=mr.ReadSingle();weaponRough487[i]=mr.ReadSingle();
      for(int k=0;k<3;k++)weaponEmission487[i*3+k]=mr.ReadSingle();
      if(first[i]!=cursor||num[i]<=0||num[i]%3!=0||tex[i]<-1||tex[i]>=13||
       weaponMetal487[i]<0||weaponMetal487[i]>1||weaponRough487[i]<0||weaponRough487[i]>1)
       throw new InvalidDataException("Weapon PBR run validation failed at "+i);
      cursor+=num[i];
     }
     if(cursor!=expected||mr.BaseStream.Position!=mr.BaseStream.Length)
      throw new InvalidDataException("Weapon PBR material vertex count mismatch");
     weaponFirst474=first;weaponCount474=num;weaponTextureIndex474=tex;
    }
    weaponBitmaps474=new Bitmap[13];
    for(int i=0;i<13;i++){
     try{using(Stream input=new MemoryStream(WeaponResource474("Asteroidy.Weapon474.Tex"+i))){using(Bitmap temp=new Bitmap(input)){weaponBitmaps474[i]=new Bitmap(temp);}}}catch(FileNotFoundException){/* material without a texture */}
    }
    Func<string,IntPtr> res=introResolve135;
    var create=Fn<CreateShader60>(res,"glCreateShader");var source=Fn<Source60>(res,"glShaderSource");var compile=Fn<U>(res,"glCompileShader");var status=Fn<Status60>(res,"glGetShaderiv");var log=Fn<Log60>(res,"glGetShaderInfoLog");var del=Fn<U>(res,"glDeleteShader");var cp=Fn<CreateProgram60>(res,"glCreateProgram");var attach=Fn<UU>(res,"glAttachShader");var link=Fn<U>(res,"glLinkProgram");var ps=Fn<Status60>(res,"glGetProgramiv");var pl=Fn<Log60>(res,"glGetProgramInfoLog");var ul=Fn<Location60>(res,"glGetUniformLocation");
    const string vs=@"#version 120
varying vec3 wn;varying vec3 vc;varying vec2 wuv;varying vec3 eye;
void main(){vec4 p=gl_ModelViewMatrix*gl_Vertex;eye=p.xyz;wn=normalize(gl_NormalMatrix*gl_Normal);vc=gl_Color.rgb;wuv=gl_MultiTexCoord0.xy;gl_Position=gl_ProjectionMatrix*p;}";
    // v486: weapon viewmodel no longer owns independent material sliders.
    // It now uses the SAME polished metal / PBR / rim switches as gloves,
    // while still reacting to the real H72 hangar lamps nearest the player.
    const string fs=@"#version 120
uniform sampler2D weaponDiffuse474;uniform int weaponTextured474;
uniform float weaponPolish484,weaponPbrPower484,weaponRimPower484;
uniform float weaponMetal487,weaponRough487;uniform vec3 weaponEmission487;
uniform int weaponPbrOn484,weaponRimOn484;
uniform vec3 weaponLightsPos482[4],weaponLightsRgb482[4];
varying vec3 wn;varying vec3 vc;varying vec2 wuv;varying vec3 eye;
const float PI=3.14159265;
float Dggx(float nh,float rough){float a=rough*rough;float a2=a*a;float d=nh*nh*(a2-1.0)+1.0;return a2/(PI*d*d+0.0001);}
void main(){
 // glTF baseColorFactor and COLOR_0 are linear. Only image samples need sRGB decoding.
 vec3 base=clamp(vc*(weaponTextured474==1?pow(texture2D(weaponDiffuse474,wuv).rgb,vec3(2.2)):vec3(1.0)),0.0,1.0);
 float metal=clamp(weaponMetal487,0.0,1.0),rough=clamp(weaponRough487,0.09,1.0);
 float polish=clamp(weaponPolish484,0.0,1.0);
 metal=mix(metal,max(metal,0.93),polish);
 rough=mix(rough,max(0.09,rough*0.18),polish);
 vec3 n=normalize(wn);if(!gl_FrontFacing)n=-n;
 vec3 v=normalize(-eye);
 float ndv=max(dot(n,v),0.001);
 vec3 f0=mix(vec3(0.045),base,metal);
 float brdfLevel=(weaponPbrOn484==1)?clamp(weaponPbrPower484,0.0,1.0)*2.0:0.0;
 vec3 c=base*(0.20+0.22*max(n.y,0.0));
 // Exact directional key light used by the gloves, evaluated with the same GGX.
 // This guarantees that PBR toggle is not dependent on whether a hangar GLB has punctual lights.
 vec3 keyL=normalize(vec3(-0.56,0.84,0.75));
 float keyNdl=max(dot(n,keyL),0.0);
 if(keyNdl>0.0){
  vec3 keyH=normalize(keyL+v);
  float keyNdh=max(dot(n,keyH),0.0),keyVdh=max(dot(v,keyH),0.0);
  vec3 keyF=f0+(vec3(1.0)-f0)*pow(1.0-keyVdh,5.0);
  float keyD=Dggx(keyNdh,rough);float keyK=pow(rough+1.0,2.0)/8.0;
  float keyG=(ndv/(ndv*(1.0-keyK)+keyK))*(keyNdl/(keyNdl*(1.0-keyK)+keyK));
  vec3 keyBrdf=keyF*keyD*keyG/(4.0*ndv*keyNdl+0.002);
  c+=(base*(1.0-metal)/PI+keyBrdf*brdfLevel)*keyNdl*vec3(2.1,2.3,2.65);
 }
 for(int j=0;j<4;j++){
  vec3 lightRgb=weaponLightsRgb482[j]*1.35;
  vec3 delta=weaponLightsPos482[j]-eye;
  float dist=length(delta);
  if(dist<0.001||dot(lightRgb,lightRgb)<0.000001)continue;
  vec3 l=delta/dist;
  float ndl=max(dot(n,l),0.0);
  if(ndl<=0.0)continue;
  vec3 h=normalize(l+v);
  float ndh=max(dot(n,h),0.0),vdh=max(dot(v,h),0.0);
  vec3 F=f0+(vec3(1.0)-f0)*pow(1.0-vdh,5.0);
  float D=Dggx(ndh,rough);float k=pow(rough+1.0,2.0)/8.0;
  float G=(ndv/(ndv*(1.0-k)+k))*(ndl/(ndl*(1.0-k)+k));
  vec3 brdf=F*D*G/(4.0*ndv*ndl+0.002);
  c+=(base*(1.0-metal)/PI+brdf*brdfLevel)*ndl*lightRgb;
 }
 vec3 lamp=normalize(vec3(0.8,0.25,0.65));vec3 rh=normalize(lamp+v);
 c+=vec3(0.5,0.75,1.0)*pow(max(dot(n,rh),0.0),mix(48.0,140.0,1.0-rough))*mix(0.04,0.54,metal)*brdfLevel;
 if(weaponRimOn484==1)c+=vec3(0.33,0.56,0.76)*pow(1.0-ndv,3.0)*0.36*clamp(weaponRimPower484,0.0,1.0);
 c+=base*(1.0-metal)*0.025;
 c+=max(weaponEmission487,vec3(0.0))*0.18;
 // v489: polished metal must have a room reflection, as in H55Renderer v395.
 // Without it, raising metallic merely removes diffuse colour unless a point light aligns with the normal.
 // At polish=0 this is exactly zero, retaining original viewmodel material and v487 live lighting.
 vec3 refl=reflect(-v,n);
 float width489=max(0.045,0.12+rough*0.24);
 float boxA489=exp(-pow((refl.y-0.70)/width489,2.0));
 float boxB489=exp(-pow((refl.x+0.62)/(width489*0.78),2.0))*smoothstep(-0.4,0.5,refl.y);
 float boxC489=pow(max(0.0,dot(refl,normalize(vec3(0.16,0.66,0.73)))),max(6.0,55.0*(1.0-rough)));
 vec3 room489=vec3(0.22,0.31,0.45)*(0.20+0.65*max(0.0,refl.y))
    +vec3(3.0,2.8,2.54)*boxA489+vec3(0.65,1.4,2.25)*boxB489
    +vec3(1.9,1.85,1.6)*boxC489;
 vec3 fresnel489=f0+(vec3(1.0)-f0)*pow(1.0-ndv,5.0);
 vec3 reflected489=room489*fresnel489*(1.0-rough*0.60)*polish*(0.35+0.65*metal);
 c+=reflected489;
 c=c/(1.0+c);c=pow(clamp(c,0.0,1.0),vec3(1.0/2.2));gl_FragColor=vec4(c,1.0);
}";
    weaponShader474=BuildPostProgram103(vs,fs,create,source,compile,status,log,del,cp,attach,link,ps,pl);
    weaponMetalLoc487=ul(weaponShader474,"weaponMetal487");weaponRoughLoc487=ul(weaponShader474,"weaponRough487");weaponEmissionLoc487=ul(weaponShader474,"weaponEmission487");
    if(weaponMetalLoc487<0||weaponRoughLoc487<0||weaponEmissionLoc487<0)throw new InvalidOperationException("Weapon v487 PBR material uniforms missing");
    weaponSampler474=ul(weaponShader474,"weaponDiffuse474");weaponHasTexture474=ul(weaponShader474,"weaponTextured474");
    weaponPolish484=ul(weaponShader474,"weaponPolish484");
    weaponPbrToggle484=ul(weaponShader474,"weaponPbrOn484");weaponRimToggle484=ul(weaponShader474,"weaponRimOn484");
    weaponPbrPower484=ul(weaponShader474,"weaponPbrPower484");weaponRimPower484=ul(weaponShader474,"weaponRimPower484");
    if(weaponPolish484<0||weaponPbrToggle484<0||weaponRimToggle484<0||weaponPbrPower484<0||weaponRimPower484<0)
     throw new InvalidOperationException("Weapon v486 shared material uniforms unavailable");
    weaponLightsPos482=ul(weaponShader474,"weaponLightsPos482[0]");weaponLightsRgb482=ul(weaponShader474,"weaponLightsRgb482[0]");
    if(weaponLightsPos482<0||weaponLightsRgb482<0)throw new InvalidOperationException("Weapon hangar lighting uniforms missing");
    gpuLog66("Weapon v487: glove GGX key + original GLB material runs + hangar lights active");return true;
   }catch(Exception ex){weaponFailed474=true;gpuLog66("Weapon v474 load error: "+ex);return false;}
  }
  void DrawImportedWeapon474(){
   if(!EnsureWeapon474())return;
   activeTexture103(TEXTURE0_103);disable(0x0B44);
   useToon60(weaponShader474);
   if(weaponSampler474>=0)uniform60(weaponSampler474,0);
   uniform60(weaponPbrToggle484,AdvancedOn106[0]?1:0);
   uniform60(weaponRimToggle484,AdvancedOn106[1]?1:0);
   waterFloat65(weaponPolish484,Math.Max(0,Math.Min(100,MetalPolish395))*0.01f);
   waterFloat65(weaponPbrPower484,AdvancedPower106[0]*.01f);
   waterFloat65(weaponRimPower484,AdvancedPower106[1]*.01f);
   if(weaponLightsPos482>=0&&skinVectors65!=null)skinVectors65(weaponLightsPos482,4,currentWeaponLightPos482);
   if(weaponLightsRgb482>=0&&skinVectors65!=null)skinVectors65(weaponLightsRgb482,4,currentWeaponLightRgb482);
   enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);enableClient(0x8078);
   bindBuffer(0x8892,weaponBuffer474);
   vertexPointer(3,0x1406,44,IntPtr.Zero);
   shipNormal(0x1406,44,new IntPtr(12));
   uvPointer(2,0x1406,44,new IntPtr(24));
   colorPointer(3,0x1406,44,new IntPtr(32));
   for(int i=0;i<weaponCount474.Length;i++){
    int ti=weaponTextureIndex474[i];bool textured=ti>=0&&ti<weaponBitmaps474.Length&&weaponBitmaps474[ti]!=null;
    waterFloat65(weaponMetalLoc487,weaponMetal487[i]);waterFloat65(weaponRoughLoc487,weaponRough487[i]);
    if(skinVectors65!=null){for(int k=0;k<3;k++)weaponEmissionUpload487[k]=weaponEmission487[i*3+k];skinVectors65(weaponEmissionLoc487,1,weaponEmissionUpload487);}
    if(weaponHasTexture474>=0)uniform60(weaponHasTexture474,textured?1:0);
    if(textured){enable(TEX);bindTexture(TEX,Texture(weaponBitmaps474[ti]));}else{bindTexture(TEX,0);disable(TEX);}
    drawArrays(4,weaponFirst474[i],weaponCount474[i]);DrawCalls++;SubmittedVertices+=weaponCount474[i];
   }
   disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);disableClient(0x8078);
   bindBuffer(0x8892,0);bindTexture(TEX,0);disable(TEX);useToon60(0);
  }
  void DisposeWeapon474(){
   if(weaponBuffer474!=0&&deleteBuffers!=null){deleteBuffers(1,ref weaponBuffer474);weaponBuffer474=0;}
   if(weaponShader474!=0&&deleteProgram60!=null){deleteProgram60(weaponShader474);weaponShader474=0;}
   if(weaponBitmaps474!=null)foreach(Bitmap b in weaponBitmaps474)if(b!=null){InvalidateTexture(b);b.Dispose();}
   weaponBitmaps474=null;weaponMetal487=null;weaponRough487=null;weaponEmission487=null;
  }
 }
}
