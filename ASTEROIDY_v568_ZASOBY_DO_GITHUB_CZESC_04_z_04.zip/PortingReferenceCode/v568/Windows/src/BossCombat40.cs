using System;
namespace Asteroidy {
 public struct SlimePatch {public V P;public float Life,Seed;}
 public partial class Game {
  public bool IsBossSector{get{return Level>=4&&Level<=CampaignLength&&Level%4==0;}}
  public int BossType{get{return Math.Max(0,Math.Min(5,Level/4-1));}}
  static readonly string[] bossNames={"ROZGWIAZDA · ANIMOWANE MACKI","LEWIATAN · Biomechaniczny drapieżnik","TWIERDZA ORBITALNA · Pierścienie obronne","PANCERNY NISZCZYCIEL · Nowy boss GLB","ALIEN SCOUT · Obcy zwiadowca","KRAB OBLĘŻNICZY · Pancerna platforma szturmowa"};
  static readonly string[] bossAttackNames={"MACKI / PLAZMA","MACKI / TOKSYCZNE WYRZUTY","MINY / POLA MAGNETYCZNE","FALE CZASOWE / SKOK / KARABINY","ALIEN SCOUT / DRONY + SALWY PLAZMY","GATLINGI / RAKIETY / SZARŻA"};
  public string BossName{get{return bossNames[BossType];}}public string BossAttackName{get{return bossAttackNames[BossType];}}
  public int BossReward{get{return Level==4?35:Level==8?70:Level==12?55:Level==16?65:Level==20?75:100;}}
  // v98: each encounter advertises the next volley and scales damage independently of normal enemies.
  public int BossShotDamage98 {get{return BossProjectileDamage98(Level,Difficulty);}}
  public static int BossProjectileDamage98(int level,int difficulty){
   int baseDamage=level<=4?16:level<=8?19:level<=12?22:level<=16?25:level<=20?28:30;
   return Math.Max(1,(int)Math.Round(baseDamage*(difficulty==0?.8f:difficulty==2?1.18f:1f)));
  }
  public int BossDismantled98, BossBonus98;
  public int BossBonusPerPart98 {get{return 2+BossType;}}
  public float BossWarning98 {get{return BossActive&&BossAimLocked&&BossPhaseShift<=0&&BossCooldown>0?Math.Max(0,Math.Min(1,1-BossCooldown/(.85f*DangerSpeed))):0;}}
  public string BossAttackPreview98 {get{if(BossType==5){if(BossFireTime>0&&BossAttackKind==1)return "GATLINGI OBLĘŻNICZE";switch(UpcomingBossAttack){case 1:return "GATLINGI OBLĘŻNICZE";case 2:return "RAKIETY OBLĘŻNICZE - UNIK / ZESTRZEL";case 3:return "SZARŻA PANCERNA - ODSUŃ SIĘ";default:return "SALWA WACHLARZOWA - UNIK";}}if(BossFireTime>0)return SpecialBehavior159(BossType);switch(UpcomingBossAttack){case 1:return SpecialBehavior159(BossType);case 2:return BossType==1?"MAŹ - UNIKAJ SPOWOLNIENIA":"POCISKI SPECJALNE - UNIK";case 3:return "IMPULS DOOKOLNY - ZACHOWAJ ODSTEP";default:return "SALWA WACHLARZOWA - UNIK";}}}
  public float BossSlowTime,BossAim,BossFireTime;public float ScoutAttackStarted173=-9999f;public int BossVolley,BossAttackKind;public bool BossAimLocked;float bossFireEmission;V bossAimPoint72;
  public readonly SlimePatch[] SlimePatches=new SlimePatch[16];int slimeCursor;
  public float BossMovementScale{get{return BossSlowTime>0?.65f:1;}}
  public int BossStage=1;public float BossPhaseShift;public int UpcomingBossAttack{get{return NextSpecial158(NextBossAttack);}}
  public int BossFanCount{get{return NextBossAttack==2?(BossStage==3?5:3):NextBossAttack==3?8+BossStage*2:3+BossStage*2;}}
  void ResetBossSpecial(){ResetScoutPhysics174();ResetCrabBoss175();ResetBossPhysical179();ResetBossTerrain180();ResetBossMotion157();ResetBossModules84();BossExposure65=0;bossLastOwner65=0;bossLastHit65=bossCombo65=-99;BossStage=1;BossPhaseShift=0;ResetBossUnique159();BossSlowTime=BossFireTime=bossFireEmission=0;ResetGuardianGuns434();ScoutAttackStarted173=-9999f;BossAimLocked=false;BossVolley=BossAttackKind=slimeCursor=0;Array.Clear(SlimePatches,0,SlimePatches.Length);}
  void StepBossSlow(float dt){BossSlowTime=Math.Max(0,BossSlowTime-dt);for(int i=0;i<SlimePatches.Length;i++){SlimePatch p=SlimePatches[i];p.Life=Math.Max(0,p.Life-dt);SlimePatches[i]=p;if(p.Life>0&&WorldDelta67(Ship,p.P).Length<48)BossSlowTime=Math.Max(BossSlowTime,.45f);}}
  void SlimeImpact(V p,float seed){SlimePatches[slimeCursor]=new SlimePatch{P=p,Life=3.4f,Seed=seed};slimeCursor=(slimeCursor+1)%SlimePatches.Length;}
  int NextBossAttack{get{switch(BossType){
   case 0:return BossVolley%3==0?1:BossVolley%3==1?0:3; // Drill shocks: plasma and radial debris
   case 1:return BossVolley%3==0?1:BossVolley%3==1?2:0; // Leviathan: energy sweep and slowing secretion
   case 2:return BossVolley%2==0?3:0; // Rotating fortress batteries
   case 3:return BossVolley%3==0?2:BossVolley%3==1?3:0; // Time distortion and radial energy
   case 4:return 1; // Scout deploys seven hunters and charges independent plasma batteries
   default:return BossVolley%3==0?1:BossVolley%3==1?2:3; // Siege crab: gun bursts, rocket pods and armored charge
  }}}
  void BossShot(V origin,float angle,float speed,int kind){if(BossProjectiles.Count>=96||(BossFireTime>0&&kind!=1&&BossType!=4))return;float port=BossType==2?(kind==1?-55:55):BossType==5?(kind==1?-60:kind==2?60:0):BossType==0?(BossProjectiles.Count%2==0?-43:43):0;float muzzle=BossType==5?102:BossType==2?60:72;if(SphereActive67){port*=BossSize68;muzzle*=BossSize68;speed*=1.12f*DangerSpeed;}BossProjectile shot=new BossProjectile{P=SphereActive67?WorldOffset67(origin,Direction(angle)*muzzle+Direction(angle+PI/2)*port):origin+Direction(angle)*muzzle+Direction(angle+PI/2)*port,Velocity=Direction(angle)*speed,Kind=kind,Life=kind==1?1.12f:kind==2?2.8f:5,Seed=BossVolley*.71f+BossProjectiles.Count*.83f};shot.Velocity=TransportVelocity67(origin,shot.P,shot.Velocity);BossProjectiles.Add(shot);}
  void BossAttack(){bool rage=BossStage>=2;BossAttackKind=NextSpecial158(NextBossAttack);BossVolley++;
   if(BossType==4){
    ScoutAttackStarted173=Time;
    BossAttackKind=1;BossFireTime=1.35f;bossFireEmission=0;StartBossUnique159();
    // Never clear active shots: the previous build destroyed every volley here.
   }else if(BossAttackKind==1){BossFireTime=(.85f+BossStage*.15f)*(.55f+.45f*BossArmamentRatio84);bossFireEmission=0;if(BossType==5)CrabAttackStarted175=Time;if(BossType!=0&&BossType!=5)StartBossUnique159();
    if(BossType!=5)BossProjectiles.RemoveAll(delegate(BossProjectile projectile){return projectile.Kind!=1;});
   }else if(BossType==5&&BossAttackKind==2){BossFireTime=.72f;bossFireEmission=0;CrabRocketVolley177();}
   else if(BossType==5&&BossAttackKind==3){BossFireTime=0;bossFireEmission=0;CrabStartCharge177();}
   else if(BossAttackKind==3){int count=Math.Max(2,(int)Math.Round((8+BossStage*2)*(.45f+.55f*BossArmamentRatio84)));for(int i=0;i<count;i++)BossShot(BossPosition,BossAim+i*2*PI/count+BossVolley*.24f,130,3);}else {int count=Math.Max(2,(int)Math.Round((BossAttackKind==2?(BossStage==3?5:3):3+BossStage*2)*(.45f+.55f*BossArmamentRatio84)));float spacing=BossAttackKind==2?.34f:.24f;for(int i=0;i<count;i++)BossShot(BossPosition,BossAim+(i-(count-1)*.5f)*spacing,BossAttackKind==2?120:rage?175:150,BossAttackKind);}
   // v83: identifiable boss-specific attacks, all using existing collision-safe projectiles.
   if(SphereActive67){
    if(BossType==0&&BossModulesAlive84>0&&BossVolley%3==1){ // Kolos: drilling lunge and seismic ring
      V rush=WorldDelta67(Ship,BossPosition);if(rush.Length>1)BossVelocity68+=rush*(22/rush.Length);
    }
    if(BossType==1&&BossModulesAlive84>=2&&BossVolley%3==0){ // Leviathan: secretion lingers near moving tentacles
      for(int t=-1;t<=1;t++)SlimeImpact(WorldOffset67(BossPosition,Direction(BossAim+t*.42f)*(55+BossStage*12)),BossVolley*.4f+t);
    }
    if(BossType==3&&BossModulesAlive84>0&&BossVolley%4==0){ // Chronosphere: short spatial jump, preserving spherical coordinates
      V toward=WorldDelta67(Ship,BossPosition);if(toward.Length>130){
       V leap=Direction(BossAim+PI/2)*(65+BossStage*12);
       V old=BossPosition;BossPosition=WorldOffset67(old,leap);BossVelocity68=TransportVelocity67(old,BossPosition,BossVelocity68);BossPhaseShift=.35f;
      }
    }
    // Crab uses two independent Gatlings; no fake center/side salvos.
   }
   BossCooldown=BossType==4?(3.20f-(BossStage-1)*.20f)*(.92f+.08f/DangerSpeed):((BossAttackKind==1?3.0f:BossAttackKind==2?2.6f:2.25f)-(BossStage-1)*.18f)*(SphereActive67?.70f:1);if(BossType==5)BossCooldown*=BossAttackKind==3?.92f:.78f;BossAimLocked=false;BossExposure65=1.15f;
  }
  internal void StepBoss(float dt){if(!BossActive)return;if(BossFireTime<=0)BossExposure65=Math.Max(0,BossExposure65-dt);BossClock+=dt*(1+(BossStage-1)*.10f);BossPhaseShift=Math.Max(0,BossPhaseShift-dt);BossFlash=Math.Max(0,BossFlash-dt);if(SphereActive67)MoveBoss68(dt);else MoveBossClassic157(dt);
   StepScoutPhysics174(dt);StepBossPhysical179(dt);StepCrabBoss175(dt);StepBossTerrain180(dt);CrabGatlingTick178(dt);StepBossDebris85(dt);StepLeviathanGrab85(dt);StepGuardianGuns434(dt);
   if(BossPhaseShift<=0)BossCooldown-=dt*DangerSpeed;
   if(BossCooldown<=.85f*DangerSpeed&&!BossAimLocked){V toward=WorldDelta67(CoopEnabled62&&(Down1Time65>0||Down2Time65<=0&&BossVolley%2==1)?Ship62:Ship,BossPosition);if(SphereActive67){bool second=CoopEnabled62&&(Down1Time65>0||Down2Time65<=0&&BossVolley%2==1);V target=second?Ship62:Ship;V v=second?Velocity62:Velocity;toward=WorldDelta67(WorldOffset67(target,Limit68(v,SurfaceSpeed68)*Math.Min(.85f,toward.Length/230)),BossPosition);}bossAimPoint72=WorldOffset67(BossPosition,toward);BossAimLocked=true;}
   {V target=CoopEnabled62&&(Down1Time65>0||Down2Time65<=0&&WorldDelta67(Ship62,BossPosition).Length<WorldDelta67(Ship,BossPosition).Length)?Ship62:Ship;
    // Crab keeps tracking the actual player even while an older attack point is locked.
    V d=WorldDelta67(BossType==5?target:(BossAimLocked?bossAimPoint72:target),BossPosition);if(d.Length>.001f)TurnBossInertial157((float)Math.Atan2(d.Y,d.X),dt);
   }
   if(BossPhaseShift<=0&&BossCooldown<=0&&BossFireTime<=0)BossAttack();
   if(BossFireTime>0){BossFireTime=Math.Max(0,BossFireTime-dt);if(BossType==0){bossFireEmission+=dt*27*(.45f+.55f*BossArmamentRatio84);int cap=0;while(bossFireEmission>=1&&cap++<12){bossFireEmission--;float curl=(float)Math.Sin(BossClock*8+bossFireEmission)*(.16f+BossStage*.06f);BossShot(BossPosition,BossAim+curl,280,1);}}
    else if(BossType==4){bossFireEmission+=dt*(BossStage==3?3.5f:2.8f);int waves174=0;while(bossFireEmission>=1&&waves174++<3){bossFireEmission--;ScoutGunBurst174();}}else if(BossType==5&&BossAttackKind==1){bossFireEmission+=dt*(BossStage>=3?6.0f:BossStage==2?5.0f:4.2f);int salvos175=0;while(bossFireEmission>=1&&salvos175++<5){bossFireEmission--;CrabGunBurst175();}}}
   if(BossType!=0)StepBossUnique159(dt);
   for(int i=BossProjectiles.Count-1;i>=0;i--){BossProjectile p=BossProjectiles[i];V old=p.P;if(p.Kind==1){p.Velocity=p.Velocity*(float)Math.Exp(-dt*1.1f);StepSpecialShots158(p,dt);}V sweep67=p.Velocity*(dt*(SphereActive67?1:DangerSpeed));p.P=WorldAdvance67(p.P,ref p.Velocity,dt*(SphereActive67?1:DangerSpeed));p.Life-=dt;p.Age+=dt;bool expired=p.Life<=0||!SphereActive67&&(p.P.X<-70||p.P.X>W+70||p.P.Y<-70||p.P.Y>H+70);
    V travel=SphereActive67?sweep67:p.P-old,to=WorldDelta67(Ship,old);float len=travel.X*travel.X+travel.Y*travel.Y,t=len>0?Math.Max(0,Math.Min(1,(to.X*travel.X+to.Y*travel.Y)/len)):0;float radius=p.Radius+11;if(SphereActive67&&ProjectileCover68(p,old,travel)){BossProjectiles.RemoveAt(i);continue;}
    if((to-travel*t).Length<radius){
     // v98: consume projectiles on every genuine contact, including during i-frames.
     // Otherwise an old overlapping hit can injure the player after immunity expires.
     if(p.Kind==2){if(Invincible<=0)BossSlowTime=Math.Max(BossSlowTime,2.2f);SlimeImpact(p.P,p.Seed);BossProjectiles.RemoveAt(i);continue;}
     if(Invincible<=0)ApplyHit96("POCISK BOSSA",BossShotDamage98);
     BossProjectiles.RemoveAt(i);continue;
    }
    if(SecondBossHit62(p,old,travel,radius)){BossProjectiles.RemoveAt(i);continue;}if(expired){if(p.Kind==2&&(SphereActive67||p.P.X>0&&p.P.X<W&&p.P.Y>110&&p.P.Y<H))SlimeImpact(p.P,p.Seed);BossProjectiles.RemoveAt(i);}
   }
   if(!SphereActive67&&WorldDelta67(BossPosition,Ship).Length<BossContactRadius+ContactRadius-ShipContactRadius&&Invincible<=0){ApplyHit96("ZDERZENIE Z BOSSEM",CollisionDamage96);V away=WorldDelta67(Ship,BossPosition);Ship=WorldOffset67(BossPosition,(away.Length>.01f?away*(110/away.Length):new V(0,110)));}
  }
 }
}
