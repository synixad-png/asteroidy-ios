using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;

namespace Asteroidy {
 // Exact indexed triangles and RGBA vertex colours from user-supplied VULKARIS GLB.
 // Converted once at packaging time; GLB itself is also retained in the ZIP.
 // Original contains no texture images, animations or authored vertex normals;
 // converter computes smooth vertex normals without modifying positions or faces.
 internal sealed class Vulkaris276 {
  internal const int Level = 26;
  internal const int Triangles = 299769;
  internal const int Groups = 7;
  internal readonly float[] Vertices;
  internal readonly int[] Starts = new int[Groups];
  internal readonly int[] Counts = new int[Groups];
  internal readonly float[] HeightMap;
  internal readonly int Width, Height;
  private static Vulkaris276 shared;
  private Vulkaris276() {
   using(Stream raw=Assembly.GetExecutingAssembly().GetManifestResourceStream("Vulkaris276.Mesh")) {
    if(raw==null)throw new InvalidDataException("Brak wbudowanej geometrii VULKARIS");
    using(GZipStream gz=new GZipStream(raw,CompressionMode.Decompress))
    using(BinaryReader reader=new BinaryReader(gz)) {
     if(reader.ReadUInt32()!=0x39373256u || reader.ReadInt32()!=Groups)throw new InvalidDataException("Nieznany format VULKARIS v279");
     int sum=0;
     for(int i=0;i<Groups;i++){Starts[i]=sum;Counts[i]=reader.ReadInt32();if(Counts[i]<0||Counts[i]>450000||Counts[i]%3!=0)throw new InvalidDataException("Bledne indeksy VULKARIS");sum=checked(sum+Counts[i]);}
     if(sum!=Triangles*3)throw new InvalidDataException("Niekompletna geometria VULKARIS");
     int uniqueCount=reader.ReadInt32();
     if(uniqueCount<=0||uniqueCount>sum)throw new InvalidDataException("Uszkodzone wierzcholki VULKARIS");
     float[] unique=new float[checked(uniqueCount*10)];
     for(int i=0;i<unique.Length;i++)unique[i]=reader.ReadSingle();
     Vertices=new float[checked(sum*10)];
     for(int i=0;i<sum;i++){
      uint ix=reader.ReadUInt32();if(ix>=uniqueCount)throw new InvalidDataException("Uszkodzony indeks VULKARIS");
      int u=checked((int)ix*10),v=i*10;
      for(int j=0;j<10;j++)Vertices[v+j]=unique[u+j];
     }
     Width=reader.ReadInt32();Height=reader.ReadInt32();
     if(Width!=512||Height!=256)throw new InvalidDataException("Niepoprawna mapa kolizji VULKARIS");
     HeightMap=new float[Width*Height];for(int i=0;i<HeightMap.Length;i++)HeightMap[i]=reader.ReadSingle();
    }
   }
  }
  internal static Vulkaris276 Get() {if(shared==null)shared=new Vulkaris276();return shared;}
  internal float SurfaceRadius(float x,float y,float z) {
   float len=(float)Math.Sqrt(x*x+y*y+z*z);if(len<1e-7f)return 1f;
   float lon=(float)Math.Atan2(z,x),lat=(float)Math.Asin(Math.Max(-1,Math.Min(1,y/len)));
   float u=(lon+(float)Math.PI)/(float)(Math.PI*2)*Width-.5f;
   float v=(lat+(float)Math.PI/2)/(float)Math.PI*Height-.5f;
   int ix=(int)Math.Floor(u),iy=(int)Math.Floor(v);float a=u-ix,b=v-iy;
   int x0=((ix%Width)+Width)%Width,x1=(x0+1)%Width;
   int y0=Math.Max(0,Math.Min(Height-1,iy)),y1=Math.Max(0,Math.Min(Height-1,iy+1));
   float r00=HeightMap[y0*Width+x0],r10=HeightMap[y0*Width+x1],r01=HeightMap[y1*Width+x0],r11=HeightMap[y1*Width+x1];
   return (r00+(r10-r00)*a)*(1-b)+(r01+(r11-r01)*a)*b;
  }
 }
}
