// v461: select the TWO imported GLB drones actually placed in front of the
// mechanic. Never infer dynamic actors from arbitrary mesh names elsewhere in
// the hangar. The third imported model remains part of the authored scene.
using System;
using System.Collections.Generic;
namespace Asteroidy {
 internal static class H71DroneImports461 {
  internal sealed class Spawn {
   internal int Root;internal float X,Y,Z;internal string Name,Prefab;
  }
  static Dictionary<string,object> Obj(object value){return value as Dictionary<string,object> ?? new Dictionary<string,object>();}
  static List<object> Arr(object value){return value as List<object> ?? new List<object>();}
  static object Get(Dictionary<string,object> v,string k){object x;return v.TryGetValue(k,out x)?x:null;}
  static string Str(object x){return x as string ?? "";}
  static float Num(object x){return x==null?0f:Convert.ToSingle(x);}
  internal static Spawn[] Select(Dictionary<string,object> doc){
   List<object> nodes=Arr(Get(doc,"nodes"));float mx=10.194016f,mz=12.696275f;
   // The active authored mechanic has a HangarLab parent with a matrix.
   for(int i=0;i<nodes.Count;i++){
    var n=Obj(nodes[i]);string name=Str(Get(n,"name"));if(name.IndexOf("Mechanik_",StringComparison.OrdinalIgnoreCase)<0||Get(n,"mesh")!=null)continue;
    var mat=Arr(Get(n,"matrix"));if(mat.Count==16){mx=Num(mat[12]);mz=Num(mat[14]);break;}
   }
   List<Spawn> candidates=new List<Spawn>();
   for(int i=0;i<nodes.Count;i++){
    var n=Obj(nodes[i]);var extra=Obj(Get(n,"extras"));
    if(!(Get(extra,"hangarLabImported") is bool)||!(bool)Get(extra,"hangarLabImported"))continue;
    string source=Str(Get(extra,"hangarLabImportName"));
    if(source.IndexOf("dron",StringComparison.OrdinalIgnoreCase)<0&&source.IndexOf("drone",StringComparison.OrdinalIgnoreCase)<0)continue;
    var matrix=Arr(Get(n,"matrix"));if(matrix.Count!=16)continue;
    float x=Num(matrix[12]),y=Num(matrix[13]),z=Num(matrix[14]);
    float distance=(x-mx)*(x-mx)+(z-mz)*(z-mz);
    if(distance>36f)continue; // no remote / storage-area drone
    if(Arr(Get(n,"children")).Count==0)continue;
    candidates.Add(new Spawn{Root=i,X=x,Y=y,Z=z,Name=Str(Get(n,"name")),Prefab=Str(Get(extra,"hangarLabPrefabId"))});
   }
   candidates.Sort(delegate(Spawn a,Spawn b){float da=(a.X-mx)*(a.X-mx)+(a.Z-mz)*(a.Z-mz);float db=(b.X-mx)*(b.X-mx)+(b.Z-mz)*(b.Z-mz);return da.CompareTo(db);});
   if(candidates.Count<2)return new Spawn[0];
   return new[]{candidates[0],candidates[1]};
  }
 }
}
