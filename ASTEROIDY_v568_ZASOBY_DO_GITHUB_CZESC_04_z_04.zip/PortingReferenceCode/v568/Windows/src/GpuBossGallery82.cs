using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace Asteroidy {
 // Four damped masses in series, hanging from the immovable body. Mass
 // increases and stiffness decreases toward the distal tip. Wind from motion
 // excites the chain, while gravity and a slow periodic drive keep it alive at
 // hover. This is simulation of offsets, not source skeletal clip blending.
 internal sealed class StarTentacleMotion450 {
   public readonly float[] Uniforms=new float[12];
   readonly float[] px=new float[4],py=new float[4],pz=new float[4];
   readonly float[] vx=new float[4],vy=new float[4],vz=new float[4];
   float lastTime=-1f;int stepCount;
   public int StepCount{get{return stepCount;}}
   public void Reset(){Array.Clear(px,0,4);Array.Clear(py,0,4);Array.Clear(pz,0,4);
     Array.Clear(vx,0,4);Array.Clear(vy,0,4);Array.Clear(vz,0,4);
     for(int i=0;i<4;i++)pz[i]=-.20f*(i+1)-.07f*i*i;
     lastTime=-1f;stepCount=0;Pack();}
   public StarTentacleMotion450(){Reset();}
   void Pack(){for(int i=0;i<4;i++){Uniforms[3*i]=px[i];Uniforms[3*i+1]=py[i];Uniforms[3*i+2]=pz[i];}}
   public void Advance(float time,float speed,float backX,float backY){
     if(float.IsNaN(time)||float.IsInfinity(time))return;
     if(lastTime<0||time<lastTime||time-lastTime>.65f){Reset();lastTime=time;return;}
     float delta=time-lastTime;
     if(delta<=0)return;
     delta=Math.Min(.1f,delta);
     int substeps=Math.Max(1,(int)Math.Ceiling(delta/.0125f));
     float dt=delta/substeps,origin=time-delta;
     speed=Math.Max(0f,Math.Min(1f,speed));
     backX=Math.Max(-1f,Math.Min(1f,backX));backY=Math.Max(-1f,Math.Min(1f,backY));
     for(int s=0;s<substeps;s++){
       float t=origin+dt*(s+1);
       for(int i=0;i<4;i++){
         float phase=t*1.72f-i*.87f;
         // Each mass follows the previous mass with spring force and drag.
         float ax=i==0?0:px[i-1],ay=i==0?0:py[i-1],az=i==0?0:pz[i-1];
         float tx=ax+backX*speed*(.19f+.13f*i)+(float)Math.Sin(phase)*(.14f+.055f*i);
         float ty=ay+backY*speed*(.25f+.16f*i)+(float)Math.Cos(phase*.91f+.8f)*(.12f+.045f*i);
         float tz=az-(.20f+.14f*i)+(float)Math.Sin(phase-1.15f)*(.085f+.035f*i);
         // omega decreases with increasing tip mass; damping is deliberately
         // below critical so heavy tips overshoot and slowly settle.
         float omega=3.15f-.36f*i,drag=2f*(.34f+.02f*i)*omega;
         float force=omega*omega;
         vx[i]+=(force*(tx-px[i])-drag*vx[i])*dt;
         vy[i]+=(force*(ty-py[i])-drag*vy[i])*dt;
         vz[i]+=(force*(tz-pz[i])-drag*vz[i])*dt;
         px[i]+=vx[i]*dt;py[i]+=vy[i]*dt;pz[i]+=vz[i]*dt;
         // Numerical safety after long pauses/reloads and unexpected inputs.
         px[i]=Math.Max(-4f,Math.Min(4f,px[i]));
         py[i]=Math.Max(-4f,Math.Min(4f,py[i]));
         pz[i]=Math.Max(-4f,Math.Min(.5f,pz[i]));
       }
       stepCount++;
     }
     lastTime=time;Pack();
   }
 }
 // A development-only preview renderer. Loads actual triangulated GLB geometry converted to B82B.
 // Boss AI, collisions, campaign progression and existing bosses are not replaced.
 sealed partial class GpuRenderer {
   sealed class GalleryPart82 {
     public int start,count; public int newCrabGroup445=-1; public float[][] frames; public float[][][] scoutClips173; public float saturation168,luminance168; public float cx169,cy169,cz169,radius169; public int shadowSlot169=-1;
   }
   sealed class GalleryModel82 {
     public float[] vertices; public float[] crabUV446; public uint crabUVBuffer446,crabTexture446; public Bitmap crabBitmap446; public GalleryPart82[] parts; public bool scout173,crab175,newCrab445,star448; public float[,] pivots85=new float[10,3]; public int[] shadowParts169=new int[0]; public uint buffer;
   }
   // v198: GLB authored six hip/knee sockets, cached to avoid per-part allocations.
   static readonly float[] CrabHipX198={.68f,-.28f,-1.21f,.68f,-.28f,-1.21f};
   static readonly float[] CrabHipY198={1.61f,1.61f,1.61f,-1.61f,-1.61f,-1.61f};
   static readonly float[] CrabKneeDX198={.10f,-.23f,-.43f,.10f,-.23f,-.43f};
   static readonly float[] CrabKneeDY198={.86f,.95f,.79f,-.86f,-.95f,-.79f};
   static readonly float[] CrabKneeDZ198={.12f,.15f,.24f,.12f,.15f,.24f};
   readonly GalleryModel82[] galleryModels82 = new GalleryModel82[64];
   readonly StarTentacleMotion450 starMotion450 = new StarTentacleMotion450();
   readonly bool[] missingModelWarning87=new bool[6];
   internal void WarnMissingBossModel87(Game g){int t=Math.Max(0,Math.Min(5,g.BossType));if(missingModelWarning87[t])return;missingModelWarning87[t]=true;g.Notice="BRAK MODELU 3D BOSSA · SPRAWDŹ ASSETS_BOSS82";g.NoticeTime=8;Console.Error.WriteLine("BRAK MODELU 3D BOSSA KAMPANII #"+(t+1)+"; zweryfikuj Assets_Boss82 obok pliku wykonywalnego.");}
   readonly float[] interpolatedBossMatrix87=new float[16];
   public int BossLimbDraws87 {get;private set;}
   public int BossLimbHidden87 {get;private set;}
   // Continuous interpolation of the exported 12-FPS GLB animation track.
   // Avoid allocating per-mesh/per-frame matrices while rendering hundreds of parts.
   static void InterpolateBossTransform87(float[][] frames,float phase,float[] dst){BossPose88.Interpolate(frames,phase,dst);}
   void AnimateBossGroup87(Game g,int group,GalleryModel82 model,float time){
     float px=model.pivots85[group,0],py=model.pivots85[group,1],pz=model.pivots85[group,2];
     float phase=time*(1+.15f*(g.BossStage-1));
     float sway=(float)Math.Sin(phase*2.1f+group*.85f);
     float pulse=(float)Math.Sin(phase*3.1f+group*.7f);
     float recoil=Math.Max(0,Math.Min(1,g.BossFireTime*2.5f));
     float hitAge=g.Time-g.BossModuleHitAt85[group];
     float flinch=hitAge>=0&&hitAge<.32f?(float)Math.Sin(hitAge*24)*10*(float)Math.Exp(-hitAge*6):0;
     shipTranslate(px,py,pz);
     switch(g.BossType){
      case 0: // v156: shoulder and elbow are rigidly attached to the hull.
       // Their former 185 deg/s Y rotation swung entire drill arms through space.
       // The actual drill bits rotate separately around their own fixed axes.
       break;
      case 1: // six coherent limbs; four heavy attackers, two smaller rear feelers
       shipRotate(sway*(group<4?23:12)+flinch,0,0,1);
       shipRotate(pulse*(group<4?11:17),1,0,0);
       if(group<4&&g.BossGrabModule85==group&&g.BossGrabTelegraph85>0)
        shipRotate(31*(1-g.BossGrabTelegraph85/.75f),0,0,1);
       break;
      case 2: // each cannon tracks while its stabilizer recoils
       shipRotate(sway*13,0,0,1);shipTranslate(0,-recoil*.08f,0);break;
      case 3: // v434 fixed turrets: slight inertial yaw and recoil, never spin entire model.
       shipRotate(sway*3.3f+flinch*.22f,0,0,1);
       shipTranslate(0,-Math.Max(0,g.GuardianGunFlash434)*.22f,0);break;
      case 4: // Scout has its own complete authored 70-joint animation; no extra Hydra swaying.
       break;
      case 5: // grounded siege crab: authored leg motion drives the walk; only small body recoil is added.
       shipRotate((float)Math.Sin(phase*1.6f+group*.9f)*3.0f+flinch*.55f,0,0,1);
       shipTranslate(0,-recoil*.05f,0);break;
     }
     if(g.BossType==1){
       // Four heavier, more readable limbs and two thinner auxiliary feelers;
       // anchored scaling stretches complete 19-part chains, not triangles.
       if(group<4)shipScale(1.22f,1.18f,1.35f);
       else shipScale(.90f,.84f,.91f);
     }
     shipTranslate(-px,-py,-pz);
   }
   // v156: spin the cutter itself, not the whole arm. The solid cutter
   // assemblies have axes through x=+/-3.15, z=-.06 in GLB local coordinates.
   // Shoulder pieces 7..9 / 22..24 and the body struts 21 / 36 never rotate.
   void AnimateKolosDrill156(int partIndex,float time,int stage){
     int side=partIndex>=10&&partIndex<=20?-1:partIndex>=25&&partIndex<=35?1:0;
     if(side==0)return;
     float x=side*3.15f,z=-.06f;
     shipTranslate(x,-2.80f,z);
     shipRotate(time*(1+.15f*(stage-1))*(side<0?185f:-185f),0,1,0);
     shipTranslate(-x,2.80f,-z);
   }
   // v83: six campaign fights select the most detailed existing GLB-derived meshes.
   static readonly int[] campaignBossMesh83={6,3,2,5,1,4}; // slot 6 replaced at runtime by the animated siege crab asset
   static readonly int[] campaignVariant83={1,2,1,3,2,1};
   public readonly bool GalleryEnabled82=Environment.GetEnvironmentVariable("ASTEROIDY_GALLERY_BOSS")!=null;
   public int GalleryIndex82=ParseGalleryInt82("ASTEROIDY_GALLERY_BOSS",1,1,8)-1;
   public int GalleryVariant82=ParseGalleryInt82("ASTEROIDY_GALLERY_VARIANT",1,1,4)-1;
   static int ParseGalleryInt82(string name,int def,int min,int max){int i;return int.TryParse(Environment.GetEnvironmentVariable(name),out i)?Math.Max(min,Math.Min(max,i)):def;}
   // Campaign assets embedded in EXE/bin. The gallery can still load external extras.
   internal static bool HasEmbeddedBoss88(string filename){
     return Assembly.GetExecutingAssembly().GetManifestResourceInfo("Boss89."+filename+".gz")!=null;
   }
   internal static Stream OpenBossAsset88(string filename,bool campaign){
     if(campaign){Stream embedded=Assembly.GetExecutingAssembly().GetManifestResourceStream("Boss89."+filename+".gz");
       if(embedded!=null)return new GZipStream(embedded,CompressionMode.Decompress);}
     string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets_Boss82",filename);
     if(File.Exists(path))return File.OpenRead(path);
     throw new FileNotFoundException("Brak geometrii bossa 3D: "+filename,path);
   }

   static float Clamp01Color206(float v){return v<0?0:v>1?1:v;}
   static void PaintBossPart206(List<float> vertices,GalleryPart82 part,float tr,float tg,float tb,float floor,float gain){
    int baseIndex=part.start*10,end=baseIndex+part.count*10;
    for(int at=baseIndex;at<end;at+=10){
     float r=vertices[at+6],g=vertices[at+7],b=vertices[at+8];
     float luma=.2126f*r+.7152f*g+.0722f*b;
     float shade=floor+gain*Clamp01Color206(luma*1.08f);
     float micro=((Math.Abs(vertices[at])+Math.Abs(vertices[at+1])+Math.Abs(vertices[at+2]))%1f)*.06f-.03f;
     shade=Clamp01Color206(shade+micro);
     vertices[at+6]=Clamp01Color206(tr*shade);
     vertices[at+7]=Clamp01Color206(tg*shade);
     vertices[at+8]=Clamp01Color206(tb*shade);
    }
   }
   static void RetagPartMaterial206(GalleryPart82 part,float sat,float lum){part.saturation168=sat;part.luminance168=lum;}
   static void ApplyCrabPalette206(List<float> vertices,GalleryPart82 part,int partIndex,int group){
    if(group>=0){
     int local=(partIndex-50)&15;
     bool joint=local<=1||local==5||local==6||local==10||local==11||local>=14;
     bool tip=local==12||local==13;
     if(joint){
      PaintBossPart206(vertices,part,.12f,.035f,.035f,.48f,.34f); // near-black joint housings
      RetagPartMaterial206(part,.11f,.16f);
     }else if(tip){
      PaintBossPart206(vertices,part,.42f,.05f,.05f,.54f,.42f); // darker red claw / terminal segments
      RetagPartMaterial206(part,.64f,.24f);
     }else{
      PaintBossPart206(vertices,part,.84f,.10f,.10f,.56f,.46f); // primary armored red limb segments
      RetagPartMaterial206(part,.86f,.33f);
     }
     return;
    }
    // Body and weapons: dark graphite chassis with controlled crimson accents.
    bool weapon=partIndex>=160&&partIndex<=191;
    bool accent=(partIndex%7)==0||(partIndex>=24&&partIndex<=31)||(partIndex>=92&&partIndex<=103);
    if(weapon){
     PaintBossPart206(vertices,part,.30f,.31f,.34f,.52f,.42f);
     RetagPartMaterial206(part,.18f,.26f);
    }else if(accent){
     PaintBossPart206(vertices,part,.62f,.11f,.11f,.54f,.44f);
     RetagPartMaterial206(part,.68f,.29f);
    }else{
     PaintBossPart206(vertices,part,.24f,.25f,.28f,.54f,.40f);
     RetagPartMaterial206(part,.16f,.22f);
    }
   }
   GalleryModel82 GetGallery82(int idx){
     int variant=Math.Max(0,Math.Min(3,GalleryEnabled82?GalleryVariant82:campaignVariant83[activeCampaignBoss83]));
     bool scout173=!GalleryEnabled82&&activeCampaignBoss83==4;
     bool crab175=!GalleryEnabled82&&activeCampaignBoss83==5;
     bool star448=!GalleryEnabled82&&activeCampaignBoss83==0;
     int slot=scout173?62:crab175?63:star448?61:idx*4+variant;
     if(galleryModels82[slot]!=null)return galleryModels82[slot];
     string filename=scout173?"alien_scout_173.b82":crab175?"new_crab_446.b82":star448?"starfish_448.b82":"boss_"+(idx+1).ToString("00")+"_"+(variant+1)+".b82";
     GalleryModel82 model=new GalleryModel82();
     using(BinaryReader b=new BinaryReader(OpenBossAsset88(filename,!GalleryEnabled82))){
       string magic173=new string(b.ReadChars(4));
       string expected175=scout173?"B82S":(crab175||star448)?"B82T":"B82B";
       bool newCrab445=(crab175||star448)&&magic173=="B82T";
       if(magic173!=expected175)throw new InvalidDataException("Wrong boss mesh/animation header: "+magic173);
       int parts=b.ReadInt32(),frameCount=b.ReadInt32(),clipCount173=(scout173||crab175||star448)?b.ReadInt32():1;
       if(parts<1||parts>512||frameCount!=49||clipCount173<1||clipCount173>16||(scout173&&parts!=88)||(newCrab445&&parts!=(star448?77:26)))throw new InvalidDataException("Corrupt model asset");
       model.scout173=scout173;model.crab175=crab175||star448;model.star448=star448;model.newCrab445=newCrab445;
       List<float> vertices=new List<float>(1800000);List<float> crabUV=newCrab445?new List<float>(400000):null;model.parts=new GalleryPart82[parts];
       for(int p=0;p<parts;p++){
         int vcount=b.ReadInt32();int group445=newCrab445?b.ReadInt32():-1;if(vcount<3||vcount>150000)throw new InvalidDataException("Invalid triangle count");
         GalleryPart82 part=new GalleryPart82();part.start=vertices.Count/10;part.count=vcount;part.newCrabGroup445=group445;
         if(newCrab445){for(int j=0;j<vcount;j++){for(int c=0;c<10;c++)vertices.Add(b.ReadSingle());crabUV.Add(b.ReadSingle());crabUV.Add(b.ReadSingle());}}
         else for(int j=0;j<vcount*10;j++)vertices.Add(b.ReadSingle());
         if(scout173||crab175||star448){
           part.scoutClips173=new float[clipCount173][][];
           for(int clip173=0;clip173<clipCount173;clip173++){
             part.scoutClips173[clip173]=new float[frameCount][];
             for(int f=0;f<frameCount;f++){
               float[] matrix=new float[16];for(int j=0;j<16;j++)matrix[j]=b.ReadSingle();
               part.scoutClips173[clip173][f]=matrix;
             }
           }
           part.frames=part.scoutClips173[0];
         }else{
           part.frames=new float[frameCount][];
           for(int f=0;f<frameCount;f++){
             float[] matrix=new float[16];for(int j=0;j<16;j++)matrix[j]=b.ReadSingle();
             part.frames[f]=matrix;
           }
         }
         // v168: classify source-painted colors once on model load, not per frame.
         float minc=0,maxc=0,luma=0;int samples168=Math.Min(96,part.count);
         for(int s=0;s<samples168;s++){
           int at=(part.start+(int)((long)s*part.count/samples168))*10+6;
           float rc168=vertices[at],gc168=vertices[at+1],bc168=vertices[at+2];
           float mx=Math.Max(rc168,Math.Max(gc168,bc168)),mn=Math.Min(rc168,Math.Min(gc168,bc168));
           minc+=(mx>0?(mx-mn)/mx:0);maxc++;luma+=.2126f*rc168+.7152f*gc168+.0722f*bc168;
         }
         part.saturation168=maxc>0?minc/maxc:0;
         part.luminance168=maxc>0?luma/maxc:0;
         if(crab175&&!newCrab445)ApplyCrabPalette206(vertices,part,p,Game.BossMeshGroup84(5,p));
         // Exact source-mesh bounds calculated once; animate their centers with
         // the identical hierarchy used for drawing the real mesh triangles.
         part.radius169=BossShadow169.Radius(vertices,part.start,part.count,out part.cx169,out part.cy169,out part.cz169);
         model.parts[p]=part;
       }
       model.vertices=vertices.ToArray();
       if(newCrab445){
        // v447: reject erroneous unnormalized U16 texcoords instead of silently
        // drawing a grey boss due to GL_CLAMP_TO_EDGE sampling at 65535.
        for(int uv447=0;uv447<crabUV.Count;uv447++)
         if(float.IsNaN(crabUV[uv447])||float.IsInfinity(crabUV[uv447])||crabUV[uv447]<-.0001f||crabUV[uv447]>1.0001f)
          throw new InvalidDataException("Invalid normalized crab UV (B82T requires 0..1)");
        model.crabUV446=crabUV.ToArray();
        int imageLength=b.ReadInt32();
        if(imageLength<1024||imageLength>8*1024*1024)throw new InvalidDataException("Invalid GLB baseColorTexture size");
        byte[] originalJpeg=b.ReadBytes(imageLength);
        if(originalJpeg.Length!=imageLength)throw new EndOfStreamException("Truncated crab texture");
        using(MemoryStream stream=new MemoryStream(originalJpeg))
        using(Bitmap source=new Bitmap(stream))model.crabBitmap446=new Bitmap(source);
       }
       // The first animated bone of each group gives one common rotation pivot.
       // Keeping that pivot constant makes all 19 tentacle segments detach together.
       bool[] found85=new bool[10];
       for(int k=0;k<model.parts.Length;k++){
         int group=GalleryEnabled82?-1:(newCrab445?model.parts[k].newCrabGroup445:Game.BossMeshGroup84(activeCampaignBoss83,k));
         if(group<0||found85[group])continue;
         found85[group]=true;GalleryPart82 part=model.parts[k];float[] m=part.frames[0];
         int samples=Math.Min(18,part.count);float cx=0,cy=0,cz=0;
         for(int j=0;j<samples;j++){int at=(part.start+j)*10;cx+=model.vertices[at];cy+=model.vertices[at+1];cz+=model.vertices[at+2];}
         cx/=samples;cy/=samples;cz/=samples;
         model.pivots85[group,0]=m[0]*cx+m[4]*cy+m[8]*cz+m[12];
         model.pivots85[group,1]=m[1]*cx+m[5]*cy+m[9]*cz+m[13];
         model.pivots85[group,2]=m[2]*cx+m[6]*cy+m[10]*cz+m[14];
       }
     }
     // v169: choose the biggest articulated mesh pieces as local shadow
     // casters, at most two per intact limb and twelve per boss in total.
     List<int> selected169=new List<int>(BossShadow169.MaxCasters);
     int bossKind169=GalleryEnabled82?Math.Max(0,Math.Min(5,activeCampaignBoss83)):activeCampaignBoss83;
     if(!GalleryEnabled82){
      for(int group169=0;group169<Game.BossModuleCount84[bossKind169]&&selected169.Count<BossShadow169.MaxCasters;group169++){
       for(int n169=0;n169<2&&selected169.Count<BossShadow169.MaxCasters;n169++){
        int best169=-1;float strength169=0;
        for(int i169=0;i169<model.parts.Length;i169++){
         GalleryPart82 part169=model.parts[i169];if((model.newCrab445?model.parts[i169].newCrabGroup445:Game.BossMeshGroup84(bossKind169,i169))!=group169||selected169.Contains(i169))continue;
         float score169=part169.radius169*(float)Math.Sqrt(Math.Max(1,part169.count));
         if(score169>strength169){strength169=score169;best169=i169;}
        }
        if(best169>=0){model.parts[best169].shadowSlot169=selected169.Count;selected169.Add(best169);}
       }
      }
     }
     model.shadowParts169=selected169.ToArray();
     galleryModels82[slot]=model;Console.WriteLine("BOSS82 MODEL " +(idx+1)+" parts="+model.parts.Length+" triangles="+(model.vertices.Length/30)+" dynamic shadow casters="+model.shadowParts169.Length);
     return model;
   }
   // Source clips retained 1:1. One character animation state controls all 88 meshes.
   // glTF timings: hover 4s, patrol 3s, evade 2.7s, charge 2.6s,
   // burst 1.6s, tentacle sweep 2.4s, enraged 2.6s, hit .75s, entrance 3s, death 4.8s.
   static int ScoutClip173(Game g){return g.ScoutDesiredClip174();}
   // v450: the starfish rig is a static bind/rest pose. No source GLB clip is
   // played on tentacles: otherwise DRIFT/FLY/AGITATED/SETTLE fight the physical
   // GPU wave. All seven source clips remain in the asset for future editing,
   // but have no influence on the live mesh. The boss AI/projectiles are intact.
   static int StarClip448(Game g){return 0;}
   static float StarPhase448(Game g,int clip){return 0f;}
   static int AnimatedClip175(Game g,GalleryModel82 mesh){return mesh.star448?StarClip448(g):mesh.scout173?g.ScoutDesiredClip174():mesh.newCrab445?g.CrabVisualClip445():mesh.crab175?g.CrabDesiredClip175():0;}
   readonly float[] scoutTransitionMatrix174=new float[16];
   // Single shared skeletal path for both rendering and casting shadows:
   // moving joints and detached debris use the same source animation transforms.
   void ApplyGalleryPose169(int partIndex,int group,float detached,float time,Game game,GalleryModel82 mesh,GalleryPart82 p){
         if(detached>=0){
           // Apply ONE rigid transform to the whole limb, ahead of each bone's
           // frozen animation matrix; this prevents individual segments scattering.
           V relative=game.WorldDelta67(game.BossModuleDebrisPosition85[group],game.BossPosition);
           V forward=Game.Direction(game.BossAim),right=Game.Direction(game.BossAim-Game.PI/2);
           float dx=(relative.X*right.X+relative.Y*right.Y)/6.3936f;
           float dy=(relative.X*forward.X+relative.Y*forward.Y)/6.3936f;
           if(game.BossType==4&&mesh.scout173){
             // Five source whip roots are fixed at (x,+1.70). Their gameplay
             // units are based on the exact local-to-world StampSphere67 scale.
             float[] xs173={-.95f,-.49f,0f,.49f,.95f};
             float logicalUnit173=74f*.43f*Game.BossSize68;
             V worldRelative173=game.WorldDelta67(game.BossModuleDebrisPosition85[group],game.BossPosition);
             float dWorldX173=(worldRelative173.X*right.X+worldRelative173.Y*right.Y)/logicalUnit173;
             float dWorldY173=(worldRelative173.X*forward.X+worldRelative173.Y*forward.Y)/logicalUnit173;
             dx=-dWorldX173-xs173[group];dy=-dWorldY173-1.70f;
           }
           if(game.BossType==5&&mesh.crab175&&!mesh.newCrab445){
             float logicalUnit175=74f*.43f*Game.BossSize68;
             V worldRelative175=game.WorldDelta67(game.BossModuleDebrisPosition85[group],game.BossPosition);
             float dWorldX175=(worldRelative175.X*right.X+worldRelative175.Y*right.Y)/logicalUnit175;
             float dWorldY175=(worldRelative175.X*forward.X+worldRelative175.Y*forward.Y)/logicalUnit175;
             float[] xs175={-2.55f,-3.05f,-2.45f,2.55f,3.05f,2.45f};
             float[] ys175={2.25f,0f,-2.15f,2.25f,0f,-2.15f};
             dx=-(dWorldX175-xs175[group]);dy=-(dWorldY175-ys175[group]);
           }
           if(game.BossType==3){
             // v434 native GLB-to-world scale; avoid old 6.3936 Chronosphere scale.
             float unit434=74f*.43f*Game.BossSize68;
             float[] xs434={-1.65f,0f,1.65f};
             dx=(relative.X*right.X+relative.Y*right.Y)/unit434-xs434[group];
             dy=(relative.X*forward.X+relative.Y*forward.Y)/unit434-1.55f;
           }
           if(mesh.star448){
             // Module locations are the two opposite actual tentacle flanks.
             // Convert physical separation from world tangent units into this GLB's local model frame.
             float logicalUnit448=74f*.43f*Game.BossSize68;
             float dxWorld448=(relative.X*right.X+relative.Y*right.Y)/logicalUnit448;
             float dyWorld448=(relative.X*forward.X+relative.Y*forward.Y)/logicalUnit448;
             dx=dxWorld448-(group==0?-2.20f:2.20f);
             dy=dyWorld448;
           }
           if(game.BossType==0&&!mesh.star448){
             // Convert world-space debris travel back into the 180-degree-
             // corrected GLB frame. At sever time the transform is identity,
             // so the limb never teleports away from its shoulder.
             dx=-dx-(group==0?-3.15f:3.15f);
             dy=-dy+3.79f;
           }
           shipTranslate(dx,dy,Game.BossDebrisHeight85(detached));
           float px=mesh.pivots85[group,0],py=mesh.pivots85[group,1],pz=mesh.pivots85[group,2];
           // Restrict the corrected rotation pivot to Kolos. Other campaign
           // bosses retain their established debris transform unchanged.
           if(game.BossType==0||game.BossType==3)shipTranslate(px,py,pz);
           shipRotate((game.BossModuleDebrisAim85[group]-game.BossAim+game.BossModuleDebrisSpin85[group]*detached)*180/Game.PI,0,0,1);
           shipRotate((float)Math.Sin(detached*3)*31,1,0,0);
           shipTranslate(-px,-py,-pz);
           AnimateBossGroup87(game,group,mesh,game.BossModuleBrokenAt84[group]);
           if(game.BossType==0&&!mesh.star448)AnimateKolosDrill156(partIndex,game.BossModuleBrokenAt84[group],game.BossStage);
           planetMultiply(p.frames[game.BossModuleBreakFrame85[group]]);
         }else{
           if(group>=0){
             AnimateBossGroup87(game,group,mesh,time);
             if(mesh.scout173){
               // Mass/spring simulation is stepped in Game, NEVER inside drawing.
               // A small progressive deflection down the fourteen articulated
               // pieces makes the whip trail behind a turning hull.  Anchors
               // remain in the source GLB local frame; no triangle-level motion.
               int joint179=Math.Max(0,Math.Min(13,partIndex-18-group*14));
               float progression179=joint179/13f;
               // Respect the true GLB chain; group roots are fixed to the hull.
               // Coupled downstream spring angles lag the steering input like braids.
               float angle179=game.ScoutBraidAngle179[group,joint179]*(.25f+.72f*progression179);
               float pitch179=game.ScoutBraidLift179[group,joint179]*(.18f+.42f*progression179);
               if(Math.Abs(angle179)+Math.Abs(pitch179)>.0005f){
                 float px=mesh.pivots85[group,0],py=mesh.pivots85[group,1],pz=mesh.pivots85[group,2];
                 shipTranslate(px,py,pz);
                 shipRotate(angle179,0,0,1);
                 shipRotate(-pitch179,1,0,0);
                 shipTranslate(-px,-py,-pz);
               }
             }else if(!mesh.crab175){
               // Legacy impact kicks are intentionally kept on other bosses.
               float age=game.Time-game.BossModuleHitAt85[group];
               float recoil=age>=0&&age<.43f?(float)Math.Sin(age*39)*17*(float)Math.Exp(-age*8):0;
               float grab=game.BossType==1&&game.BossGrabModule85==group&&game.BossGrabTelegraph85>0
                 ?(float)Math.Sin((.75f-game.BossGrabTelegraph85)/.75f*Math.PI)*25:0;
               if(recoil!=0||grab!=0){
                 shipTranslate(mesh.pivots85[group,0],mesh.pivots85[group,1],mesh.pivots85[group,2]);
                 shipRotate(recoil+grab,0,0,1);
                 shipTranslate(-mesh.pivots85[group,0],-mesh.pivots85[group,1],-mesh.pivots85[group,2]);
               }
             }
           }
           if(game.BossType==0&&!mesh.star448)AnimateKolosDrill156(partIndex,time,game.BossStage);
           float[][] clipFrames173=p.frames;
           float phase173=time*(1+.12f*(game.BossStage-1));
           int clip174=-1;
           if((mesh.scout173||mesh.crab175)&&p.scoutClips173!=null){
             clip174=AnimatedClip175(game,mesh);
             // v446: per-leg gait is not interrupted by gunfire, recoil or charging.
             // The six animated hip/knee pairs must follow movement even when weapons fire.
             if(mesh.newCrab445&&!mesh.star448&&group>=0&&game.CrabAltitude191<=.18f&&!game.CrabAirborne196&&game.CrabWalkSpeed181>4f)
               clip174=(game.BossAngularSpeed157>.92f?2:game.BossAngularSpeed157<-.92f?3:1);
             // Walking legs are driven by traveled distance even while the
             // upper guns fire; the original GLB walk clip remains intact.
             if(mesh.crab175&&!mesh.newCrab445&&group>=0){clip174=(game.CrabAltitude191>.18f||(game.CrabAirborne196&&game.CrabFlightBlend183>.10f))?0:(game.CrabWalkSpeed181>4f?1:0);}
             clipFrames173=p.scoutClips173[clip174];
             phase173=mesh.star448?StarPhase448(game,clip174):mesh.scout173?Game.ScoutPhase174(game,clip174):mesh.newCrab445?Game.CrabVisualPhase445(game,clip174):Game.CrabPhase175(game,clip174);
             if(mesh.crab175&&!mesh.newCrab445&&group>=0&&(game.CrabAltitude191>.18f||(game.CrabAirborne196&&game.CrabFlightBlend183>.10f)))phase173=0f;
           }
           InterpolateBossTransform87(clipFrames173,phase173,interpolatedBossMatrix87);
           if(mesh.scout173||mesh.crab175){
             // Switch clips smoothly, even when taking repeated damage during a
             // charge; no sudden snap to a different absolute GLB transform.
             float age174=mesh.star448?999f:game.Time-(mesh.scout173?game.ScoutClipChanged174:game.CrabClipChanged175);
             int prevClip174=mesh.scout173?game.ScoutClipPrevious174:mesh.newCrab445?Game.CrabMapVisualClip445(game.CrabClipPrevious175):game.CrabClipPrevious175;
             float prevPhase174=mesh.scout173?game.ScoutClipPreviousPhase174:mesh.newCrab445?Game.CrabVisualPhase445(game,Math.Max(0,prevClip174)):game.CrabClipPreviousPhase175;
             if(!(mesh.crab175&&!mesh.newCrab445&&group>=0)&&prevClip174>=0&&prevClip174<p.scoutClips173.Length&&age174>=0&&age174<.30f){
               float blend174=age174/.30f;blend174=blend174*blend174*(3f-2f*blend174);
               InterpolateBossTransform87(p.scoutClips173[prevClip174],prevPhase174,scoutTransitionMatrix174);
               BossPose88.BlendRigid(scoutTransitionMatrix174,interpolatedBossMatrix87,blend174,interpolatedBossMatrix87);
             }
             // Preserve authored emitter/thruster scale; the interpolator
             // reconstructs orientation and translation, but drops scale.
             float tick173=(phase173%4+4)%4*12;
             int fa173=(int)Math.Floor(tick173)%48,fb173=(fa173+1)%48;
             float blend173=tick173-(float)Math.Floor(tick173);
             for(int col173=0;col173<3;col173++){
               float[] a173=clipFrames173[fa173],b173=clipFrames173[fb173];int k173=col173*4;
               float sa173=(float)Math.Sqrt(a173[k173]*a173[k173]+a173[k173+1]*a173[k173+1]+a173[k173+2]*a173[k173+2]);
               float sb173=(float)Math.Sqrt(b173[k173]*b173[k173]+b173[k173+1]*b173[k173+1]+b173[k173+2]*b173[k173+2]);
               float scale173=sa173*(1-blend173)+sb173*blend173;
               for(int ax173=0;ax173<3;ax173++)interpolatedBossMatrix87[k173+ax173]*=scale173;
             }
           }
           if(mesh.scout173&&group>=0&&game.BossModuleHealth84[group]>0){
             // Terrain probe under each real GLB segment (after clip interpolation).
             // The mass-spring state is stepped separately in Game; the small final
             // terrain projection prevents fast pose changes from penetrating rocks.
             int joint180=Math.Max(0,Math.Min(13,partIndex-18-group*14));
             float nativeX180=interpolatedBossMatrix87[0]*p.cx169+interpolatedBossMatrix87[4]*p.cy169+interpolatedBossMatrix87[8]*p.cz169+interpolatedBossMatrix87[12];
             float nativeY180=interpolatedBossMatrix87[1]*p.cx169+interpolatedBossMatrix87[5]*p.cy169+interpolatedBossMatrix87[9]*p.cz169+interpolatedBossMatrix87[13];
             float nativeZ180=interpolatedBossMatrix87[2]*p.cx169+interpolatedBossMatrix87[6]*p.cy169+interpolatedBossMatrix87[10]*p.cz169+interpolatedBossMatrix87[14];
             float scale180=74f*.43f*Game.BossSize68*Scale67;
             float terrainCorrection180=0;
             if(planet!=null&&game.SphereActive67&&scale180>.01f){
               V point180=game.BossLocalGround180(nativeX180,nativeY180,false);
               IntroScene41.P radial180=Sphere67.Normal(point180);
               float terrainRadius180=PlanetCrawler.Height(planet,new PlanetCrawler.P(radial180.X,radial180.Y,radial180.Z))*100f;
               float expectedRadius180=Shell67+(game.BossLift179+nativeZ180)*scale180;
               terrainCorrection180=Math.Max(0f,Math.Min(2.2f,(terrainRadius180+1.2f-expectedRadius180)/scale180));
             }
             float spring180=game.ScoutTerrainLift180[group,joint180];
             shipTranslate(0,0,Math.Max(spring180,terrainCorrection180)+game.ScoutBraidLift179[group,joint180]*.008f);
           }
           if(mesh.crab175&&!mesh.newCrab445&&group>=0&&group<6&&game.BossModuleHealth84[group]>0){
             // Split the terrain-driven foot correction across shin, ankle and
             // talon. Hip and knee stays attached to the authored GLB animation.
             int piece180=partIndex-(50+group*16);
             float weight180=piece180<=5?0f:piece180<=7?.15f:piece180<=11?.39f:piece180<=12?.68f:piece180<=14?.90f:1f;
             if(game.CrabAltitude191<.18f&&!game.CrabAirborne196){
               // v198: exact rest-space joint sockets read from Crab_Siege_Boss_v3_ANIMOWANY GLB.
               // Six distinct hip and knee coordinates; no generic pivot reused across legs.
               float hx198=CrabHipX198[group],hy198=CrabHipY198[group],hz198=1.64f;
               float kx198=hx198+CrabKneeDX198[group],ky198=hy198+CrabKneeDY198[group],kz198=hz198+CrabKneeDZ198[group];
               float radialX198=kx198-hx198,radialY198=ky198-hy198;
               float radialLength198=(float)Math.Sqrt(radialX198*radialX198+radialY198*radialY198);
               float axisX198=radialLength198>.001f?-radialY198/radialLength198:0f;
               float axisY198=radialLength198>.001f?radialX198/radialLength198:1f;
               float hip198=game.CrabHipIK197[group],knee198=game.CrabKneeIK197[group];
               // The gear ring stays on the hull; the upper arm rotates about the hip.
               // Lower shin/talon rotate about both sockets, respecting rigid GLB meshes.
               if(piece180>=1&&Math.Abs(hip198)>.001f){
                shipTranslate(hx198,hy198,hz198);
                shipRotate(hip198,axisX198,axisY198,0);
                shipTranslate(-hx198,-hy198,-hz198);
               }
               if(piece180>=4&&Math.Abs(knee198)>.001f){
                shipTranslate(kx198,ky198,kz198);
                shipRotate(knee198,axisX198,axisY198,0);
                shipTranslate(-kx198,-ky198,-kz198);
               }
             }
             if(weight180>0){
               float x180=game.CrabFootSlipY180[group],y180=-game.CrabFootSlipX180[group];
               shipTranslate(x180*weight180,y180*weight180,game.CrabFootOffset180[group]*weight180);
             }
           }
           if(mesh.crab175&&!mesh.newCrab445&&game.BossType==5){
             // v176: rotate only the actual gatling barrels, not the whole gun assemblies.
             // The spin axis follows the real barrel centerline from the imported GLB.
             if(partIndex==165||partIndex==166){
               const float px=4.10f,py=1.705f,pz=1.465f;
               shipTranslate(px,py,pz);shipRotate(game.CrabBarrelAngle178,1,0,0);shipTranslate(-px,-py,-pz);
             }else if(partIndex==190||partIndex==191){
               const float px=4.10f,py=-1.705f,pz=1.465f;
               shipTranslate(px,py,pz);shipRotate(game.CrabBarrelAngle178,1,0,0);shipTranslate(-px,-py,-pz);
             }
           }
           planetMultiply(interpolatedBossMatrix87);
         }
   }
   void PrepareGalleryShadows169(Game game,float time,GalleryModel82 mesh){
    bossShadowCount169=0;
    if(disableBossShadows169||getMatrix169==null||setShadowSpheres169==null||bossShadowCountLoc169<0||bossShadowSpheresLoc169<0||mesh.shadowParts169.Length==0)return;
    for(int n=0;n<mesh.shadowParts169.Length;n++){
     int idx=mesh.shadowParts169[n];GalleryPart82 p=mesh.parts[idx];
     int group=mesh.newCrab445?p.newCrabGroup445:Game.BossMeshGroup84(game.BossType,idx);
     if(group<0||game.BossModuleHealth84[group]<=0)continue; // destroyed arm cannot shadow intact chassis
     planetPush();
     try{
      ApplyGalleryPose169(idx,group,-1,time,game,mesh,p);
      getMatrix169(0x0BA6,bossShadowMatrix169); // actual OpenGL MODELVIEW matrix
      BossShadow169.Eye(bossShadowMatrix169,p.cx169,p.cy169,p.cz169,p.radius169*1.45f,bossShadowData169,bossShadowCount169);
      bossShadowPartSlots169[bossShadowCount169++]=idx;
     }finally{planetPop();}
    }
    // Set constant per-frame caster positions once; a single integer changes per part.
    useToon60(toonProgram60);
    setShadowSpheres169(bossShadowSpheresLoc169,BossShadow169.MaxCasters,bossShadowData169);
    useToon60(0);
   }
   void DrawGalleryModel82(float time,Game game){
     GalleryModel82 mesh=GetGallery82(GalleryEnabled82?GalleryIndex82:campaignBossMesh83[activeCampaignBoss83]);
     GCHandle pinned=new GCHandle();GCHandle pinnedUV=new GCHandle();IntPtr ptr=IntPtr.Zero;
     try {
       if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){
         if(mesh.buffer==0){genBuffers(1,out mesh.buffer);pinned=GCHandle.Alloc(mesh.vertices,GCHandleType.Pinned);bindBuffer(0x8892,mesh.buffer);bufferData(0x8892,new IntPtr(mesh.vertices.Length*4),pinned.AddrOfPinnedObject(),0x88E4);}
         else bindBuffer(0x8892,mesh.buffer);
       } else {pinned=GCHandle.Alloc(mesh.vertices,GCHandleType.Pinned);ptr=pinned.AddrOfPinnedObject();}
       if(mesh.newCrab445){
        if(mesh.crabTexture446==0)mesh.crabTexture446=Texture(mesh.crabBitmap446);
        if(mesh.crabUVBuffer446==0&&genBuffers!=null&&bindBuffer!=null&&bufferData!=null){
         genBuffers(1,out mesh.crabUVBuffer446);pinnedUV=GCHandle.Alloc(mesh.crabUV446,GCHandleType.Pinned);bindBuffer(0x8892,mesh.crabUVBuffer446);bufferData(0x8892,new IntPtr(mesh.crabUV446.Length*4),pinnedUV.AddrOfPinnedObject(),0x88E4);
        }
       }
       // The position VBO is kept bound for glVertex/Normal/ColorPointer.
       if(mesh.buffer!=0)bindBuffer(0x8892,mesh.buffer);
       enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);
       vertexPointer(3,0x1406,40,ptr);shipNormal(0x1406,40,new IntPtr(ptr.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(ptr.ToInt64()+24));
       shipMaterial(0x0408,0x1202,specular);shipShine(0x0408,0x1601,60);
       if(mesh.newCrab445){
        // Separate UV VBO, same vertex sequence, for original GLB baseColor JPEG.
        enableClient(0x8078);
        if(mesh.crabUVBuffer446!=0){bindBuffer(0x8892,mesh.crabUVBuffer446);uvPointer(2,0x1406,8,IntPtr.Zero);}
        else{pinnedUV=GCHandle.Alloc(mesh.crabUV446,GCHandleType.Pinned);bindBuffer(0x8892,0);uvPointer(2,0x1406,8,pinnedUV.AddrOfPinnedObject());}
        if(mesh.buffer!=0)bindBuffer(0x8892,mesh.buffer);
        enable(TEX);bindTexture(TEX,mesh.crabTexture446);
       }
       // v450: stateful, damped, gravity-loaded chain for 4 sections of each
       // tentacle. Update ONCE per frame, not once per triangle or draw call.
       // Authored skeleton clips are frozen to the rest frame above.
       if(mesh.star448){
         float travel450=game.BossVelocity68.Length;
         float motion450=Math.Max(0f,Math.Min(1f,travel450/95f));
         float backX450=0f,backY450=0f;
         if(travel450>.01f){
           V f450=Game.Direction(game.BossAim),r450=Game.Direction(game.BossAim-Game.PI/2f),v450=game.BossVelocity68;
           backX450=-(v450.X*r450.X+v450.Y*r450.Y)/travel450;
           backY450=-(v450.X*f450.X+v450.Y*f450.Y)/travel450;
         }
         starMotion450.Advance(time,motion450,backX450,backY450);
         if(starSpringLoc450>=0){useToon60(toonProgram60);skinVectors65(starSpringLoc450,4,starMotion450.Uniforms);useToon60(0);}
       }
       BossLimbDraws87=0;BossLimbHidden87=0;
       PrepareGalleryShadows169(game,time,mesh);
       for(int partIndex=0;partIndex<mesh.parts.Length;partIndex++){
         GalleryPart82 p=mesh.parts[partIndex];
         int group=GalleryEnabled82?-1:(mesh.newCrab445?p.newCrabGroup445:Game.BossMeshGroup84(game.BossType,partIndex));
         if(group==-2){BossLimbHidden87++;continue;}
         float detached=group>=0&&game.BossModuleHealth84[group]<=0?game.Time-game.BossModuleBrokenAt84[group]:-1;
         if(detached>=Game.BossDebrisLifetime85)continue;
         planetPush();
         ApplyGalleryPose169(partIndex,group,detached,time,game,mesh,p);
         if(group>=0)BossLimbDraws87++;
         BeginToon60(true,mesh.newCrab445&&(mesh.star448||partIndex<17));
         if(starWaveFlag449>=0)uniform60(starWaveFlag449,mesh.star448&&detached<0?1:0);
         if(mesh.star448&&detached<0&&starWaveTime449>=0)waterFloat65(starWaveTime449,time);

         BossFinish168 material=BossMaterials168.ForPart(game.BossType,group,p.saturation168,p.luminance168,detached>=0);
         if(crabTextureFlag446>=0)uniform60(crabTextureFlag446,mesh.newCrab445&&(mesh.star448||partIndex<17)?1:0);
         if(mesh.newCrab445&&!mesh.star448)material=partIndex>=17?new BossFinish168(.04f,.85f,1f,.65f,1f,.28f,.04f):new BossFinish168(.16f,.68f,.95f,.03f,.55f,.68f,.85f);
         if(mesh.star448)material=new BossFinish168(.04f,.90f,.98f,.01f,1f,1f,1f); // preserve original GLB base color, do not use Kolos blue palette
         SetBossShade168(material.Metal,material.Rough,material.Cavity,material.Glow*(1f+(game.BossFireTime>0?.85f:0f)+(game.BossFlash>0?.45f:0f)),material.R,material.G,material.B);
         if(bossShadowIgnoreLoc169>=0){int ignore169=-1;for(int s169=0;s169<bossShadowCount169;s169++)if(bossShadowPartSlots169[s169]==partIndex){ignore169=s169;break;}uniform60(bossShadowIgnoreLoc169,ignore169);}
         drawArrays(4,p.start,p.count);EndToon60();DrawCalls++;SubmittedVertices+=p.count;
         planetPop();
       }
       disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);
       if(mesh.newCrab445){disableClient(0x8078);disable(TEX);}
       if(mesh.buffer!=0)bindBuffer(0x8892,0);
     }finally{if(pinned.IsAllocated)pinned.Free();if(pinnedUV.IsAllocated)pinnedUV.Free();}
   }
   int activeCampaignBoss83;
   internal bool HasCampaignBossAsset83(Game g){
     if(GalleryEnabled82)return true;
     int type=Math.Max(0,Math.Min(5,g.BossType));
     int number=campaignBossMesh83[type]+1,variant=campaignVariant83[type]+1;
     string filename=type==4?"alien_scout_173.b82":type==5?"new_crab_446.b82":type==0?"starfish_448.b82":"boss_"+number.ToString("00")+"_"+variant+".b82";
     return HasEmbeddedBoss88(filename)||File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets_Boss82",filename));
   }
   void DrawGalleryBossWorld82(Game g,bool animated){
     activeCampaignBoss83=Math.Max(0,Math.Min(5,g.BossType));
     int variant=GalleryEnabled82?GalleryVariant82:campaignVariant83[activeCampaignBoss83];
     // This is the same world transform and actual depth-buffered camera used by real boss fights.
     planetPush();StampSphere67(g.BossPosition,g.BossAim,74*Game.BossSize68*Scale67*.43f*g.BossArrivalScale86);
     // The Kolos GLB points along local -Y, whereas StampSphere67's +Y
     // points toward BossAim. Turn its chassis and both drills as one unit.
     if(g.BossType==4)shipRotate(180,0,0,1); // new starfish model has no legacy Kolos heading correction
     if(g.BossType==5){
       // v182: world-to-ground fix. StampSphere67 positions the chassis at the
       // *124-unit camera/navigation shell*, NOT on the procedural planet.
       // v181 correctly computed CrabBodyHeight181 but never applied it here:
       // the boss hovered ~24 world units above its feet on level 24.
       // v446: glTF crab faces +Z, converted to gameplay-local +Y.
       // The +90° correction was for the REMOVED siege crab and made this model walk sideways.
       if(!GetGallery82(GalleryEnabled82?GalleryIndex82:campaignBossMesh83[activeCampaignBoss83]).newCrab445)shipRotate(90,0,0,1);
       shipTranslate(.55f,0,g.CrabRenderBodyZ182);
       shipRotate(g.CrabGroundRoll175,0,1,0);
       shipRotate(g.CrabGroundPitch175,1,0,0);
       shipTranslate(0,0,g.CrabBodyBob175*0.010f);
     }
     else {
       // v179: attitude follows acceleration and steering, not ornamental sine waves.
       shipTranslate(0,0,g.BossLift179);
       shipRotate(g.BossBank179,0,1,0);
       shipRotate(g.BossPitch179,1,0,0);
     }
     if(g.BossType!=4&&g.BossType!=5){
       if(g.BossType==0){/* v448: keep authored starfish proportions */}
       else if(variant==1)shipScale(1.08f,.97f,1.07f);
       else if(variant==2)shipScale(.97f,1.12f,1.04f);
       else if(variant==3)shipScale(1.08f,1.06f,.95f);
     }
     // World-space sun lighting is prepared by SphereScene67 before the boss transform.
     // Do not reset it here, or the light will stick to the boss and ignore the planet's day/night side.
     enable(DEPTH);disable(TEX);disable(BLEND);
     // Animation accelerates subtly through the established three combat phases.
     bossDrawing168=true;
     // v435: the hull becomes nearly black in planetary shadow but its
     // authored emission, shots and independently drawn engine flames remain alive.
     SetBossDaylight435(PlanetLightEnabled436?BossDaylight435(g.BossPosition,sunClock436,sunAnimated436,PlanetNightBrightness437):1f);
     try{DrawGalleryModel82(g.Time+(g.BossArrivalActive86?g.BossArrivalTime86:0),g);DrawBossEngines179(g);}
     finally{SetBossDaylight435(1f);bossDrawing168=false;EndToon60();planetPop();}
   }
   // Procedural, depth-tested exhaust jets positioned on the authored chassis.
   // Light output varies with measured acceleration and inertial throttle.
   public int BossEngineTriangles179{get;private set;}
   bool bossEngineDiagnosed179;
   void BossEngineJet179(float x,float y,float z,float dx,float dy,float dz,float span,float radius,float power,float clock,int seed,int boss){
     float jitter=(float)Math.Sin(clock*15.0f+seed*1.74f)*.10f;
     float r=radius*(.88f+.14f*power);
     float length=span*(.55f+.95f*power)*(1+jitter);
     int slices=18;
     for(int layer=0;layer<2;layer++){
       float rr=r*(layer==0?1.7f:.75f),ll=length*(layer==0?1.18f:.76f);
       float alpha=layer==0?.16f+.14f*power:.38f+.32f*power;
       float cr=boss==1?.35f:boss==4?.28f:.45f;
       float cg=boss==1?.96f:boss==4?.85f:.72f;
       float cb=boss==1?.52f:1f;
       begin(4);
       for(int i=0;i<slices;i++){
         float a=i*(float)(Math.PI*2/slices),b=(i+1)*(float)(Math.PI*2/slices);
         // A true 3D cross-section perpendicular to the nozzle axis.
         bool belly179=Math.Abs(dz)>.65f;
         float x1=x+(float)Math.Cos(a)*rr;
         float x2=x+(float)Math.Cos(b)*rr;
         float y1=belly179?y+(float)Math.Sin(a)*rr:y;
         float y2=belly179?y+(float)Math.Sin(b)*rr:y;
         float z1=belly179?z:z+(float)Math.Sin(a)*rr;
         float z2=belly179?z:z+(float)Math.Sin(b)*rr;
         color(cr,cg,cb,alpha);vertex(x1,y1,z1);
         color(cr,cg,cb,alpha);vertex(x2,y2,z2);
         color(.28f,.80f,1f,0);vertex(x+dx*ll,y+dy*ll,z+dz*ll);
       }
       end();BossEngineTriangles179+=slices;DrawCalls++;SubmittedVertices+=slices*3;
     }
   }
   // Solid mounting sleeve: the jet begins at the sleeve lip, not in empty space.
   void CrabNozzleMount192(float x,float y,float z){
     const int sides=12;
     float r=.19f,top=z+.30f,bottom=z-.055f;
     begin(4);
     for(int j=0;j<sides;j++){
       float a=(float)(j*Math.PI*2/sides),b=(float)((j+1)*Math.PI*2/sides);
       float ax=x+r*(float)Math.Cos(a),ay=y+r*(float)Math.Sin(a);
       float bx=x+r*(float)Math.Cos(b),by=y+r*(float)Math.Sin(b);
       color(.22f,.27f,.32f,1);vertex(ax,ay,top);vertex(bx,by,top);vertex(ax,ay,bottom);
       color(.12f,.16f,.22f,1);vertex(ax,ay,bottom);vertex(bx,by,top);vertex(bx,by,bottom);
       color(.39f,.65f,.80f,1);vertex(ax,ay,bottom);vertex(bx,by,bottom);vertex(x,y,bottom);
     }
     end();BossEngineTriangles179+=sides*3;DrawCalls++;SubmittedVertices+=sides*9;
   }
   void DrawBossEngines179(Game g){
     if(!g.BossActive||g.BossArrivalScale86<.15f)return;
     float power=g.BossType==5?g.CrabFlightBlend183:g.BossType==3?Math.Max(.26f,g.BossEngine179):g.BossEngine179;
     if(power<.015f)return;
     // Draw with fixed-function colors, not boss surface shader: emissive exhaust.
     EndToon60();disable(TEX);disable(0x0B50);disable(0x0B44);enable(DEPTH);enable(BLEND);depthMask(0);blendFunc(0x0302,1);
     BossEngineTriangles179=0;
     if(g.BossType==3){
       // v434 actual imported Tripo boss is Y-up with original lower surface
       // at Y=0. Converter maps that surface to local Z=-1.875.
       // All four exhausts point down into world Z-, pulse with thrust and
       // bank, but DO NOT distort or rotate the imported GLB's rigid chassis.
       // Actual underside circular outlets checked against original GLB
       // positions: (X,Z) +/- (.40,.33) and +/- (.35,-.16).
       // Rotate to native game XY=(7.5*X,-7.5*Z), not arbitrary air points.
       float thrust434=Math.Max(.26f,Math.Min(1f,power+.10f));
       float bank434=Math.Max(-.25f,Math.Min(.25f,g.BossBank179/50f));
       for(int side434=-1;side434<=1;side434+=2){
        float boost434=Math.Max(.12f,Math.Min(1f,thrust434+side434*bank434));
        BossEngineJet179(side434*3.00f,-2.475f,-1.50f,0,0,-1,
          1.02f,.205f,boost434,g.BossEnginePulse179,20+side434,g.BossType);
        BossEngineJet179(side434*2.625f,1.20f,-1.32f,0,0,-1,
          .92f,.175f,boost434,g.BossEnginePulse179,30+side434,g.BossType);
       }
     }else if(g.BossType==5){
       // Engine exhaust from the underside of the imported crab chassis.
       // Thrusters attach to the belly of the SAME chassis frame used by the GLB.
       // A physical mounting collar is drawn at each exhaust origin.
       // v445: nine actual local thruster positions from new GLB (Y-up -> Z-up, scale 7).
       float thrust=Math.Max(.08f,Math.Min(1f,power*.8f+Math.Max(0f,g.CrabVerticalVelocity192)*.16f));
       float[] sockets445={-.875f,1.554f,-1.015f, .875f,1.554f,-1.015f,
         -1.575f,.665f,-1.015f,1.575f,.665f,-1.015f,
         -.945f,-.420f,-1.001f,.945f,-.420f,-1.001f,
         -.980f,-1.925f,-1.050f,0f,-1.925f,-1.071f,.980f,-1.925f,-1.050f};
       for(int nozzle445=0;nozzle445<9;nozzle445++){
        int j445=nozzle445*3;
        float nx=sockets445[j445],ny=sockets445[j445+1],nz=sockets445[j445+2];
        CrabNozzleMount192(nx,ny,nz);
        BossEngineJet179(nx,ny,nz,0,0,-1,.66f,.115f,thrust,g.Time,70+nozzle445,5);
       }
     }else if(g.BossType==4){
       // Source GLB: rear connector + bilateral stabilizers; belly nozzle z=-.76.
       BossEngineJet179(-.58f,1.12f,-.25f,0,1,.18f,.90f,.17f,power,g.BossEnginePulse179,0,g.BossType);
       BossEngineJet179(.58f,1.12f,-.25f,0,1,.18f,.90f,.17f,power,g.BossEnginePulse179,1,g.BossType);
       BossEngineJet179(0,-1.20f,-.76f,0,-.15f,-1f,.48f,.21f,power,g.BossEnginePulse179,2,g.BossType);
     }else if(g.BossType==1){
       BossEngineJet179(-1.8f,1.20f,-.20f,0,1,0,.68f,.20f,power,g.BossEnginePulse179,3,g.BossType);
       BossEngineJet179(1.8f,1.20f,-.20f,0,1,0,.68f,.20f,power,g.BossEnginePulse179,4,g.BossType);
     }else{
       float sep=g.BossType==3?1.45f:2.0f;
       BossEngineJet179(-sep,1.30f,-.28f,0,1,.08f,.68f,.18f,power,g.BossEnginePulse179,5,g.BossType);
       BossEngineJet179(sep,1.30f,-.28f,0,1,.08f,.68f,.18f,power,g.BossEnginePulse179,6,g.BossType);
     }
     depthMask(1);disable(BLEND);enable(0x0B50);
     if(!bossEngineDiagnosed179&&BossEngineTriangles179>0&&Environment.GetEnvironmentVariable("ASTEROIDY_DIAG_179")=="1") {Console.WriteLine("BOSS179 EXHAUST TRIANGLES="+BossEngineTriangles179+" power="+power.ToString("F2"));bossEngineDiagnosed179=true;}
   }
   void DisposeGallery82(){for(int i=0;i<galleryModels82.Length;i++)if(galleryModels82[i]!=null){
     GalleryModel82 model=galleryModels82[i];uint v=model.buffer;if(v!=0)deleteBuffers(1,ref v);
     v=model.crabUVBuffer446;if(v!=0)deleteBuffers(1,ref v);
     if(model.crabBitmap446!=null){model.crabBitmap446.Dispose();model.crabBitmap446=null;}
     galleryModels82[i]=null;}}
 }
}
