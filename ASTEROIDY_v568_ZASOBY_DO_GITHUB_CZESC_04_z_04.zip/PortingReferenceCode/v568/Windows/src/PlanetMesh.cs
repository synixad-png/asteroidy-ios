using System;using System.Drawing;using System.Collections.Generic;
namespace Asteroidy {
 // A closed displaced icosphere. All terrain and vegetation are generated once per level.
 sealed class PlanetMesh {
  public struct P {public float X,Y,Z;public P(float x,float y,float z){X=x;Y=y;Z=z;}public static P operator +(P a,P b){return new P(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}public static P operator -(P a,P b){return new P(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}public static P operator *(P a,float s){return new P(a.X*s,a.Y*s,a.Z*s);}public float Length{get{return (float)Math.Sqrt(X*X+Y*Y+Z*Z);}}public P Unit{get{return this*(1/Math.Max(.00001f,Length));}}}
  struct Crater {public P Center;public float Radius;}
  readonly List<float> vertices=new List<float>(1000000);readonly Crater[] craters=new Crater[14],volcanoes=new Crater[3];readonly List<float> lava=new List<float>();readonly bool hub52;readonly int seed;Random rng;P[] faultSamples258;P[] faultMidpoints271;public bool Basalt110{get{return seed==1&&!IsCarbonis277;}}
  // v109: true radial plateau in the atlas planet mesh, not a fake base-sized box.
  P siteNormal109;float siteHeight109;bool hasSite109;
  bool InsideSite109(P n,float meters){return hasSite109&&(n-siteNormal109).Length*100f<meters;}
  public readonly PlanetBiome Biome;public float WaterRadius{get{return Biome.Sea;}}public bool IsVulkaris276{get{return seed==Vulkaris276.Level;}}public bool IsCarbonis277{get{return seed==Carbonis277.Level&&!hub52;}}public readonly int LavaStart,LavaVertices;
  public readonly float[] Vertices;public readonly int TerrainVertices,NatureVertices,WaterVertices;public readonly int TreeCount,CrystalCount;public readonly float MinRadius,MaxRadius;
  bool AmigaBoing262{get{return !hub52&&seed==Game.CampaignLength;}}
  int CraterCount{get{return AmigaBoing262?0:Biome.Kind==1?2:Biome.Kind==0?4:Biome.Kind==2?0:Biome.Kind==3?5:Biome.Kind==5?5:Biome.Kind==8?6:14;}}
  static P Cross(P a,P b){return new P(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);}static float Dot(P a,P b){return a.X*b.X+a.Y*b.Y+a.Z*b.Z;}static float AngleDiff113(float a,float b){float d=a-b;while(d>(float)Math.PI)d-=(float)(Math.PI*2);while(d<-(float)Math.PI)d+=(float)(Math.PI*2);return d;}
  static float Noise(P p,int s){return (float)(Math.Sin(p.X*7.1+p.Y*3.4+p.Z*5.3+s*.73)*Math.Cos(p.Y*6.5-p.Z*4.2+s*.37)*.5+Math.Sin(p.X*13.7-p.Y*9.1+p.Z*11.3+s)*.18);}
  // Cold ancient basalt: large shield-lava fields, weathered escarpments, subdued ridges.
  // Deterministic in object coordinates; the landing-zone flattening below is preserved.
  static float BasaltHeight110(P n){
   float warp=Noise(n*2.2f,59),w=Noise(n*1.45f,71);
   P p=new P(n.X+warp*.075f,n.Y+w*.05f,n.Z-warp*.06f).Unit;
   float plains=Noise(p*.78f,23),r=Noise(p*3.3f,42);
   float ridge=(float)Math.Pow(Math.Max(0f,1f-Math.Abs(r*1.85f)),4.0);
   // v121: avoid linear sine strata: periodic layers made screen-space latitude bands.
   float weathering=Noise(p*8.3f,97)*.66f+Noise(p*23.7f,157)*.34f;
   float high=Math.Max(0f,plains+.06f);
   float broad=1.014f+plains*.028f+ridge*high*.115f;
   float erosion=(float)Math.Pow(Math.Max(0f,1f-Math.Abs(weathering)),3f)*.0030f*high;
   return Math.Max(.963f,Math.Min(1.138f,broad+erosion));
  }
  public static Color BasaltTint110(P n,float h){
   // v121: spherical 3D noise rather than a planar sinusoidal colour band.
   float patch=Noise(n*2.35f,141),fine=Noise(n*16f,155),flow=Noise(n*6.1f,17)*.7f+Noise(n*13.7f,118)*.3f;
   float elevation=Math.Max(0f,Math.Min(1f,(h-1.0f)*9.5f));
   Color dark=Color.FromArgb(72,79,86),slate=Color.FromArgb(99,109,119),weathered=Color.FromArgb(133,138,138);
   float mix=Math.Max(0f,Math.Min(1f,.35f+patch*.51f+elevation*.37f+fine*.10f));
   Color tone=Mix(dark,slate,mix);
   float dust=Math.Max(0f,Math.Min(.46f,(.21f-elevation*.17f)+flow*.09f+fine*.05f));
   return Mix(tone,weathered,dust);
  }
  // v242: these features exist ONLY on the main orbital world (detail >=6,
  // level 1); the first combat mission uses a different PlanetMesh and retains
  // its old heights, colours, collisions and gameplay.
  public bool OrbitAtlas242{get{return hub52&&Basalt110;}}
  static readonly P[] AtlasCraterCenters242={
   new P(.10f,.36f,.93f).Unit, new P(-.56f,-.13f,.82f).Unit,
   new P(.84f,.35f,-.42f).Unit,new P(-.26f,-.67f,-.69f).Unit,
   new P(.66f,-.52f,.54f).Unit,new P(-.89f,.35f,-.29f).Unit};
  static readonly float[] AtlasCraterRadius242={.37f,.29f,.25f,.27f,.21f,.18f};
  static float AtlasClamp242(float x){return Math.Max(0f,Math.Min(1f,x));}
  static float AtlasSmooth242(float x){x=AtlasClamp242(x);return x*x*(3f-2f*x);}
  static float AtlasCraterSuppress242(P n){
   float keep=1f;
   for(int i=0;i<AtlasCraterCenters242.Length;i++){
    float q=AtlasCraterProfile242(n,i);if(q<0f)continue;
    float local=AtlasSmooth242((q-.72f)/.34f);
    keep=Math.Min(keep,local);
   }
   return keep;
  }
  static P AtlasOrtho242(P axis,P helper){
   P side=Cross(axis,helper);
   if(side.Length<.0001f)side=Cross(axis,Math.Abs(axis.Y)<.9f?new P(0,1,0):new P(1,0,0));
   return side.Unit;
  }
  static float AtlasUnwrap242(float a,float pivot){
   float two=(float)(Math.PI*2);
   while(a-pivot>(float)Math.PI)a-=two;
   while(a-pivot<-(float)Math.PI)a+=two;
   return a;
  }
  static float AtlasArcFade242(float a,float start,float end,float edge){
   float two=(float)(Math.PI*2);
   float endAdj=end;
   if(endAdj<start)endAdj+=two;
   float mid=(start+endAdj)*.5f;
   float aa=AtlasUnwrap242(a,mid);
   if(aa<start||aa>endAdj)return 0f;
   float len=Math.Max(.0001f,endAdj-start),e=Math.Max(.0001f,Math.Min(edge,len*.45f));
   float fIn=AtlasClamp242((aa-start)/e),fOut=AtlasClamp242((endAdj-aa)/e);
   return AtlasSmooth242(fIn)*AtlasSmooth242(fOut);
  }
  static float AtlasFaultDistanceGeneric242(P n,P axis,P helper,float start,float end,float edge,float baseOffset,float ampA,float freqA,float phaseA,float ampB,float freqB,float phaseB,out float lengthFade){
   P side=AtlasOrtho242(axis,helper),forward=Cross(side,axis).Unit;
   float along=(float)Math.Atan2(Dot(n,side),Dot(n,forward));
   lengthFade=AtlasArcFade242(along,start,end,edge);
   float across=Dot(n,axis);
   float target=baseOffset+ampA*(float)Math.Sin(along*freqA+phaseA)+ampB*(float)Math.Sin(along*freqB+phaseB);
   return Math.Abs(across-target);
  }
  static float BasaltVolcanoProfile251(float q){
   if(q>=1.55f)return 0f;
   float bowl=1f-AtlasSmooth242(q/.20f);
   float innerWall=(float)Math.Exp(-Math.Pow((q-.27f)/.08f,2f));
   float rim=(float)Math.Exp(-Math.Pow((q-.48f)/.14f,2f));
   float apron=(float)Math.Exp(-Math.Pow((q-.82f)/.34f,2f));
   return -bowl*.018f+innerWall*.010f+rim*.054f+apron*.022f;
  }
  // Squared angular distance avoids expensive sqrt for most craters.
  static float AtlasCraterProfile242(P n,int i){
   float q2=2f-2f*Dot(n,AtlasCraterCenters242[i]),rad=AtlasCraterRadius242[i];
   if(q2>rad*rad*1.50f*1.50f)return -1f;
   return (float)Math.Sqrt(Math.Max(0f,q2))/rad;
  }
  // v253: tectonic fractures now use three different spherical directions
  // instead of several almost-parallel latitude bands.
  public static float AtlasFaultDistance242(P n,out float lengthFade){
   return AtlasFaultDistanceGeneric242(n,new P(.54f,.63f,-.56f).Unit,new P(0,1,0),-2.55f,-.15f,.34f,.015f,.16f,1.45f,.7f,.05f,4.5f,1.3f,out lengthFade);
  }
  public static float AtlasFaultDistanceB242(P n,out float lengthFade){
   return AtlasFaultDistanceGeneric242(n,new P(-.66f,.25f,.71f).Unit,new P(0,1,0),-.25f,2.10f,.30f,-.012f,.13f,1.90f,-1.0f,.04f,5.1f,.45f,out lengthFade);
  }
  public static float AtlasFaultDistanceC242(P n,out float lengthFade){
   return AtlasFaultDistanceGeneric242(n,new P(.18f,.94f,.29f).Unit,new P(1,0,0),1.45f,3.70f,.28f,.006f,.11f,1.60f,.2f,.05f,4.8f,-.75f,out lengthFade);
  }
  float AtlasFaultKeep253(P n){
   float keep=AtlasCraterSuppress242(n);
   if(Basalt110){
    for(int i=0;i<volcanoes.Length;i++){
     float q=(n-volcanoes[i].Center).Length/Math.Max(.0001f,volcanoes[i].Radius);
     float local=AtlasSmooth242((q-.96f)/.34f);
     keep=Math.Min(keep,local);
    }
   }
   if(hasSite109){
    float siteDist=(n-siteNormal109).Length*100f;
    float siteKeep=AtlasSmooth242((siteDist-44f)/18f);
    keep=Math.Min(keep,siteKeep);
   }
   return keep;
  }
  float AtlasRelief242(P n){
   float relief=0f;
   for(int i=0;i<AtlasCraterCenters242.Length;i++){
    float q=AtlasCraterProfile242(n,i);if(q<0f)continue;
    float pit=(1f-AtlasSmooth242(q/.90f));
    float rim=(float)Math.Exp(-Math.Pow((q-1.01f)/.15f,2f));
    relief-=pit*(i==0?.039f:i<3?.031f:.023f);
    relief+=rim*(i==0?.017f:.012f);
   }
   return relief;
  }
  // Mineral bands, crater floors and old scar coloration are baked once into
  // the orbital atlas texture. No per-frame texture reconstruction.
  public Color AtlasTint242(P n,float h){
   Color baseColor=BasaltTint110(n,h);
   float mineral=Noise(n*2.15f,362),iron=Noise(n*4.8f,255),dust=Noise(n*8.2f,117);
   Color stone=Mix(Color.FromArgb(83,94,103),Color.FromArgb(163,155,137),AtlasClamp242(.51f+mineral*.65f));
   stone=Mix(stone,Color.FromArgb(112,95,83),AtlasClamp242((iron-.17f)*.85f)*.27f);
   stone=Mix(stone,baseColor,.42f);
   float dark=0,rimLight=0;
   for(int i=0;i<AtlasCraterCenters242.Length;i++){
    float q=AtlasCraterProfile242(n,i);if(q<0)continue;
    dark=Math.Max(dark,(1f-AtlasSmooth242(q/.88f))*(i==0?.68f:.52f));
    rimLight=Math.Max(rimLight,(float)Math.Exp(-Math.Pow((q-1.03f)/.13f,2f))*.29f);
   }
   stone=Mix(stone,Color.FromArgb(38,47,59),dark);
   stone=Mix(stone,Color.FromArgb(187,182,168),rimLight);
   float grit=AtlasClamp242(.62f+dust*.18f);
   return CombatFaultTint254(n,h,Mix(stone,Color.FromArgb(111,115,118),(.09f+grit*.05f)));
  }
  float BasaltLavaMask113(P n){
   if(!Basalt110)return 0f;float best=0f;
   for(int i=0;i<volcanoes.Length;i++){
    P center=volcanoes[i].Center;
    // v271: skip the entire trigonometric volcano channel evaluation if it
    // cannot change the mask. The original channel/fan end at q < 1.30.
    // The conservative 1.31 margin makes this exact even at float boundaries.
    P delta271=n-center;float reach271=volcanoes[i].Radius*1.31f;
    if(delta271.X*delta271.X+delta271.Y*delta271.Y+delta271.Z*delta271.Z>reach271*reach271)continue;
    float q=delta271.Length/volcanoes[i].Radius;
    P u=Cross(center,Math.Abs(center.Y)<.93f?new P(0,1,0):new P(1,0,0)).Unit;if(u.Length<.001f)u=new P(1,0,0);
    P v=Cross(center,u).Unit;float angle=(float)Math.Atan2(Dot(n,v),Dot(n,u));
    if(q<.22f){best=Math.Max(best,.92f+(.22f-q)*.55f);continue;}
    for(int c=0;c<3;c++){
     float dir=(i*1.37f+seed*.09f)+(c-1)*1.18f+(c==1?.34f:-.16f);
     float diff=Math.Abs(AngleDiff113(angle,dir));
     float width=.12f+q*.11f;
     if(q>.20f&&q<1.30f&&diff<width){
      float channel=(float)Math.Pow((width-diff)/width,1.35f);
      float fade=Math.Max(0f,1f-(q-.20f)/1.10f);
      best=Math.Max(best,channel*fade);
     }
    }
    if(q>.82f&&q<1.26f){
     float fan=1f-Math.Abs(q-1.03f)/.23f;
     if(fan>0f)best=Math.Max(best,fan*.33f*(.60f+.40f*(float)Math.Sin(angle*2.1f+i*1.8f)));
    }
   }
   return Math.Max(0f,Math.Min(1f,best));
  }
  public float LavaMask113(P n){return Basalt110?BasaltLavaMask113(n):(IsLava(n)?1f:0f);}
  public float Height(P n,bool applySite109=true){if(IsVulkaris276)return Vulkaris276.Get().SurfaceRadius(n.X,n.Y,n.Z);if(IsCarbonis277)return Carbonis277.Get().SurfaceRadius(n.X,n.Y,n.Z);if(AmigaBoing262)return 1.002f;float broad=Noise(n,seed),ridge=(float)Math.Pow(Math.Max(0,1-Math.Abs(Noise(n*2.3f,seed+19)*1.6)),3),h;
   switch(Biome.Kind){case 8:
     // v131: audit v109 vs v110-v130 proved that the high-contrast basalt
     // heightfield amplified screen-space AO banding on low-angle terrain.
     // Restore most of the earlier smooth terrain silhouette, retain 45% of
     // basalt forms, and leave volcanic/lava geometry and site flattening intact.
     float oldHeight131=1f+broad*.042f+Math.Max(0f,broad+.04f)*ridge*.07f;
     h=oldHeight131*.55f+BasaltHeight110(n)*.45f;
     break;case 0:h=1+broad*.042f+Math.Max(0,broad+.04f)*ridge*.07f;break;case 1:h=1+broad*.060f+Math.Max(0,broad+.24f)*ridge*.28f;break;case 2:h=.995f+broad*.042f;break;case 3:h=1+broad*.10f+Math.Max(0,broad)*ridge*.07f;break;case 4:h=1+broad*.045f+Math.Max(0,broad)*ridge*.12f;break;case 5:h=1+broad*.060f+(float)Math.Sin(n.X*23+n.Y*7+n.Z*8+seed)*.011f;break;case 6:h=1+broad*.055f+Math.Max(0,broad)*ridge*.055f;break;default:h=1+broad*.05f+ridge*.022f;break;}
   int count=CraterCount;
   for(int i=0;i<count;i++){
    // v271: the vast majority of planet samples cannot be influenced by a
    // crater. Reject them before the square root and division. 1.41 > 1.40
    // is deliberately conservative; near the boundary use original math.
    P delta271=n-craters[i].Center;float reach271=craters[i].Radius*1.41f;
    if(delta271.X*delta271.X+delta271.Y*delta271.Y+delta271.Z*delta271.Z>reach271*reach271)continue;
    float q=delta271.Length/craters[i].Radius;if(q<1.4f){float target=q<.85f?(i%3==0?.972f:1.001f)+.022f*q*q:1.021f+.040f*Math.Max(0,1-Math.Abs(q-1)/.32f);float mix=Math.Min(1,(1.4f-q)/.3f);h=h*(1-mix)+target*mix;}}
   if(Basalt110){float lava=BasaltLavaMask113(n);for(int i=0;i<volcanoes.Length;i++){
     P delta271=n-volcanoes[i].Center;float reach271=volcanoes[i].Radius*1.56f;
     if(delta271.X*delta271.X+delta271.Y*delta271.Y+delta271.Z*delta271.Z>reach271*reach271)continue;
     float q=delta271.Length/volcanoes[i].Radius;if(q<1.55f){float target=1.010f+BasaltVolcanoProfile251(q);float mix=AtlasSmooth242((1.55f-q)/.40f);h=h*(1-mix)+Math.Max(h,target)*mix;}}if(lava>.03f){float pool=Math.Max(0f,1f-Math.Abs(lava-.52f)*1.35f);h-=.0085f*lava*(.48f+.52f*pool);}}
   if(Biome.Kind==2)for(int i=0;i<volcanoes.Length;i++){
     P delta271=n-volcanoes[i].Center;float reach271=volcanoes[i].Radius*1.16f;
     if(delta271.X*delta271.X+delta271.Y*delta271.Y+delta271.Z*delta271.Z>reach271*reach271)continue;
     float q=delta271.Length/volcanoes[i].Radius;if(q<1.15f){P vr=Cross(volcanoes[i].Center,new P(0,1,0)).Unit,vf=Cross(vr,volcanoes[i].Center).Unit;float angle=(float)Math.Atan2(Dot(n,vf),Dot(n,vr));float target=PlanetLife52.VolcanoHeight56(q,angle,i),mix=Math.Min(1,(1.15f-q)/.2f);h=h*(1-mix)+target*mix;}}
   if(hub52&&!Basalt110){float river=PlanetLife52.River52(new IntroScene41.P(n.X,n.Y,n.Z));if(river<.026f&&h<1.06f&&Math.Abs(n.Y)<.72f){float mix=Math.Min(1,(.026f-river)/.014f);h-=.004f*mix;}
    for(int v=0;v<PlanetLife52.Volcanoes.Length;v++){float a;float q=PlanetLife52.Volcano56(new IntroScene41.P(n.X,n.Y,n.Z),v,out a);if(q<1){float target=PlanetLife52.VolcanoHeight56(q,a,v),mix=Math.Min(1,(1-q)/.18f);h=h*(1-mix)+target*mix;}}}
   if(CombatFaults254)h+=CombatFaultRelief254(n);
   if(OrbitAtlas242)h+=AtlasRelief242(n);
   if(applySite109&&hasSite109){
    float dist=(n-siteNormal109).Length*100f;
    // Uniform landing-zone grade to 26 metres, easing back to original planet
    // topology at 40 metres without an exposed rectangular pedestal.
    if(dist<40f){float blend=dist<=26f?1f:1f-(dist-26f)/14f;
     blend=blend*blend*(3f-2f*blend);h=h+(siteHeight109-h)*blend;}
   }
   return h;
  }
  // v258: replace latitude-band fractures with one long tennis-ball-like seam
  // wrapped around each selected planet. The seam is sampled as a closed
  // polyline on the unit sphere, so it can cover the globe without self-crossing.
  internal bool CombatFaults254{get{return !IsCarbonis277&&((hub52&&seed==1)||(!hub52&&(seed==1||seed==8)));}}
  internal int CombatFaultCount254{get{return 1;}}
  P FaultFrameA258{get{return hub52?new P(0,1,0):(seed==1?new P(1,0,0):new P(0,0,1));}}
  P FaultFrameB258{get{return hub52?new P(1,0,0):(seed==1?new P(0,0,1):new P(1,0,0));}}
  P FaultFrameC258{get{return Cross(FaultFrameA258,FaultFrameB258).Unit;}}
  float FaultAmplitude258{get{return hub52?.60f:(seed==1?.52f:.56f);}}
  float FaultTwist258{get{return hub52?2f:(seed==1?2f:3f);}}
  float FaultPhase258{get{return hub52?.35f:(seed==1?.95f:1.75f);}}
  int FaultSamples258{get{return hub52?108:96;}}
  // An area forbidden to fractures has a crisp end with just a very narrow
  // transition (<1% planet radius), rather than a long translucent fade.
  float FaultClearance257(P n){
   float clearance=99f;
   for(int i=0;i<CraterCount;i++){
    float gap=(n-craters[i].Center).Length-(craters[i].Radius*1.43f+.035f);
    if(gap<clearance)clearance=gap;
   }
   if(hub52){
    for(int i=0;i<AtlasCraterCenters242.Length;i++){
     float gap=(n-AtlasCraterCenters242[i]).Length-(AtlasCraterRadius242[i]*1.45f+.035f);
     if(gap<clearance)clearance=gap;
    }
   }
   if(Basalt110){
    for(int i=0;i<volcanoes.Length;i++){
     float gap=(n-volcanoes[i].Center).Length-(volcanoes[i].Radius*1.50f+.03f);
     if(gap<clearance)clearance=gap;
    }
   }
   if(hasSite109){
    float gap=(n-siteNormal109).Length-.57f;
    if(gap<clearance)clearance=gap;
   }
   return clearance;
  }
  // v272: the fade saturates at a clearance >= .011. For distant features
  // a squared-distance test skips the square root. For every nearby feature
  // the ORIGINAL sqrt, subtraction and min arithmetic is retained bitwise.
  // A deliberately conservative .012 guard protects floating-point edges.
  internal float FaultKeep257(P n){
   float clearance=99f;
   for(int i=0;i<CraterCount;i++){
    P d=n-craters[i].Center;
    float obstacle=craters[i].Radius*1.43f+.035f,reach=obstacle+.012f;
    if(d.X*d.X+d.Y*d.Y+d.Z*d.Z<=reach*reach){
     float gap=d.Length-obstacle;if(gap<clearance)clearance=gap;
    }
   }
   if(hub52)for(int i=0;i<AtlasCraterCenters242.Length;i++){
    P d=n-AtlasCraterCenters242[i];
    float obstacle=AtlasCraterRadius242[i]*1.45f+.035f,reach=obstacle+.012f;
    if(d.X*d.X+d.Y*d.Y+d.Z*d.Z<=reach*reach){
     float gap=d.Length-obstacle;if(gap<clearance)clearance=gap;
    }
   }
   if(Basalt110)for(int i=0;i<volcanoes.Length;i++){
    P d=n-volcanoes[i].Center;
    float obstacle=volcanoes[i].Radius*1.50f+.03f,reach=obstacle+.012f;
    if(d.X*d.X+d.Y*d.Y+d.Z*d.Z<=reach*reach){
     float gap=d.Length-obstacle;if(gap<clearance)clearance=gap;
    }
   }
   if(hasSite109){
    P d=n-siteNormal109;
    if(d.X*d.X+d.Y*d.Y+d.Z*d.Z<=.582f*.582f){
     float gap=d.Length-.57f;if(gap<clearance)clearance=gap;
    }
   }
   return AtlasSmooth242(clearance/.011f);
  }

  static float Frac258(float x){return x-(float)Math.Floor(x);}
  P FaultCandidate258(int slot,int attempt){
   float u=Frac258(seed*.137f+(slot+1)*.6180339f+(attempt+1)*.75487766f);
   float y=Frac258(seed*.271f+(slot+1)*.41421357f+(attempt+1)*.5698403f)*2f-1f;
   float r=(float)Math.Sqrt(Math.Max(0f,1f-y*y));
   float phi=(float)(Math.PI*2*u);
   return new P(r*(float)Math.Cos(phi),y,r*(float)Math.Sin(phi));
  }
  float FaultObstaclePad258(float radius){return radius*1.12f+.11f;}
  bool FaultClearOfSite258(P c,float radius){return !hasSite109||(c-siteNormal109).Length>(.57f+FaultObstaclePad258(radius));}
  bool FaultClearOfAtlas258(P c,float radius){
   if(!hub52)return true;
   float pad=FaultObstaclePad258(radius);
   for(int i=0;i<AtlasCraterCenters242.Length;i++)if((c-AtlasCraterCenters242[i]).Length<(AtlasCraterRadius242[i]+pad))return false;
   return true;
  }
  bool FaultClearOfVolcanoes258(P c,float radius,int skip){
   if(!Basalt110)return true;
   float pad=FaultObstaclePad258(radius);
   for(int i=0;i<volcanoes.Length;i++){
    if(i==skip)continue;
    if((c-volcanoes[i].Center).Length<(volcanoes[i].Radius+pad))return false;
   }
   return true;
  }
  bool FaultClearOfCraters258(P c,float radius,int skip){
   float pad=FaultObstaclePad258(radius);
   for(int i=0;i<CraterCount;i++){
    if(i==skip)continue;
    if((c-craters[i].Center).Length<(craters[i].Radius+pad))return false;
   }
   return true;
  }
  bool FaultClearOfFault258(P c,float radius){return FaultDistance257(c,0)>FaultObstaclePad258(radius);}
  float FaultPlacementScore258(P c,float radius){
   float score=FaultDistance257(c,0)*3.5f;
   if(hasSite109)score+=(c-siteNormal109).Length*1.4f;
   for(int i=0;i<CraterCount;i++)score+=(c-craters[i].Center).Length*.08f;
   if(hub52)for(int i=0;i<AtlasCraterCenters242.Length;i++)score+=(c-AtlasCraterCenters242[i]).Length*.05f;
   if(Basalt110)for(int i=0;i<volcanoes.Length;i++)score+=(c-volcanoes[i].Center).Length*.06f;
   return score-radius;
  }
  void RepositionFaultCraters258(){
   if(!CombatFaults254)return;
   for(int i=0;i<CraterCount;i++){
    Crater current=craters[i];
    bool ok=FaultClearOfFault258(current.Center,current.Radius)&&FaultClearOfSite258(current.Center,current.Radius)&&FaultClearOfAtlas258(current.Center,current.Radius)&&FaultClearOfVolcanoes258(current.Center,current.Radius,-1)&&FaultClearOfCraters258(current.Center,current.Radius,i);
    if(ok)continue;
    P best=current.Center;float bestScore=-1e9f;
    for(int a=0;a<320;a++){
     P cand=FaultCandidate258(i,a);
     if(!FaultClearOfFault258(cand,current.Radius))continue;
     if(!FaultClearOfSite258(cand,current.Radius))continue;
     if(!FaultClearOfAtlas258(cand,current.Radius))continue;
     if(!FaultClearOfVolcanoes258(cand,current.Radius,-1))continue;
     if(!FaultClearOfCraters258(cand,current.Radius,i))continue;
     float score=FaultPlacementScore258(cand,current.Radius);
     if(score>bestScore){bestScore=score;best=cand;}
    }
    if(bestScore>-1e8f)craters[i]=new Crater{Center=best,Radius=current.Radius};
   }
  }
  void RepositionFaultVolcanoes258(){
   if(!CombatFaults254||!Basalt110)return;
   for(int i=0;i<volcanoes.Length;i++){
    Crater current=volcanoes[i];
    bool ok=FaultClearOfFault258(current.Center,current.Radius)&&FaultClearOfSite258(current.Center,current.Radius)&&FaultClearOfAtlas258(current.Center,current.Radius)&&FaultClearOfCraters258(current.Center,current.Radius,-1)&&FaultClearOfVolcanoes258(current.Center,current.Radius,i);
    if(ok)continue;
    P best=current.Center;float bestScore=-1e9f;
    for(int a=0;a<320;a++){
     P cand=FaultCandidate258(i+CraterCount,a+97);
     if(!FaultClearOfFault258(cand,current.Radius))continue;
     if(!FaultClearOfSite258(cand,current.Radius))continue;
     if(!FaultClearOfAtlas258(cand,current.Radius))continue;
     if(!FaultClearOfCraters258(cand,current.Radius,-1))continue;
     if(!FaultClearOfVolcanoes258(cand,current.Radius,i))continue;
     float score=FaultPlacementScore258(cand,current.Radius);
     if(score>bestScore){bestScore=score;best=cand;}
    }
    if(bestScore>-1e8f)volcanoes[i]=new Crater{Center=best,Radius=current.Radius};
   }
  }
  internal float FaultPathMinClearance257(int samples){
   if(!CombatFaults254)return 99f;
   float best=99f;
   for(int i=0;i<samples;i++){
    P n=FaultPoint258((float)(i*Math.PI*2/samples));
    float c=FaultClearance257(n);
    if(c<best)best=c;
   }
   return best;
  }
  P FaultPoint258(float t){
   P a=FaultFrameA258,b=FaultFrameB258,c=FaultFrameC258;
   float lat=FaultAmplitude258*(float)Math.Sin(FaultTwist258*t+FaultPhase258);
   float cl=(float)Math.Cos(lat),sl=(float)Math.Sin(lat);
   float ct=(float)Math.Cos(t),st=(float)Math.Sin(t);
   return (b*(cl*ct)+c*(cl*st)+a*sl).Unit;
  }
  void EnsureFaultSamples258(){
   if(faultSamples258!=null)return;
   int count=FaultSamples258;
   faultSamples258=new P[count];
   for(int i=0;i<count;i++)faultSamples258[i]=FaultPoint258((float)(i*Math.PI*2/count));
   // v271: these midpoint normals depend only on the immutable fracture path.
   // Computing them once preserves the original sample positions bit for bit.
   faultMidpoints271=new P[count];
   for(int i=0;i<count;i++)faultMidpoints271[i]=(faultSamples258[i]+faultSamples258[(i+1)%count]).Unit;
  }
  // Distance from a point on the unit sphere to the single closed seam.
  // v271: square-root is monotone, so compare exact squared distances of the
  // original endpoint/midpoint samples, then compute only the winning root.
  // Every endpoint is present in the neighbouring segment as well; no samples
  // are omitted, and terrain mesh / decorative seams remain unchanged.
  internal float FaultDistance257(P n,int index){
   EnsureFaultSamples258();
   float bestSq=99f*99f;
   for(int i=0;i<faultSamples258.Length;i++){
    P a=n-faultSamples258[i];
    float sq=a.X*a.X+a.Y*a.Y+a.Z*a.Z;
    if(sq<bestSq)bestSq=sq;
    P m=n-faultMidpoints271[i];
    sq=m.X*m.X+m.Y*m.Y+m.Z*m.Z;
    if(sq<bestSq)bestSq=sq;
   }
   return (float)Math.Sqrt(bestSq);
  }
  float CombatFaultDistance254(P n,int idx,out float lengthFade){
   lengthFade=1f;return FaultDistance257(n,idx);
  }
  internal float CombatFaultRelief254(P n){
   if(!CombatFaults254)return 0f;
   float keep=FaultKeep257(n);if(keep<.001f)return 0f;
   float d=FaultDistance257(n,0);
   if(d>.102f)return 0f;
   float trench=1f-AtlasSmooth242(d/.041f);
   float innerWall=(float)Math.Exp(-Math.Pow((d-.030f)/.0135f,2));
   float outerWall=(float)Math.Exp(-Math.Pow((d-.056f)/.021f,2));
   return keep*((innerWall*.0085f+outerWall*.0105f)-trench*.039f);
  }
  bool CombatFaultNeedsRefine254(P n){
   return CombatFaults254&&FaultKeep257(n)>.05f&&FaultDistance257(n,0)<.090f;
  }
  Color CombatFaultTint254(P n,float h,Color color){
   if(!CombatFaults254)return color;
   float keep=FaultKeep257(n);if(keep<.001f)return color;
   Color ember=seed==1?Color.FromArgb(245,119,25):Mix(Biome.Glow,Color.FromArgb(255,190,130),.22f);
   Color emberHot=Mix(ember,Color.FromArgb(255,232,168),.42f);
   Color rimGlow=Mix(emberHot,Color.FromArgb(255,244,210),.35f);
   Color soot=seed==1?Color.FromArgb(65,29,18):Mix(Biome.Rock,Color.FromArgb(22,18,26),.60f);
   float d=FaultDistance257(n,0);if(d>.094f)return color;
   float dark=keep*(1f-AtlasSmooth242(d/.088f));
   color=Mix(color,soot,dark*.82f);
   float edge=keep*(float)Math.Exp(-Math.Pow((d-.037f)/.018f,2));
   color=Mix(color,emberHot,edge*.34f);
   // v259: subtle warm rim glow hugging the crack edges, no geometry changes.
   float rimInner=keep*(float)Math.Exp(-Math.Pow((d-.023f)/.0085f,2));
   float rimOuter=keep*(float)Math.Exp(-Math.Pow((d-.050f)/.012f,2));
   color=Mix(color,rimGlow,rimInner*.18f+rimOuter*.14f);
   float core=keep*(1f-AtlasSmooth242(d/.017f));
   float emberVariation=.67f+.33f*(float)Math.Sin(n.X*19f+n.Y*13f+n.Z*23f+seed*2f);
   color=Mix(color,ember,core*(.82f+.15f*emberVariation));
   return color;
  }
  static Color Mix(Color a,Color b,float f){f=Math.Max(0,Math.Min(1,f));return Color.FromArgb((int)(a.R+(b.R-a.R)*f),(int)(a.G+(b.G-a.G)*f),(int)(a.B+(b.B-a.B)*f));}
  bool IsLava(P n){if(Basalt110)return BasaltLavaMask113(n)>.18f;if(Biome.Kind!=2)return false;for(int i=0;i<3;i++){P center=volcanoes[i].Center;float q=(n-center).Length/volcanoes[i].Radius;if(q<.205f)return true;if(q<.26f||q>1.02f)continue;P u=Cross(center,new P(0,1,0)).Unit,v=Cross(center,u);float angle=(float)Math.Atan2(Dot(n,v),Dot(n,u));if(Math.Abs(Math.Sin(angle*3+seed*.2))<.15)return true;}return false;}
  Color TerrainColor(P n,float h){
   if(AmigaBoing262)return Color.FromArgb(244,243,239); // v263: actual checker tiles have separate faces
   Color color=Biome.Land;
   if(OrbitAtlas242)return AtlasTint242(n,h);
   else if(Basalt110)color=BasaltTint110(n,h);
   else if(Biome.Kind==4)color=Mix(Biome.Land,Biome.Rock,Math.Max(0,(h-.98f)*8));
   else if(h<WaterRadius-.01f)color=Mix(Biome.Land,Biome.Water,.65f);
   else if(h<WaterRadius+.009f)color=Biome.Shore;
   else {
    bool craterBlend=false;
    for(int i=0;i<CraterCount;i++){
     float q=(n-craters[i].Center).Length/craters[i].Radius;
     if(i%3!=0&&q<.84f){color=Mix(Biome.Land,Biome.Rock,q<.45f?.34f:.52f);craterBlend=true;break;}
    }
    if(!craterBlend){
     if(Biome.Kind==1)color=h>1.064f?Mix(Biome.Rock,Color.FromArgb(227,232,229),Math.Min(1,(h-1.064f)*16)):Mix(Biome.Land,Biome.Rock,Math.Max(0,(h-.99f)*6));
     else if(Biome.Kind==2)color=Mix(Biome.Land,Biome.Rock,Math.Max(0,(h-1)*5));
     else {float patch=Noise(n*1.6f,seed+101);color=Mix(Biome.Land,Biome.Rock,Math.Max(0,(h-1)*5)+Math.Max(0,patch)*.42f);} 
    }
   }
   return CombatFaultTint254(n,h,color);
  }
  void LavaTriangle(P a,P b,P c){P n=Cross(b-a,c-a).Unit;if(Dot(n,a+b+c)<0){P swap=b;b=c;c=swap;n=n*-1;}Color tint=Basalt110?Color.FromArgb(242,113,28):Mix(Biome.Accent,Color.FromArgb(255,232,135),.28f);foreach(P p in new[]{a*1.0018f,b*1.0018f,c*1.0018f})lava.AddRange(new[]{p.X,p.Y,p.Z,n.X,n.Y,n.Z,tint.R/255f,tint.G/255f,tint.B/255f,1f});}
  void Vertex(P p,P n,Color c){vertices.AddRange(new[]{p.X,p.Y,p.Z,n.X,n.Y,n.Z,c.R/255f,c.G/255f,c.B/255f,1f});}
  void Triangle(P a,P b,P c,Color color,bool terrain){P normal=Cross(b-a,c-a).Unit;if(Dot(normal,a+b+c)<0){P tmp=b;b=c;c=tmp;normal=normal*-1;}Vertex(a,terrain?(normal*.55f+a.Unit*.45f).Unit:normal,color);Vertex(b,terrain?(normal*.55f+b.Unit*.45f).Unit:normal,color);Vertex(c,terrain?(normal*.55f+c.Unit*.45f).Unit:normal,color);}
  void Subdivide(P a,P b,P c,int depth,bool water,bool local=false){if(depth>0){P ab=(a+b).Unit,bc=(b+c).Unit,ca=(c+a).Unit;Subdivide(a,ab,ca,depth-1,water,local);Subdivide(b,bc,ab,depth-1,water,local);Subdivide(c,ca,bc,depth-1,water,local);Subdivide(ab,bc,ca,depth-1,water,local);return;}
   P mid=(a+b+c).Unit;
   if(Basalt110&&!water&&!local){for(int i=0;i<volcanoes.Length;i++){float q=(mid-volcanoes[i].Center).Length/volcanoes[i].Radius;if(q<1.28f){Subdivide(a,b,c,1,false,true);return;}}}
   if(hub52&&!Basalt110&&!water&&!local){for(int i=0;i<4;i++){float angle;if(PlanetLife52.Volcano56(new IntroScene41.P(mid.X,mid.Y,mid.Z),i,out angle)<.55f){Subdivide(a,b,c,1,false,true);return;}}}
   if(CombatFaults254&&!water&&!local&&CombatFaultNeedsRefine254(mid)){Subdivide(a,b,c,1,false,true);return;}
   if(water){Triangle(a*WaterRadius,b*WaterRadius,c*WaterRadius,Biome.Water,true);return;}float ha=Height(a),hb=Height(b),hc=Height(c);P center=mid;Triangle(a*ha,b*hb,c*hc,TerrainColor(center,(ha+hb+hc)/3),true);if(!Basalt110&&IsLava(center))LavaTriangle(a*ha,b*hb,c*hc);
  }
  // v263: white/red Boing Ball. Each checker is its own watertight set of
  // quads on the sphere. We never sample one triangle's center to color a
  // larger triangle spanning both cells, which caused v262's jagged patches.
  // 10 latitude rows x 20 longitude columns give square angular tiles near
  // the equator; internal subdivisions preserve a smooth true sphere.
  internal const int BoingRows263=10,BoingCols263=20,BoingSplit263=4;
  static P BoingPoint263(double longitude,double latitude){
   float y=(float)Math.Sin(latitude),r=(float)Math.Cos(latitude);
   return new P(r*(float)Math.Cos(longitude),y,r*(float)Math.Sin(longitude));
  }
  void BuildBoingBall263(){
   const int rows=BoingRows263,cols=BoingCols263,split=BoingSplit263;
   Color red=Color.FromArgb(233,20,32),white=Color.FromArgb(249,249,246);
   for(int j=0;j<rows;j++)for(int i=0;i<cols;i++){
    Color tile=((i+j)&1)==0?red:white;
    for(int a=0;a<split;a++)for(int b=0;b<split;b++){
     double t0=(j+a/(double)split)/(double)rows*Math.PI-Math.PI*.5;
     double t1=(j+(a+1)/(double)split)/(double)rows*Math.PI-Math.PI*.5;
     double p0=(i+b/(double)split)/(double)cols*Math.PI*2;
     double p1=(i+(b+1)/(double)split)/(double)cols*Math.PI*2;
     P c00=BoingPoint263(p0,t0)*1.002f,c10=BoingPoint263(p1,t0)*1.002f;
     P c01=BoingPoint263(p0,t1)*1.002f,c11=BoingPoint263(p1,t1)*1.002f;
     if((c10-c00).Length>.000001f&&(c11-c00).Length>.000001f)Triangle(c00,c10,c11,tile,true);
     if((c11-c00).Length>.000001f&&(c01-c00).Length>.000001f)Triangle(c00,c11,c01,tile,true);
    }
   }
  }
  void Sphere(int depth,bool water){float t=(1+(float)Math.Sqrt(5))/2;P[] p={new P(-1,t,0),new P(1,t,0),new P(-1,-t,0),new P(1,-t,0),new P(0,-1,t),new P(0,1,t),new P(0,-1,-t),new P(0,1,-t),new P(t,0,-1),new P(t,0,1),new P(-t,0,-1),new P(-t,0,1)};int[] f={0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1};for(int i=0;i<p.Length;i++)p[i]=p[i].Unit;for(int i=0;i<f.Length;i+=3)Subdivide(p[f[i]],p[f[i+1]],p[f[i+2]],depth,water);}
  P RandomNormal(){float y=(float)(rng.NextDouble()*2-1),a=(float)(rng.NextDouble()*Math.PI*2),r=(float)Math.Sqrt(1-y*y);return new P(r*(float)Math.Cos(a),y,r*(float)Math.Sin(a));}
  void Cone(P root,P n,float bottom,float top,float width,float tip,Color color){P u=Cross(n,Math.Abs(n.Y)<.9f?new P(0,1,0):new P(1,0,0)).Unit,v=Cross(n,u);for(int i=0;i<6;i++){float a=i*(float)Math.PI/3,b=(i+1)*(float)Math.PI/3;P ra=u*(float)Math.Cos(a)+v*(float)Math.Sin(a),rb=u*(float)Math.Cos(b)+v*(float)Math.Sin(b);P aa=root+n*bottom+ra*width,bb=root+n*bottom+rb*width,cc=root+n*top+rb*tip,dd=root+n*top+ra*tip;Triangle(aa,bb,cc,color,false);if(tip>0)Triangle(aa,cc,dd,color,false);}}
  // Fourteen-sided grounded basalt debris: real smooth rings and irregular top facets.
  void BasaltRock110(P root,P n,float width,float tall,int key){
   P axis=Cross(n,Math.Abs(n.Y)<.85f?new P(0,1,0):new P(1,0,0)).Unit,front=Cross(n,axis).Unit;
   const int sides=14;P[] baseRing=new P[sides],shoulder=new P[sides],crown=new P[sides];
   for(int j=0;j<sides;j++){
    float a=2*(float)Math.PI*j/sides;
    float irregular=.88f+.13f*(float)Math.Sin(j*3.13+key*1.93);
    P radial=axis*(float)Math.Cos(a)+front*(float)Math.Sin(a);
    baseRing[j]=root+radial*(width*irregular);
    shoulder[j]=root+n*(tall*.65f)+radial*(width*irregular*.72f);
    crown[j]=root+n*(tall*(.93f+.07f*(float)Math.Sin(j*2.7+key)))+radial*(width*.20f);
   }
   Color stone=Mix(Color.FromArgb(53,59,66),Color.FromArgb(102,109,112),((key*17)%23)/26f);
   for(int j=0;j<sides;j++){
    int next=(j+1)%sides;
    Triangle(baseRing[j],baseRing[next],shoulder[next],stone,false);
    Triangle(baseRing[j],shoulder[next],shoulder[j],stone,false);
    Triangle(shoulder[j],shoulder[next],crown[next],stone,false);
    Triangle(shoulder[j],crown[next],crown[j],stone,false);
    Triangle(crown[j],crown[next],root+n*tall,stone,false);
   }
  }

  // v114: continuous physical streams, built once; no terrain-triangle sampling and
  // no random lava patches. Three vents, two/three channels per vent with cooled rims.
  public static readonly P[] BasaltVents114={new P(.78f,.36f,-.50f).Unit,new P(-.74f,.18f,.65f).Unit,new P(.12f,-.82f,.56f).Unit};
  static float Ease114(float x){x=Math.Max(0,Math.Min(1,x));return x*x*(3-2*x);}
  P FlowPosition114(int vent,int branch,float q){
   P center=volcanoes[vent].Center;
   P axis=Cross(center,Math.Abs(center.Y)<.92f?new P(0,1,0):new P(1,0,0)).Unit;
   P front=Cross(center,axis).Unit;
   float baseAngle=vent*1.37f+seed*.09f+(branch-1)*1.18f+(branch==1?.34f:-.16f);
   float bend=(.26f*(float)Math.Sin(q*2.6f+branch*1.4f+vent*.7f)+.09f*(float)Math.Sin(q*8.4f+vent+branch*.8f))*Ease114((q-.22f)*1.35f);
   float flare=.08f*(float)Math.Sin(q*15.0f+branch*2.7f+vent*.9f)*Ease114((q-.28f)*1.2f);
   float a=baseAngle+bend+flare,theta=volcanoes[vent].Radius*q;
   return (center*(float)Math.Cos(theta)+(axis*(float)Math.Cos(a)+front*(float)Math.Sin(a))*(float)Math.Sin(theta)).Unit;
  }
  void LavaVertex114(P p,Color shade){P n=p.Unit;lava.AddRange(new[]{p.X,p.Y,p.Z,n.X,n.Y,n.Z,shade.R/255f,shade.G/255f,shade.B/255f,1f});}
  void LavaStrip114(P a,P b,P c,P d,Color shade){
   P face=Cross(b-a,c-a);if(Dot(face,a+b+c+d)<0){P tmp=b;b=d;d=tmp;}
   LavaVertex114(a,shade);LavaVertex114(b,shade);LavaVertex114(c,shade);
   LavaVertex114(a,shade);LavaVertex114(c,shade);LavaVertex114(d,shade);
  }
  P FlowEdge114(P n,P tangent,float offset,float lift){
   P side=Cross(n,tangent).Unit;P dir=(n+side*offset).Unit;
   return dir*(Height(dir)+lift);
  }
  void FlowLayer114(P a,P b,float width0,float width1,float lift,Color shade){
   P tangent=(b-a).Unit;
   P l0=FlowEdge114(a,tangent,-width0,lift),r0=FlowEdge114(a,tangent,width0,lift),l1=FlowEdge114(b,tangent,-width1,lift),r1=FlowEdge114(b,tangent,width1,lift);
   LavaStrip114(l0,l1,r1,r0,shade);
  }
  void BuildFlowFan114(P end,P tangent,float width,int vent,int branch){
   P center=end.Unit;P side=Cross(center,tangent).Unit;
   Color crust=Color.FromArgb(30,26,25),body=Color.FromArgb(111,38,18),core=Color.FromArgb(232,86,24);
   for(int ring=0;ring<3;ring++){
    float inner=ring==0?0f:ring==1?width*.58f:width*.92f;
    float outer=ring==0?width*.64f:ring==1?width:width*1.26f;
    Color col=ring==0?core:ring==1?body:crust;float lift=ring==0?.0108f:ring==1?.0092f:.0076f;
    for(int i=0;i<14;i++){
     float a0=(-.95f+i*(1.9f/14f));float a1=(-.95f+(i+1)*(1.9f/14f));
     P d0=(center+tangent*(float)Math.Cos(a0)*outer+side*(float)Math.Sin(a0)*outer).Unit;
     P d1=(center+tangent*(float)Math.Cos(a1)*outer+side*(float)Math.Sin(a1)*outer).Unit;
     P c0=(center+tangent*(float)Math.Cos(a0)*inner+side*(float)Math.Sin(a0)*inner).Unit;
     P c1=(center+tangent*(float)Math.Cos(a1)*inner+side*(float)Math.Sin(a1)*inner).Unit;
     if(ring==0)LavaStrip114(center*(Height(center)+lift),d0*(Height(d0)+lift),d1*(Height(d1)+lift),center*(Height(center)+lift),col);
     else LavaStrip114(c0*(Height(c0)+lift),c1*(Height(c1)+lift),d1*(Height(d1)+lift),d0*(Height(d0)+lift),col);
    }
   }
  }
  void BuildFlow114(int vent,int branch){
   Color crust=Color.FromArgb(28,24,24),body=Color.FromArgb(101,41,18),core=Color.FromArgb(232,88,22);
   const int steps=58;
   P lastA=new P(),lastB=new P();float lastWidth=0;
   for(int k=0;k<steps;k++){
    float t=k/(float)steps,tn=(k+1)/(float)steps;
    float q=.24f+t*1.02f,qn=.24f+tn*1.02f;
    P a=FlowPosition114(vent,branch,q),b=FlowPosition114(vent,branch,qn);
    if(InsideSite109(a,54f)||InsideSite109(b,54f))continue;
    float wiggle=.90f+.22f*(float)Math.Sin(t*6.5f+branch*1.8f+vent*.7f)+.08f*(float)Math.Sin(t*17.0f+branch+vent);
    float width0=(.019f+.030f*Ease114(t))*wiggle;float width1=(.019f+.030f*Ease114(tn))*(.90f+.22f*(float)Math.Sin(tn*6.5f+branch*1.8f+vent*.7f)+.08f*(float)Math.Sin(tn*17.0f+branch+vent));
    width0=Math.Max(.016f,width0);width1=Math.Max(.017f,width1);
    // broad cooled crust as the base shape
    FlowLayer114(a,b,width0*1.22f,width1*1.22f,.0072f,crust);
    // darker hot body with slight asymmetry
    FlowLayer114(a,b,width0*.88f,width1*.88f,.0086f,body);
    // bright molten core
    FlowLayer114(a,b,width0*.42f,width1*.42f,.0102f,core);
    // broken crust plates across the surface to avoid ribbon look
    if(k%5==2||k%7==3){
     float plateWidth0=width0*(.28f+.18f*(float)Math.Sin(k*1.9f+vent));
     float plateWidth1=width1*(.24f+.17f*(float)Math.Sin(k*1.7f+branch));
     P tangent=(b-a).Unit;float offset=(float)Math.Sin(k*2.3f+branch*1.2f)*width0*.23f;
     P c0=FlowEdge114(a,tangent,offset-plateWidth0,.0109f),c1=FlowEdge114(b,tangent,offset-plateWidth1,.0109f),c2=FlowEdge114(b,tangent,offset+plateWidth1,.0109f),c3=FlowEdge114(a,tangent,offset+plateWidth0,.0109f);
     LavaStrip114(c0,c1,c2,c3,crust);
    }
    lastA=a;lastB=b;lastWidth=width1;
   }
   BuildFlowFan114(lastB,(lastB-lastA).Unit,lastWidth*1.3f,vent,branch);
  }
  void BuildVentPool114(int vent){
   P center=volcanoes[vent].Center;
   P axis=Cross(center,Math.Abs(center.Y)<.92f?new P(0,1,0):new P(1,0,0)).Unit,front=Cross(center,axis).Unit;
   const int sides=84;
   Color core=Color.FromArgb(232,88,22),body=Color.FromArgb(110,40,18),crust=Color.FromArgb(30,25,24);
   float innerR=.11f*volcanoes[vent].Radius,midR=.165f*volcanoes[vent].Radius,outerR=.225f*volcanoes[vent].Radius;
   for(int j=0;j<sides;j++){
    float a=j*(float)(Math.PI*2)/sides,b=(j+1)*(float)(Math.PI*2)/sides;
    P d0=(center*(float)Math.Cos(innerR)+(axis*(float)Math.Cos(a)+front*(float)Math.Sin(a))*(float)Math.Sin(innerR)).Unit;
    P d1=(center*(float)Math.Cos(innerR)+(axis*(float)Math.Cos(b)+front*(float)Math.Sin(b))*(float)Math.Sin(innerR)).Unit;
    P e0=(center*(float)Math.Cos(midR)+(axis*(float)Math.Cos(a)+front*(float)Math.Sin(a))*(float)Math.Sin(midR)).Unit;
    P e1=(center*(float)Math.Cos(midR)+(axis*(float)Math.Cos(b)+front*(float)Math.Sin(b))*(float)Math.Sin(midR)).Unit;
    P f0=(center*(float)Math.Cos(outerR)+(axis*(float)Math.Cos(a)+front*(float)Math.Sin(a))*(float)Math.Sin(outerR)).Unit;
    P f1=(center*(float)Math.Cos(outerR)+(axis*(float)Math.Cos(b)+front*(float)Math.Sin(b))*(float)Math.Sin(outerR)).Unit;
    P c=center*(Height(center)+.0108f);
    LavaStrip114(c,d0*(Height(d0)+.0108f),d1*(Height(d1)+.0108f),c,core);
    LavaStrip114(d0*(Height(d0)+.0094f),d1*(Height(d1)+.0094f),e1*(Height(e1)+.0094f),e0*(Height(e0)+.0094f),body);
    LavaStrip114(e0*(Height(e0)+.0076f),e1*(Height(e1)+.0076f),f1*(Height(f1)+.0076f),f0*(Height(f0)+.0076f),crust);
   }
   for(int tile=0;tile<18;tile++){
    float a=(float)(tile*2.3999632+vent*.37),rad=innerR+(.01f+(tile%5)*.007f)*volcanoes[vent].Radius;
    P t=(center*(float)Math.Cos(rad)+(axis*(float)Math.Cos(a)+front*(float)Math.Sin(a))*(float)Math.Sin(rad)).Unit;
    P u=Cross(t,new P(0,1,0)).Unit,v=Cross(t,u).Unit;
    float width=(.0030f+(tile%4)*.0014f)*(.9f+.15f*(float)Math.Sin(tile*7.2f));
    P mid=t*(Height(t)+.0111f);
    for(int edge=0;edge<5;edge++){
     float left=edge*(float)Math.PI/2.5f,right=(edge+1)*(float)Math.PI/2.5f;
     P n0=(t+(u*(float)Math.Cos(left)+v*(float)Math.Sin(left))*width).Unit;
     P n1=(t+(u*(float)Math.Cos(right)+v*(float)Math.Sin(right))*width).Unit;
     LavaStrip114(mid,n0*(Height(n0)+.0113f),n1*(Height(n1)+.0113f),mid,crust);
    }
   }
  }
  void BuildBasaltLava114(){
   for(int i=0;i<volcanoes.Length;i++){
    BuildVentPool114(i);
    for(int branch=0;branch<3;branch++)BuildFlow114(i,branch);
   }
  }

  public PlanetMesh(int level,int detail=5){hub52=detail>=6;seed=Math.Max(1,level);Biome=PlanetBiome.ForLevel(level);rng=new Random(unchecked(seed*7919+922));
   if(IsCarbonis277){
    Carbonis277 imported=Carbonis277.Get();Vertices=imported.Vertices;
    TerrainVertices=imported.Counts[0];NatureVertices=imported.Counts[1];WaterVertices=0;
    LavaStart=0;LavaVertices=0;MinRadius=.9f;MaxRadius=1.08f;
    TreeCount=0;CrystalCount=0;return;
   }
   if(IsVulkaris276) {
    Vulkaris276 imported=Vulkaris276.Get();Vertices=imported.Vertices;
    TerrainVertices=imported.Counts[0];WaterVertices=imported.Counts[1];
    NatureVertices=imported.Vertices.Length/10-TerrainVertices-WaterVertices;
    LavaStart=0;LavaVertices=0;MinRadius=.914f;MaxRadius=1.235f;
    TreeCount=0;CrystalCount=0;return;
   }for(int i=0;i<craters.Length;i++)craters[i]=new Crater{Center=RandomNormal(),Radius=.13f+(float)rng.NextDouble()*.16f};
   craters[0]=new Crater{Center=new P(-.43f,.39f,.81f).Unit,Radius=.24f};craters[1]=new Crater{Center=new P(.35f,.13f,.93f).Unit,Radius=.21f};craters[2]=new Crater{Center=new P(-.17f,-.48f,.85f).Unit,Radius=.23f};
   if(Basalt110){volcanoes[0]=new Crater{Center=BasaltVents114[0],Radius=.24f};volcanoes[1]=new Crater{Center=BasaltVents114[1],Radius=.27f};volcanoes[2]=new Crater{Center=BasaltVents114[2],Radius=.25f};}
   else{float baseLon=-level*29*(float)Math.PI/180;for(int i=0;i<3;i++){float lon=baseLon+(i-1)*.65f,lat=i==1?.12f:i==0?-.34f:.46f;volcanoes[i]=new Crater{Center=new P((float)(Math.Sin(lon)*Math.Cos(lat)),(float)Math.Sin(lat),(float)(Math.Cos(lon)*Math.Cos(lat))),Radius=i==1?.33f:.27f};}}
   if(hub52&&seed==1){
    // Identical n to Game.DockPosition90, but independent of game state.
    IntroScene41.P beacon=OrbitWorld50.Beacon(1).Unit;
    IntroScene41.P side=IntroScene41.Cross(new IntroScene41.P(0,1,0),beacon).Unit;
    IntroScene41.P station=(beacon*132-side*90).Unit;
    siteNormal109=new P(station.X,station.Y,station.Z);
    hasSite109=true;
    siteHeight109=Height(siteNormal109,false)+.0015f;
   }
   RepositionFaultCraters258();
   RepositionFaultVolcanoes258();
   if(AmigaBoing262)BuildBoingBall263();else Sphere(Math.Max(5,Math.Min(7,detail)),false);TerrainVertices=vertices.Count/10;float low=10,high=0;for(int i=0;i<vertices.Count;i+=10){float r=new P(vertices[i],vertices[i+1],vertices[i+2]).Length;low=Math.Min(low,r);high=Math.Max(high,r);}MinRadius=low;MaxRadius=high;
   if(!Basalt110&&!AmigaBoing262)Sphere(detail>=7?6:detail>=6?5:4,true);WaterVertices=vertices.Count/10-TerrainVertices;
   int trees=0,crystals=0;int candidates=AmigaBoing262?0:(Biome.Kind==8?280:Biome.Kind==0?850:Biome.Kind==1?90:Biome.Kind==2?60:Biome.Kind==3?420:Biome.Kind==4?140:Biome.Kind==5?85:Biome.Kind==6?550:720);
   for(int i=0;i<candidates;i++){P n=RandomNormal();float h=Height(n);if(h<WaterRadius+.013f||h>1.095f||IsLava(n)||InsideSite109(n,38f))continue;P root=n*(h-.001f);float height=.032f+(float)rng.NextDouble()*.042f;Color plant=Mix(Biome.Plant,Biome.Accent,(i%7)*.075f);
    if(Basalt110){BasaltRock110(root,n,.009f+(float)rng.NextDouble()*.011f,.005f+(float)rng.NextDouble()*.012f,i);crystals++;}
    else if(Biome.Kind==4||Biome.Kind==7||Biome.Kind==2||i%23==0){Cone(root,n,0,height,.009f,.001f,plant);Cone(root+n*.002f+Cross(n,new P(0,1,0)).Unit*.012f,n,0,height*.65f,.007f,0,Biome.Accent);crystals++;}
    else if(Biome.Kind==6){Cone(root,n,0,height*.80f,.004f,.003f,Mix(Biome.Plant,Biome.Rock,.6f));Cone(root,n,height*.63f,height*.82f,.027f,.023f,plant);Cone(root,n,height*.82f,height,.023f,0,plant);trees++;}
    else if(Biome.Kind==5){Cone(root,n,0,height,.007f,.006f,plant);Cone(root+Cross(n,new P(0,1,0)).Unit*.008f,n,height*.25f,height*.67f,.004f,.003f,plant);trees++;}
    else {Cone(root,n,0,height*.6f,.003f,.002f,Mix(Biome.Rock,Biome.Plant,.2f));Cone(root,n,height*.32f,height,.020f,0,plant);Cone(root,n,height*.18f,height*.72f,.024f,.002f,plant);trees++;}}
   TreeCount=trees;CrystalCount=crystals;NatureVertices=vertices.Count/10-TerrainVertices-WaterVertices;/* v116: detached LavaMesh116 replaces the previous terrain ribbons. */LavaStart=vertices.Count/10;LavaVertices=lava.Count/10;vertices.AddRange(lava);lava.Clear();Vertices=vertices.ToArray();vertices.Clear();
  }
 }
}
