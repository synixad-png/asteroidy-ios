using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {
 // New 130%-scale orbital planet, backed by the actual GLB triangle geometry.
 // --old-hub290 (or ASTEROIDY_OLD_HUB290=1) restores original planet, flight and dock.
 internal sealed class NewHome290 {
  // v294: scale only the drifting docking wreck in the new orbital world.
  // The old world retains its original station size and docking distance.
  internal const float WreckScale294=.504f; // v293 .42f * 1.20
  internal const float DockRadius294=36f;   // v293 30f * 1.20
  // v295: grow the entire derelict by a further 20%; legacy hub is untouched.
  internal const float WreckScale295=WreckScale294*1.20f;
  internal const float DockRadius295=DockRadius294*1.20f;
  internal const int WreckDebrisCount295=146;  // new-home only; old world retains 86
  internal const float WreckTrailLength295=178f; // new-home only; old world remains 104
  internal const int TriangleCount=172208;
  internal const int Width=512,Height=256;
  internal static readonly bool Enabled=Environment.GetEnvironmentVariable("ASTEROIDY_OLD_HUB290")!="1" && Array.IndexOf(Environment.GetCommandLineArgs(),"--old-hub290")<0;
  internal readonly float[] PackedVertices; // vertex: xyz, normal xyz, RGBA, UV
  internal readonly int[] Starts=new int[2],Counts=new int[2];
  internal readonly float[] HeightMap;
  static NewHome290 shared;
  internal static NewHome290 Get(){if(shared==null)shared=new NewHome290();return shared;}
  private NewHome290(){
   using(Stream r=Assembly.GetExecutingAssembly().GetManifestResourceStream("NewHome290.Mesh")){
    if(r==null)throw new InvalidDataException("Brak nowej planety głównej");
    using(GZipStream zip=new GZipStream(r,CompressionMode.Decompress))using(BinaryReader rd=new BinaryReader(zip)){
     if(rd.ReadUInt32()!=0x30393248 || rd.ReadInt32()!=2)throw new InvalidDataException("Niepoprawny format planety głównej");
     int[] uniqueCounts=new int[2];int total=0;
     for(int k=0;k<2;k++){Counts[k]=rd.ReadInt32();uniqueCounts[k]=rd.ReadInt32();if(Counts[k]<0||Counts[k]%3!=0||uniqueCounts[k]<0||Counts[k]>800000)throw new InvalidDataException("Uszkodzone grupy GLB");Starts[k]=total;total+=Counts[k];}
     if(total!=TriangleCount*3)throw new InvalidDataException("Niekompletna planeta główna");
     float[][] unique=new float[2][];
     for(int k=0;k<2;k++){unique[k]=new float[checked(uniqueCounts[k]*12)];for(int i=0;i<unique[k].Length;i++)unique[k][i]=rd.ReadSingle();}
     PackedVertices=new float[checked(total*12)];
     for(int k=0;k<2;k++)for(int i=0;i<Counts[k];i++){
      uint ix=rd.ReadUInt32();if(ix>=uniqueCounts[k])throw new InvalidDataException("Uszkodzony indeks GLB");
      Array.Copy(unique[k],(int)ix*12,PackedVertices,(Starts[k]+i)*12,12);
     }
     if(rd.ReadInt32()!=Width||rd.ReadInt32()!=Height)throw new InvalidDataException("Niepoprawna mapa kolizji planety");
     HeightMap=new float[Width*Height];for(int i=0;i<HeightMap.Length;i++)HeightMap[i]=rd.ReadSingle();
    }
   }
  }
  // v292: GLB contains only a base JPEG, so the glowing lava maps are baked from it.
  internal static Stream LavaEmission292(){return Assembly.GetExecutingAssembly().GetManifestResourceStream("NewHome292.Emission");}
  internal static Stream LavaIrradiance292(){return Assembly.GetExecutingAssembly().GetManifestResourceStream("NewHome292.Irradiance");}
  public static System.IO.Stream LavaGlow293(){return System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("NewHome293.Glow");}
  internal static Stream Texture(){Stream s=Assembly.GetExecutingAssembly().GetManifestResourceStream("NewHome290.Texture");if(s==null)throw new InvalidDataException("Brak tekstury nowej planety głównej");return s;}
  internal float HeightAt(IP d){
   IP n=d.Unit;float lon=(float)Math.Atan2(n.Z,n.X),lat=(float)Math.Asin(Math.Max(-1,Math.Min(1,n.Y)));
   float u=(lon+(float)Math.PI)/(float)(2*Math.PI)*Width-.5f;
   float v=(lat+(float)Math.PI*.5f)/(float)Math.PI*Height-.5f;
   int x=(int)Math.Floor(u),y=(int)Math.Floor(v);float tx=u-x,ty=v-y;
   int x0=((x%Width)+Width)%Width,x1=(x0+1)%Width,y0=Math.Max(0,Math.Min(Height-1,y)),y1=Math.Max(0,Math.Min(Height-1,y+1));
   float h00=HeightMap[y0*Width+x0],h10=HeightMap[y0*Width+x1],h01=HeightMap[y1*Width+x0],h11=HeightMap[y1*Width+x1];
   return 100f*((h00+(h10-h00)*tx)*(1-ty)+(h01+(h11-h01)*tx)*ty);
  }
  internal static float Surface(IP p){return Enabled?Get().HeightAt(p):100f;}
  internal static IP WreckPosition(){IP n=LegacyBeaconDirection290(),t=IntroScene41.Cross(new IP(0,1,0),n).Unit,b=IntroScene41.Cross(n,t).Unit;IP d=(n*142-t*126+b*12).Unit;return Enabled?d*(Surface(d)+15f):n*142-t*126+b*12;}
  internal static IP LegacyBeaconDirection290(){return new IP((float)Math.Cos(Game.PI/8),0,(float)Math.Sin(Game.PI/8));}
  internal static IP SpawnPosition(IP direction){IP n=direction.Unit;return n*Math.Max(150f,Surface(n)+12f);}
  internal static IP SafePosition(IP position){if(!Enabled)return position;float min=Surface(position)+8f;return position.Length<min?position.Unit*min:position;}
 }
}
