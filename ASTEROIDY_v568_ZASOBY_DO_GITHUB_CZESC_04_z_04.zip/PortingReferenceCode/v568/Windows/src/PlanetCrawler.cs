using System;using System.Drawing;using System.Collections.Generic;
namespace Asteroidy {
 // Ambient fauna. Routes stay in planet coordinates and follow the displaced terrain.
 sealed class PlanetCrawler {
  public struct P {public float X,Y,Z;public P(float x,float y,float z){X=x;Y=y;Z=z;}public static P operator +(P a,P b){return new P(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}public static P operator -(P a,P b){return new P(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}public static P operator *(P a,float s){return new P(a.X*s,a.Y*s,a.Z*s);}public float Length{get{return (float)Math.Sqrt(X*X+Y*Y+Z*Z);}}public P Unit{get{return this*(1/Math.Max(.00001f,Length));}}}
  public static P Cross(P a,P b){return new P(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);}static float Dot(P a,P b){return a.X*b.X+a.Y*b.Y+a.Z*b.Z;}
  static readonly object meshLock62=new object();static float[] cachedMesh62;static int cachedBody62,cachedBone62;public static int MeshBuilds62{get;private set;}
  readonly List<float> build=new List<float>();public readonly float[] Vertices;public readonly int BodyVertices,BoneStart,BoneCount;float longitude,latitude,span;
  static P Point(float lon,float lat){return new P((float)(Math.Sin(lon)*Math.Cos(lat)),(float)Math.Sin(lat),(float)(Math.Cos(lon)*Math.Cos(lat)));}
  public P Normal(float t){return Point(longitude+span*t,latitude+(float)Math.Sin(t*Math.PI)*.035f);}
  public static float Height(PlanetMesh planet,P n){return planet.Height(new PlanetMesh.P(n.X,n.Y,n.Z));}
  public void PrepareRoute(PlanetMesh planet,int level,int routeIndex=0){int index=Math.Max(0,Math.Min(4,routeIndex));float[] xs={-.83f,.68f,-.02f,-.46f,.77f},ys={-.33f,.42f,-.62f,.43f,-.31f};float center=-level*29*(float)Math.PI/180;longitude=center+xs[index]-.10f;latitude=ys[index];span=.18f;float best=-100;for(int i=0;i<25;i++){float lon=center+xs[index]-.14f+(i%5)*.02f,lat=ys[index]-.045f+(i/5)*.0225f;float lowest=10,highest=-10;for(int k=0;k<=12;k++){float h=Height(planet,Point(lon+span*k/12,lat));lowest=Math.Min(lowest,h);highest=Math.Max(highest,h);}float score=lowest-(highest-lowest)*.3f;if(score>best){best=score;longitude=lon;latitude=lat;}}}
  public static bool FaunaActive(float time,bool animated,int index,out float progress){progress=0;if(!animated||time<3)return false;float phase=(time-3+index*6)%24;if(phase>=15)return false;progress=phase/15;return true;}
  public static bool Active(float time,bool animated,out float progress){progress=0;if(!animated||time<4)return false;float phase=(time-4)%24;if(phase>=10)return false;progress=phase/10;return true;}
  void V(P p,P n,Color c){build.AddRange(new[]{p.X,p.Y,p.Z,n.X,n.Y,n.Z,c.R/255f,c.G/255f,c.B/255f,1f});}
  void T(P a,P b,P c,Color color,P center){P n=Cross(b-a,c-a).Unit;if(Dot(n,a+b+c-center*3)<0){P swap=b;b=c;c=swap;n=n*-1;}V(a,n,color);V(b,n,color);V(c,n,color);}
  P EllipsoidPoint(P center,float x,float y,float z,float a,float b){return center+new P(x*(float)(Math.Cos(b)*Math.Cos(a)),y*(float)(Math.Cos(b)*Math.Sin(a)),z*(float)Math.Sin(b));}
  void Ellipsoid(P c,float x,float y,float z,Color color){for(int row=0;row<12;row++)for(int col=0;col<24;col++){float a=col*(float)Math.PI/12,aa=(col+1)*(float)Math.PI/12,b=-((float)Math.PI/2)+row*(float)Math.PI/12,bb=b+(float)Math.PI/12;P p=EllipsoidPoint(c,x,y,z,a,b),q=EllipsoidPoint(c,x,y,z,aa,b),r=EllipsoidPoint(c,x,y,z,aa,bb),s=EllipsoidPoint(c,x,y,z,a,bb);if(row>0)T(p,q,r,color,c);if(row<11)T(p,r,s,color,c);}}
  void BoneGeometry(){P center=new P(0,.5f,0);for(int i=0;i<16;i++){float a=i*(float)Math.PI/8,b=(i+1)*(float)Math.PI/8;P p=new P((float)Math.Cos(a),0,(float)Math.Sin(a)),q=new P((float)Math.Cos(b),0,(float)Math.Sin(b)),r=q+new P(0,1,0),s=p+new P(0,1,0);T(p,q,r,Color.FromArgb(115,139,86),center);T(p,r,s,Color.FromArgb(115,139,86),center);}}
  internal static P LegKnee65(P hip,ref P foot,int side){P d=foot-hip;float length=d.Length;if(length>.97f){foot=hip+d*(.97f/length);d=foot-hip;length=.97f;}P axis=d.Unit;P outward=new P(side,0,1),bend=(outward-axis*Dot(outward,axis)).Unit;float along=(.51f*.51f-.49f*.49f+length*length)/(2*Math.Max(.001f,length)),height=(float)Math.Sqrt(Math.Max(0,.51f*.51f-along*along));return hip+axis*along+bend*height;}
  public PlanetCrawler(){lock(meshLock62){if(cachedMesh62!=null){Vertices=cachedMesh62;BodyVertices=BoneStart=cachedBody62;BoneCount=cachedBone62;return;}Ellipsoid(new P(0,-.32f,.28f),.42f,.56f,.29f,Color.FromArgb(90,127,57));Ellipsoid(new P(0,.28f,.28f),.34f,.32f,.25f,Color.FromArgb(51,80,68));Ellipsoid(new P(0,.70f,.26f),.30f,.26f,.20f,Color.FromArgb(116,65,129));
   Ellipsoid(new P(-.19f,.86f,.36f),.08f,.08f,.06f,Color.FromArgb(244,168,73));Ellipsoid(new P(.19f,.86f,.36f),.08f,.08f,.06f,Color.FromArgb(244,168,73));
   for(int i=0;i<4;i++)Ellipsoid(new P(0,-.62f+i*.16f,.535f),.03f,.045f,.025f,Color.FromArgb(158,185,92));
   // Overlapping chitin plates, articulated antennae, pupils and mandibles.
   for(int i=0;i<6;i++){float y=-.73f+i*.18f;Ellipsoid(new P(0,y,.49f),.39f-i*.014f,.075f,.075f,Color.FromArgb(66+i*9,102+i*7,48+i*5));}
   for(int sign=-1;sign<=1;sign+=2){Ellipsoid(new P(sign*.19f,.89f,.413f),.032f,.043f,.013f,Color.FromArgb(18,23,20));Ellipsoid(new P(sign*.12f,1.01f,.27f),.045f,.13f,.035f,Color.FromArgb(86,102,53));Ellipsoid(new P(sign*.20f,1.16f,.29f),.055f,.10f,.04f,Color.FromArgb(160,175,100));Ellipsoid(new P(sign*.13f,.87f,.16f),.07f,.16f,.05f,Color.FromArgb(170,152,91));for(int j=0;j<3;j++)Ellipsoid(new P(sign*.34f,-.48f+j*.27f,.20f),.085f,.095f,.085f,Color.FromArgb(70,83,49));}
   BodyVertices=build.Count/10;BoneStart=BodyVertices;BoneGeometry();BoneCount=build.Count/10-BoneStart;Vertices=build.ToArray();build.Clear();cachedBody62=BodyVertices;cachedBone62=BoneCount;cachedMesh62=Vertices;MeshBuilds62++;}
  }
 }
}
