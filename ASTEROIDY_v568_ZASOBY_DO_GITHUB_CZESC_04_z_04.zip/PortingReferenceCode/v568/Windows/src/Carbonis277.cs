using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;

namespace Asteroidy {
 // Import of the authentic CARBONIS GLB mesh. UV0 and both embedded source
 // images are retained, unlike the older colour-only VULKARIS import.
 internal sealed class Carbonis277 {
  internal const int Level=1;
  internal const int Triangles=270249;
  internal const int Groups=2;
  internal readonly float[] Vertices;
  internal readonly float[] Uv;
  internal readonly int[] Starts=new int[Groups],Counts=new int[Groups];
  internal readonly float[] HeightMap;
  internal readonly int Width,Height;
  private static Carbonis277 shared;
  private Carbonis277(){
   using(Stream raw=Assembly.GetExecutingAssembly().GetManifestResourceStream("Carbonis277.Mesh")){
    if(raw==null)throw new InvalidDataException("Brak geometrii CARBONIS");
    using(GZipStream zip=new GZipStream(raw,CompressionMode.Decompress))
    using(BinaryReader rd=new BinaryReader(zip)){
     if(rd.ReadUInt32()!=0x39373243u||rd.ReadInt32()!=Groups)throw new InvalidDataException("Nieobslugiwany zasob CARBONIS v279");
     int sum=0;
     for(int i=0;i<Groups;i++){
      Starts[i]=sum;Counts[i]=rd.ReadInt32();
      if(Counts[i]<0||Counts[i]>1200000||Counts[i]%3!=0)throw new InvalidDataException("Bledne indeksy CARBONIS");
      sum=checked(sum+Counts[i]);
     }
     if(sum!=Triangles*3)throw new InvalidDataException("Niekompletna geometria CARBONIS");
     int uniqueCount=rd.ReadInt32();
     if(uniqueCount<=0||uniqueCount>sum)throw new InvalidDataException("Bledna tablica wierzcholkow CARBONIS");
     float[] unique=new float[checked(uniqueCount*12)];
     for(int i=0;i<unique.Length;i++)unique[i]=rd.ReadSingle();
     Vertices=new float[checked(sum*10)];Uv=new float[checked(sum*2)];
     for(int i=0;i<sum;i++){
      uint ix=rd.ReadUInt32();if(ix>=uniqueCount)throw new InvalidDataException("Uszkodzony indeks CARBONIS");
      int u=checked((int)ix*12),v=i*10,t=i*2;
      for(int j=0;j<10;j++)Vertices[v+j]=unique[u+j];
      Uv[t]=unique[u+10];Uv[t+1]=unique[u+11];
     }
     Width=rd.ReadInt32();Height=rd.ReadInt32();
     if(Width!=512||Height!=256)throw new InvalidDataException("Bledna mapa kolizji CARBONIS");
     HeightMap=new float[Width*Height];
     for(int i=0;i<HeightMap.Length;i++)HeightMap[i]=rd.ReadSingle();
    }
   }
  }
  internal static Carbonis277 Get(){if(shared==null)shared=new Carbonis277();return shared;}
  internal static Stream Resource(string suffix){
   Stream s=Assembly.GetExecutingAssembly().GetManifestResourceStream("Carbonis277."+suffix);
   if(s==null)throw new InvalidDataException("Brak tekstury CARBONIS "+suffix);
   return s;
  }
  internal float SurfaceRadius(float x,float y,float z){
   float len=(float)Math.Sqrt(x*x+y*y+z*z);if(len<1e-7f)return 1f;
   float lon=(float)Math.Atan2(z,x),lat=(float)Math.Asin(Math.Max(-1,Math.Min(1,y/len)));
   float u=(lon+(float)Math.PI)/(float)(Math.PI*2)*Width-.5f;
   float v=(lat+(float)Math.PI/2)/(float)Math.PI*Height-.5f;
   int ix=(int)Math.Floor(u),iy=(int)Math.Floor(v);float a=u-ix,b=v-iy;
   int x0=((ix%Width)+Width)%Width,x1=(x0+1)%Width;
   int y0=Math.Max(0,Math.Min(Height-1,iy)),y1=Math.Max(0,Math.Min(Height-1,iy+1));
   float r00=HeightMap[y0*Width+x0],r10=HeightMap[y0*Width+x1],r01=HeightMap[y1*Width+x0],r11=HeightMap[y1*Width+x1];
   return (r00+(r10-r00)*a)*(1-b)+(r01+(r11-r01)*a)*b;
  }
 }
}
