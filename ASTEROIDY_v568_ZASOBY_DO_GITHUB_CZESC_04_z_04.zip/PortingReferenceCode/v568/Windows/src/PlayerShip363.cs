using System;using System.Drawing;using System.IO;using System.IO.Compression;using System.Reflection;
namespace Asteroidy {
 static class PlayerShip363 {
  static readonly object sync=new object();
  static bool loaded,available;static ShipMesh.P[] engines;static ShipMesh.Face[] faces;static float[] vertices;static Bitmap skin;
  static Stream Open(string name){Assembly asm=Assembly.GetExecutingAssembly();return asm.GetManifestResourceStream(name);} 
  static bool EnsureMesh(){lock(sync){if(loaded)return available;loaded=true;try{
     using(Stream raw=Open("Asteroidy.PlayerShip367.Mesh")){if(raw==null)return available=false;using(GZipStream gz=new GZipStream(raw,CompressionMode.Decompress))using(BinaryReader r=new BinaryReader(gz)){
       if(r.ReadInt32()!=3671)throw new InvalidDataException("PlayerShip363 mesh version");int n=r.ReadInt32();if(n<=0||n>8)throw new InvalidDataException("PlayerShip363 engines");engines=new ShipMesh.P[n];for(int i=0;i<n;i++)engines[i]=new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
       int floats=r.ReadInt32();if(floats<=0||floats>60000000||floats%12!=0)throw new InvalidDataException("PlayerShip363 vertex float count");byte[] bytes=r.ReadBytes(floats*4);if(bytes.Length!=floats*4)throw new EndOfStreamException();vertices=new float[floats];Buffer.BlockCopy(bytes,0,vertices,0,bytes.Length);
       int tri=r.ReadInt32();if(tri<=0||tri>200000)throw new InvalidDataException("PlayerShip363 face count");faces=new ShipMesh.Face[tri];for(int i=0;i<tri;i++)faces[i]=new ShipMesh.Face(new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),new ShipMesh.P(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),0);
      }
     }
     // v370: projected XY silhouette of v369 GLB occupied ~25,500 raster pixels,
     // against ~64,000 for normal Vanguard under identical orthographic framing.
     // Uniform growth x1.68 yields matching projected hull footprint to Vanguard.
     // Apply to positions and engine sockets only; UVs and normals are unchanged.
     // The prototype remains an OPTIONAL fourth ship; no other mesh is changed.
     const float StandardSize369=.714f;
     for(int i=0;i<engines.Length;i++)engines[i]=new ShipMesh.P(engines[i].X*StandardSize369,engines[i].Y*StandardSize369,engines[i].Z*StandardSize369);
     for(int i=0;i<vertices.Length;i+=12){vertices[i]*=StandardSize369;vertices[i+1]*=StandardSize369;vertices[i+2]*=StandardSize369;}
     for(int i=0;i<faces.Length;i++){ShipMesh.Face f=faces[i];faces[i]=new ShipMesh.Face(
      new ShipMesh.P(f.A.X*StandardSize369,f.A.Y*StandardSize369,f.A.Z*StandardSize369),
      new ShipMesh.P(f.B.X*StandardSize369,f.B.Y*StandardSize369,f.B.Z*StandardSize369),
      new ShipMesh.P(f.C.X*StandardSize369,f.C.Y*StandardSize369,f.C.Z*StandardSize369),f.Material);}
     return available=engines!=null&&vertices!=null&&faces!=null&&faces.Length>0;
    }catch{engines=null;faces=null;vertices=null;return available=false;}}}
  public static bool TryApply(ShipMesh target){if(!EnsureMesh())return false;target.EngineCenters=engines;target.Faces=faces;target.Vertices=vertices;target.Start[0]=0;target.Count[0]=vertices.Length/12;for(int i=1;i<8;i++){target.Start[i]=target.Count[i]=0;}target.Palette[0]=Color.White;target.Palette[1]=Color.White;target.Palette[3]=Color.White;return true;}
  // GDI+ Image.FromStream retains a dependency on the underlying stream.
  // Decouple the embedded JPEG from its closed resource stream before it is
  // cached, cloned or uploaded to OpenGL on Windows.
  public static Bitmap TryLoadSkin(){lock(sync){
   if(skin!=null)return (Bitmap)skin.Clone();
   using(Stream raw=Open("Asteroidy.PlayerShip363.Base")){
    if(raw==null)return null;
    try{
     using(Bitmap decoded=new Bitmap(raw)){
      Bitmap independent=new Bitmap(decoded.Width,decoded.Height,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
      try{using(Graphics graphics=Graphics.FromImage(independent)){
       graphics.CompositingMode=System.Drawing.Drawing2D.CompositingMode.SourceCopy;
       graphics.DrawImage(decoded,new Rectangle(0,0,decoded.Width,decoded.Height));
      }}catch{independent.Dispose();throw;}
      skin=independent;
     }
    }catch(Exception ex){throw new InvalidDataException("Nie udalo sie odkodowac tekstury GLB PlayerShip363: "+ex.Message,ex);}
   }
   return (Bitmap)skin.Clone();
  }}
 }
}
