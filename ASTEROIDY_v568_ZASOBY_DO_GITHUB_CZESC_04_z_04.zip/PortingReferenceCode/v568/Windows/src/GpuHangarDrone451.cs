// v451: render the existing quadcopter mesh as a separately simulated hangar NPC.
using System;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  void DrawHangarDrone451(Game g){
   foreach(DronePilot453 p in g.HangarDrones453){if(!p.Active||p.VisualScale<=.001f)continue;
   planetPush();try{
    shipTranslate(p.X,p.Y+.055f*(float)Math.Sin(g.HubTime90*2.6f+p.Id*2f),p.Z);
    shipRotate(p.Yaw,0,1,0);
    shipRotate(p.Roll,0,0,1);
    shipRotate(p.Pitch,1,0,0);
    // Guardian mesh authored with rotors in XY plane, depth along Z;
    // re-orient to the horizontal XZ plane and reduce to 1.1 m wingspan.
    shipRotate(-90,1,0,0);
    float scale=.32f*p.VisualScale;shipScale(scale,scale,scale);
    DrawEscortDroneMesh305(g.HubTime90+p.Id*1.1f);
   }finally{planetPop();}}
  }
 }
}
