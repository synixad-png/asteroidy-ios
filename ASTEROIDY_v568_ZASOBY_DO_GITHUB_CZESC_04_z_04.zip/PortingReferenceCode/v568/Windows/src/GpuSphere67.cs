using System;
using System.Drawing;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  const float Shell67=HomeWorldOuterRadius523+15f,Scale67=Shell67/Sphere67.Radius; // v523: keep all craft and effects above full-scale terrain
  readonly float[] sphereMatrix67=new float[16];
  readonly float[][] sphereRocks67=new float[80][];readonly uint[] sphereRockBuffers67=new uint[80];
  public int SphereFrames67{get;private set;}public int SphereRockUploads67{get;private set;}
  // v73: conservative horizon/frustum culling. The rock's full original high-resolution
  // GPU mesh is retained; physics, hit detection and radar continue for all objects.
  public int VisibleRocks73{get;private set;}public int CulledRocks73{get;private set;}
  public int CulledFighters73{get;private set;}public int CulledRings73{get;private set;}
  public int LineVertices73{get;private set;}public int LineDrawCalls73{get;private set;}
  const int MaxSphereLineVertices73=32768;
  readonly float[] sphereLineVertices73=new float[MaxSphereLineVertices73*7];
  int sphereLineCount73;
  bool VisibleSurface73(V point,float worldRadius){
   IP n=Sphere67.Normal(point);
   // Occlude only when the entire bounding sphere is certainly behind terrain.
   // Shell67 is above the real planet: its tangent/horizon MUST NOT be used here.
   // Intersect camera-to-center ray with a conservative inner terrain sphere.
   IP world=n*Shell67,ray=world-sphereEye67;
   float raySq=Sphere67.Dot(ray,ray);
   if(planet!=null&&raySq>1){
    float t=-Sphere67.Dot(sphereEye67,ray)/raySq;
    float safeRadius=Math.Min(planet.MinRadius,planet.WaterRadius)*MissionPlanetScale523(100f)-5-worldRadius;
    if(t>0&&t<1&&safeRadius>0){
     IP nearest=sphereEye67+ray*t;
     if(Sphere67.Dot(nearest,nearest)<safeRadius*safeRadius)return false;
    }
   }
   PointF screen;float depth;
   if(!IntroProject(n*Shell67,out screen,out depth))return false;
   float margin=worldRadius*820/Math.Max(1,depth)+25;
   return screen.X>=-margin&&screen.X<=1280+margin&&screen.Y>=-margin&&screen.Y<=720+margin;
  }
  void EmitSphereLineVertex73(IP p,Color tint){
   if(sphereLineCount73==MaxSphereLineVertices73)FlushSphereLines73();
   int i=sphereLineCount73++*7;
   float alpha=tint.A/255f;
   sphereLineVertices73[i]=p.X;sphereLineVertices73[i+1]=p.Y;sphereLineVertices73[i+2]=p.Z;
   sphereLineVertices73[i+3]=tint.R/255f;sphereLineVertices73[i+4]=tint.G/255f;
   sphereLineVertices73[i+5]=tint.B/255f;sphereLineVertices73[i+6]=alpha;
  }
  void FlushSphereLines73(){if(sphereLineCount73==0)return;
   GCHandle pinned=GCHandle.Alloc(sphereLineVertices73,GCHandleType.Pinned);
   try{IntPtr address=pinned.AddrOfPinnedObject();
    if(vertexBuffer!=0){bindBuffer(0x8892,vertexBuffer);bufferData(0x8892,new IntPtr(sphereLineCount73*28),address,0x88E0);address=IntPtr.Zero;}
    enableClient(0x8074);enableClient(0x8076);
    vertexPointer(3,0x1406,28,address);
    colorPointer(4,0x1406,28,new IntPtr(address.ToInt64()+12));
    drawArrays(1,0,sphereLineCount73);
    disableClient(0x8074);disableClient(0x8076);
    if(vertexBuffer!=0)bindBuffer(0x8892,0);
    DrawCalls++;LineDrawCalls73++;SubmittedVertices+=sphereLineCount73;LineVertices73+=sphereLineCount73;
   }finally{pinned.Free();sphereLineCount73=0;}
  }
  IP sphereEye67;
  public bool ProjectSphere67(V p,out PointF point,out float scale){IP n=Sphere67.Normal(p),world=ShotPosition292(p,0);float depth;scale=1;bool visible=IntroProject(world,out point,out depth)&&Sphere67.Dot(n,sphereEye67)>0;scale=720*Scale67/Math.Max(1,depth);return visible;}
  void StampSphere67(V p,float angle,float scale,float lift=0f){IP n=Sphere67.Normal(p),forward=Sphere67.Vector(p,Game.Direction(angle)).Unit,right=Sphere67.Cross(forward,n).Unit,position=n*(Shell67+lift);IP col0=right*scale,col1=forward*scale,col2=n*scale;sphereMatrix67[0]=col0.X;sphereMatrix67[1]=col0.Y;sphereMatrix67[2]=col0.Z;sphereMatrix67[3]=0;sphereMatrix67[4]=col1.X;sphereMatrix67[5]=col1.Y;sphereMatrix67[6]=col1.Z;sphereMatrix67[7]=0;sphereMatrix67[8]=col2.X;sphereMatrix67[9]=col2.Y;sphereMatrix67[10]=col2.Z;sphereMatrix67[11]=0;sphereMatrix67[12]=position.X;sphereMatrix67[13]=position.Y;sphereMatrix67[14]=position.Z;sphereMatrix67[15]=1;planetMultiply(sphereMatrix67);}
  // v263/v267: a real triangulated white Amiga ball, with red 'AMIGA' decals
  // wrapped onto its spherical surface as small 3D quads, not 2D circles.
  float[] amigaRockVertices263;uint amigaRockBuffer263;
  static readonly string[] AmigaGlyphs263={
   "01110/10001/10001/11111/10001/10001/10001", // A
   "10001/11011/10101/10101/10001/10001/10001", // M
   "01110/00100/00100/00100/00100/00100/01110", // I
   "01111/10000/10000/10111/10001/10001/01111"  // G
  };
  static int AmigaGlyphIndex263(char c){return c=='A'?0:c=='M'?1:c=='I'?2:3;}
  static IP AmigaSpherePoint263(float lon,float lat,float lift=1f){
   float cos=(float)Math.Cos(lat);
   return new IP((float)Math.Cos(lon)*cos*lift,(float)Math.Sin(lat)*lift,(float)Math.Sin(lon)*cos*lift);
  }
  static void AmigaTriangle263(List<float> list,IP a,IP b,IP c,float red,float green,float blue){
   IP normal=IntroScene41.Cross(b-a,c-a).Unit;
   if(IntroScene41.Dot(normal,a+b+c)<0){IP temp=b;b=c;c=temp;normal=normal*-1f;}
   foreach(IP v in new[]{a,b,c}){
    IP n=v.Unit;
    list.Add(v.X);list.Add(v.Y);list.Add(v.Z);
    list.Add(n.X);list.Add(n.Y);list.Add(n.Z);
    list.Add(red);list.Add(green);list.Add(blue);list.Add(1f);
   }
  }
  static IP AmigaBadgePoint268(float x,float y,float lift=1.018f){
   float r2=x*x+y*y;
   float z=(float)Math.Sqrt(Math.Max(.0001f,1f-r2));
   return new IP(x*lift,y*lift,z*lift);
  }
  internal float[] AmigaRockVertices263(){
   if(amigaRockVertices263!=null)return amigaRockVertices263;
   List<float> mesh=new List<float>(100000);
   const int stacks=18,slices=36;
   for(int j=0;j<stacks;j++)for(int i=0;i<slices;i++){
    float lat0=(float)((j/(double)stacks-.5)*Math.PI),lat1=(float)(((j+1)/(double)stacks-.5)*Math.PI);
    float lon0=(float)(i*Math.PI*2/slices),lon1=(float)((i+1)*Math.PI*2/slices);
    IP p00=AmigaSpherePoint263(lon0,lat0),p01=AmigaSpherePoint263(lon0,lat1);
    IP p10=AmigaSpherePoint263(lon1,lat0),p11=AmigaSpherePoint263(lon1,lat1);
    if((p10-p00).Length>.00001f)AmigaTriangle263(mesh,p00,p10,p11,.96f,.96f,.94f);
    if((p11-p00).Length>.00001f)AmigaTriangle263(mesh,p00,p11,p01,.96f,.96f,.94f);
   }
   string label="AMIGA";
   const float cell=.048f,gap=.020f,pixel=.86f,rowLift=1.028f;
   float total=label.Length*5*cell+(label.Length-1)*gap;
   float start=-total*.5f;
   for(int ch=0;ch<label.Length;ch++){
    string[] rows=AmigaGlyphs263[AmigaGlyphIndex263(label[ch])].Split(new char[]{'/'});
    float baseX=start+ch*(5*cell+gap);
    for(int y=0;y<7;y++)for(int x=0;x<5;x++)if(rows[y][x]=='1'){
     float x0=baseX+x*cell, x1=x0+cell*pixel;
     float y0=(3-y)*cell-.5f*cell, y1=y0+cell*pixel;
     IP a=AmigaBadgePoint268(x0,y0,rowLift),b=AmigaBadgePoint268(x1,y0,rowLift);
     IP c=AmigaBadgePoint268(x1,y1,rowLift),d=AmigaBadgePoint268(x0,y1,rowLift);
     AmigaTriangle263(mesh,a,b,c,.92f,.14f,.16f);AmigaTriangle263(mesh,a,c,d,.92f,.14f,.16f);
    }
   }
   amigaRockVertices263=mesh.ToArray();return amigaRockVertices263;
  }
  // Cached rock meshes are identical in the fallback and the instanced renderer.
  float[] RockVertices75(int shape){
   if(sphereRocks67[shape]==null){List<float> data=new List<float>();for(int f=0;f<introFaces.Length;f+=3)StoneSubdivide56(data,introIco[introFaces[f]].Unit,introIco[introFaces[f+1]].Unit,introIco[introFaces[f+2]].Unit,new IP(),1,((shape%40)/5)+13,2);Color[] materials={Color.FromArgb(128,158,193),Color.FromArgb(235,174,73),Color.FromArgb(176,108,238),Color.FromArgb(226,83,108),Color.FromArgb(94,213,139)};Color tint=materials[shape%5];if(shape>=40){int gray=(tint.R*30+tint.G*59+tint.B*11)/100;int stone=90+gray/4;tint=Color.FromArgb(stone-7,stone,stone+9);}for(int j=0;j<data.Count;j+=10){float light=.85f+data[j+7]*.2f;data[j+6]=tint.R/255f*light;data[j+7]=tint.G/255f*light;data[j+8]=tint.B/255f*light;}sphereRocks67[shape]=data.ToArray();}
   return sphereRocks67[shape];
  }
  void EnsureRockBuffer75(int shape){
   if(sphereRockBuffers67[shape]!=0||genBuffers==null)return;
   float[] vertices=RockVertices75(shape);GCHandle p=GCHandle.Alloc(vertices,GCHandleType.Pinned);
   try{genBuffers(1,out sphereRockBuffers67[shape]);bindBuffer(0x8892,sphereRockBuffers67[shape]);bufferData(0x8892,new IntPtr(vertices.Length*4),p.AddrOfPinnedObject(),0x88E4);SphereRockUploads67++;}
   finally{p.Free();}
  }
  void RockSphere67(Game game,Rock rock){if(!VisibleSurface73(rock.P,rock.Radius*Scale67*1.4f+(game.Level==25?rock.BounceHeight265*Scale67:0f))){CulledRocks73++;return;}VisibleRocks73++;int shape=(rock.Shape&7)*5+Math.Max(0,Math.Min(4,rock.ArmorTier))+(rock.Fragment77?40:0);bool amiga263=game.Level==25;float[] vertices=amiga263?AmigaRockVertices263():RockVertices75(shape);
   planetPush();StampSphere67(rock.P,rock.Angle,rock.Radius*Scale67,amiga263?rock.BounceHeight265*Scale67:0f);if(amiga263)shipRotate(0,0,0,1);else{shipRotate(rock.Angle*41,1,0,0);shipRotate(rock.Angle*23,0,1,0);}FighterLight(false);disable(TEX);disable(BLEND);enable(DEPTH);shipMaterial(0x0408,0x1600,rock.HitFlash>0?hitEmission:none);GCHandle pin=new GCHandle();IntPtr ptr=IntPtr.Zero;try{if(genBuffers!=null){if((amiga263?amigaRockBuffer263:sphereRockBuffers67[shape])==0){uint gpuRockBuffer263;genBuffers(1,out gpuRockBuffer263);if(amiga263)amigaRockBuffer263=gpuRockBuffer263;else sphereRockBuffers67[shape]=gpuRockBuffer263;pin=GCHandle.Alloc(vertices,GCHandleType.Pinned);bindBuffer(0x8892,(amiga263?amigaRockBuffer263:sphereRockBuffers67[shape]));bufferData(0x8892,new IntPtr(vertices.Length*4),pin.AddrOfPinnedObject(),0x88E4);SphereRockUploads67++;}else bindBuffer(0x8892,(amiga263?amigaRockBuffer263:sphereRockBuffers67[shape]));}else{pin=GCHandle.Alloc(vertices,GCHandleType.Pinned);ptr=pin.AddrOfPinnedObject();}enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);vertexPointer(3,0x1406,40,ptr);shipNormal(0x1406,40,new IntPtr(ptr.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(ptr.ToInt64()+24));BeginToon60(true,false);drawArrays(4,0,vertices.Length/10);EndToon60();DrawCalls++;SubmittedVertices+=vertices.Length/10;disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);if((amiga263?amigaRockBuffer263:sphereRockBuffers67[shape])!=0)bindBuffer(0x8892,0);}finally{if(pin.IsAllocated)pin.Free();planetPop();}}
  // Submit 3D effect strokes through one VBO, not hundreds of glVertex callbacks.
  // Seven geodesic samples reproduce the previous six segments exactly.
  readonly bool lineCullEnabled76=Environment.GetEnvironmentVariable("ASTEROIDY_DISABLE_EFFECT_CULL")!="1";
  bool lineCullActive76;
  public int CulledEffectLines76{get;private set;}
  // v76: reject single short trails when their ENTIRE geodesic arc is hidden.
  // Ring segments already have group-level conservative culling, so skip this cost there.
  void SphereLine67(V from,V to,Color tint,bool testVisibility76=true){
   V delta=Sphere67.Delta(to,from);
   if(testVisibility76&&lineCullActive76){
    float allowance=12+delta.Length*Scale67*.85f;
    if(!VisibleSurface73(Sphere67.Offset(from,delta*.5f),allowance)){
     CulledEffectLines76++;return;
    }
   }
   IP previous=new IP();
   for(int i=0;i<=6;i++){
    IP current=Sphere67.Normal(Sphere67.Offset(from,delta*(i/6f)))*(Shell67+.4f);
    if(i>0){EmitSphereLineVertex73(previous,tint);EmitSphereLineVertex73(current,tint);}
    previous=current;
   }
  }
  void RingSphere67(V center,float radius,Color tint){
   if(!VisibleSurface73(center,(radius+2)*Scale67)){CulledRings73++;return;}
   V start=Sphere67.Offset(center,Game.Direction(0)*radius),from=start;
   for(int i=1;i<=32;i++){
    V to=i==32?start:Sphere67.Offset(center,Game.Direction(i*Game.PI/16)*radius);
    SphereLine67(from,to,tint,false);from=to;
   }
  }
  // v226: Batch asteroid/ship ground shadows into one GL multi-draw submission.
  // Each fan keeps its original vertices, ordering, depth test and alpha blending.
  // The old immediate path remains available for drivers without glMultiDrawArrays.
  float[] shadowVertices226=new float[32768];
  int[] shadowStarts226=new int[512],shadowCounts226=new int[512];
  int shadowVertexCount226,shadowFanCount226;
  bool shadowBatchActive226;
  // Fixed sample counts recur for every asteroid. Cache the *exact* angles
  // formerly evaluated on each frame to avoid thousands of Sin/Cos calls.
  readonly float[][] shadowCos226=new float[128][],shadowSin226=new float[128][];
  void ShadowAngles226(int slices,out float[] cs,out float[] sn){
   if(slices>=shadowCos226.Length){cs=sn=null;return;}
   cs=shadowCos226[slices];sn=shadowSin226[slices];if(cs!=null)return;
   cs=new float[slices+1];sn=new float[slices+1];
   for(int i=0;i<=slices;i++){float a=(float)(i*Math.PI*2/slices);cs[i]=(float)Math.Cos(a);sn[i]=(float)Math.Sin(a);}
   shadowCos226[slices]=cs;shadowSin226[slices]=sn;
  }
  public int ShadowFans226{get;private set;}
  public int ShadowDrawCalls226{get;private set;}
  void BeginPlanetShadowBatch226(){
   shadowVertexCount226=shadowFanCount226=0;
   shadowBatchActive226=false;
   if(Environment.GetEnvironmentVariable("ASTEROIDY_DISABLE_SHADOW_BATCH") == "1")return;
   // As with rock instancing, Mesa software rasterizers may be slower with
   // multi-draw despite fewer API calls. Keep the proven path for software GL.
   if(Software&&Environment.GetEnvironmentVariable("ASTEROIDY_FORCE_SHADOW_BATCH")!="1")return;
   if(multiDrawIntro135==null){
    try{multiDrawIntro135=Optional<MultiDrawIntro135>(introResolve135,"glMultiDrawArrays");}catch{multiDrawIntro135=null;}
   }
   shadowBatchActive226=multiDrawIntro135!=null;
  }
  void EmitShadowVertex226(IP p,float alpha){
   int slot=shadowVertexCount226*7;
   if(slot+7>shadowVertices226.Length)Array.Resize(ref shadowVertices226,Math.Max(slot+7,shadowVertices226.Length*2));
   shadowVertices226[slot]=p.X;shadowVertices226[slot+1]=p.Y;shadowVertices226[slot+2]=p.Z;
   shadowVertices226[slot+3]=.012f;shadowVertices226[slot+4]=.018f;shadowVertices226[slot+5]=.030f;
   shadowVertices226[slot+6]=alpha;shadowVertexCount226++;
  }
  void BeginShadowFan226(int vertices){
   if(shadowFanCount226==shadowStarts226.Length){Array.Resize(ref shadowStarts226,shadowStarts226.Length*2);Array.Resize(ref shadowCounts226,shadowCounts226.Length*2);}
   shadowStarts226[shadowFanCount226]=shadowVertexCount226;
   shadowCounts226[shadowFanCount226]=vertices;
   shadowFanCount226++;
  }
  void FinishPlanetShadowBatch226(){
   ShadowFans226=shadowFanCount226;ShadowDrawCalls226=0;
   if(!shadowBatchActive226||shadowFanCount226==0){shadowBatchActive226=false;return;}
   try{
    // These states match PlanetShadowLayer170's immediate-mode path.
    enable(DEPTH);depthMask(0);disable(TEX);disable(0x0B44);enable(BLEND);blendFunc(0x0302,0x0303);
    if(bindBuffer!=null)bindBuffer(0x8892,0);
    GCHandle vpin=GCHandle.Alloc(shadowVertices226,GCHandleType.Pinned);
    GCHandle fpin=GCHandle.Alloc(shadowStarts226,GCHandleType.Pinned);
    GCHandle cpin=GCHandle.Alloc(shadowCounts226,GCHandleType.Pinned);
    try{
     IntPtr ptr=vpin.AddrOfPinnedObject();
     enableClient(0x8074);enableClient(0x8076);
     vertexPointer(3,0x1406,28,ptr);colorPointer(4,0x1406,28,new IntPtr(ptr.ToInt64()+12));
     multiDrawIntro135(6,fpin.AddrOfPinnedObject(),cpin.AddrOfPinnedObject(),shadowFanCount226);
     DrawCalls++;ShadowDrawCalls226=1;SubmittedVertices+=shadowVertexCount226;
    }finally{disableClient(0x8074);disableClient(0x8076);cpin.Free();fpin.Free();vpin.Free();}
   }finally{shadowBatchActive226=false;depthMask(1);disable(BLEND);}
  }
  IP PlanetShadowSun170(float time,bool animated){float a=2.3f+(animated?time:0)*.025f;return new IP((float)Math.Cos(a)*.9f,.4f,(float)Math.Sin(a)*.9f).Unit;}
  IP PlanetShadowPoint170(IP normal,IP longAxis,IP shortAxis,float alongWorld,float acrossWorld,float liftWorld){
   IP dir=(normal+longAxis*(alongWorld/MissionPlanetScale523(100f))+shortAxis*(acrossWorld/MissionPlanetScale523(100f))).Unit;
   float h=Math.Max(.12f,PlanetCrawler.Height(planet,new PlanetCrawler.P(dir.X,dir.Y,dir.Z)))*MissionPlanetScale523(100f)+liftWorld;
   return dir*h;
  }
  void PlanetShadowLayer170(V point,float bodyRadius,float opacity,IP sun,float stretch170,float softness170,float altitudeBias170,float shiftBias170,int slices170){
   if(planet==null||opacity<=0||bodyRadius<=0||!VisibleSurface73(point,(bodyRadius*2.4f+22)*Scale67))return;
   IP n=Sphere67.Normal(point),longAxis=sun-n*Sphere67.Dot(sun,n);float lit=Math.Max(0f,Math.Min(1f,Sphere67.Dot(n,sun)));
   if(longAxis.Length<.0001f){IP east,south;Sphere67.Basis(point,out east,out south);longAxis=east;}else longAxis=longAxis.Unit;
   IP shortAxis=Sphere67.Cross(n,longAxis).Unit;if(shortAxis.Length<.0001f){IP east,south;Sphere67.Basis(point,out east,out south);shortAxis=south;}
   float surface=Math.Max(6f,PlanetCrawler.Height(planet,new PlanetCrawler.P(n.X,n.Y,n.Z))*MissionPlanetScale523(100f));
   float heightGap=Math.Max(5f,Shell67-surface+altitudeBias170);
   float shift=bodyRadius*shiftBias170+heightGap*(.34f+.28f*(1-lit));
   float longRadius=bodyRadius*(stretch170+(1-lit)*.95f)+heightGap*(.15f+.07f*softness170);
   float shortRadius=Math.Max(bodyRadius*.62f,bodyRadius*(.86f-.14f*lit)+heightGap*(.025f+.05f*softness170));
   float lift=.12f+.05f*softness170;
   if(!shadowBatchActive226){enable(DEPTH);depthMask(0);disable(TEX);disable(0x0B44);enable(BLEND);blendFunc(0x0302,0x0303);begin(6);}
   else BeginShadowFan226(slices170+2);
   IP center=PlanetShadowPoint170(n,longAxis,shortAxis,-shift,0,lift);
   float alpha=Math.Max(.05f,Math.Min(.85f,opacity));
   if(shadowBatchActive226)EmitShadowVertex226(center,alpha);
   else{color(.012f,.018f,.030f,alpha);vertex(center.X,center.Y,center.Z);}
   float[] cosSamples226,sinSamples226;ShadowAngles226(slices170,out cosSamples226,out sinSamples226);
   for(int i=0;i<=slices170;i++){
    float ca,sa;
    if(cosSamples226!=null){ca=cosSamples226[i];sa=sinSamples226[i];}
    else{float a=(float)(i*Math.PI*2/slices170);ca=(float)Math.Cos(a);sa=(float)Math.Sin(a);}
    IP edge=PlanetShadowPoint170(n,longAxis,shortAxis,-shift+ca*longRadius,sa*shortRadius,lift);
    if(shadowBatchActive226)EmitShadowVertex226(edge,0);
    else{color(.012f,.018f,.030f,0);vertex(edge.X,edge.Y,edge.Z);}
   }
   if(!shadowBatchActive226){end();DrawCalls++;SubmittedVertices+=slices170+2;}
  }
  void PlanetShadowDisc170(V point,float radius,float stretch,float opacity,IP sun,float altitudeBias170=.26f,float shiftBias170=.24f,int slices170=28){
   PlanetShadowLayer170(point,radius*1.42f,opacity*.42f,sun,stretch*1.36f,1.0f,altitudeBias170+2.5f,shiftBias170*.92f,slices170);
   PlanetShadowLayer170(point,radius,opacity*.88f,sun,stretch,.35f,altitudeBias170,shiftBias170,slices170);
   PlanetShadowLayer170(point,radius*.58f,opacity*.34f,sun,Math.Max(.92f,stretch*.84f),0f,altitudeBias170-1.5f,shiftBias170*.72f,Math.Max(16,slices170-6));
  }
  void DrawPlanetShadows170(Game g,bool animated){
   BeginPlanetShadowBatch226();
   IP sun=PlanetShadowSun170(g.Time,animated);
   foreach(Rock rock in g.Rocks){float jump=(g.Level==25?rock.BounceHeight265:0f);float shadow=(float)Math.Max(.095f,1f-jump/65f);PlanetShadowDisc170(rock.P,rock.Radius*(.98f+jump*.005f),1.22f,(rock.Size==3?.34f:rock.Size==2?.28f:.22f)*shadow,sun,rock.Size==3?2.8f:1.4f,rock.Size==3?.28f:.24f,rock.Size==3?26:22);}
   foreach(Bug bug in g.Bugs){
    if(bug.Robot70!=null)continue;
    if(bug.Hunter)PlanetShadowDisc170(bug.P,15.5f,1.34f,.28f,sun,2.3f,.26f,22);
    else if(bug.Shooter71>=0)PlanetShadowDisc170(bug.P,12.8f,1.26f,.24f,sun,1.8f,.24f,20);
    else PlanetShadowDisc170(bug.P,10.8f,1.18f,.21f,sun,1.4f,.22f,18);
   }
   if(g.BossActive&&g.BossArrivalScale86>.12f){
    float bossR=66*Game.BossSize68*g.BossArrivalScale86;
    PlanetShadowDisc170(g.BossPosition,bossR,1.58f,.36f,sun,7.5f,.34f,34);
    PlanetShadowDisc170(g.BossPosition,bossR*.62f,1.12f,.18f,sun,5.0f,.20f,28);
   }
   if(g.MissionObjective65==Objective65.Escort||g.MissionObjective65==Objective65.Defend)PlanetShadowDisc170(g.ObjectivePosition65,10.5f,1.18f,.16f,sun,.8f,.18f,18);
   PlanetShadowDisc170(g.Ship,11.5f,1.24f,.26f,sun,1.2f,.20f,20);
   if(g.CoopEnabled62)PlanetShadowDisc170(g.Ship62,11.5f,1.24f,.26f,sun,1.2f,.20f,20);
   FinishPlanetShadowBatch226();
   depthMask(1);disable(BLEND);
  }
  void PlanetLightLayer170(V point,float radius,Color tint,float opacity,float lift170,int slices170){
   if(planet==null||opacity<=0||radius<=0||!VisibleSurface73(point,(radius*2.6f+18)*Scale67))return;
   IP n=Sphere67.Normal(point),east,south;Sphere67.Basis(point,out east,out south);
   enable(DEPTH);depthMask(0);disable(TEX);disable(0x0B44);disable(0x0B50);enable(BLEND);blendFunc(1,1);begin(6);
   float a=Math.Max(0f,Math.Min(1f,opacity));color(tint.R/255f*a,tint.G/255f*a,tint.B/255f*a,a);
   IP center=PlanetShadowPoint170(n,east,south,0,0,lift170);vertex(center.X,center.Y,center.Z);
   for(int i=0;i<=slices170;i++){
    float angle=(float)(i*Math.PI*2/slices170),ca=(float)Math.Cos(angle),sa=(float)Math.Sin(angle);
    IP edge=PlanetShadowPoint170(n,east,south,ca*radius,sa*radius,lift170);
    color(0,0,0,0);vertex(edge.X,edge.Y,edge.Z);
   }
   end();DrawCalls++;SubmittedVertices+=slices170+2;
  }
  static Color HostileGroundTint170(int kind){return kind==2?Color.FromArgb(126,243,77):kind==3?Color.FromArgb(200,112,254):Color.FromArgb(72,185,255);}
  static readonly Color[] ProjectileLightPreset285={Color.White,Color.FromArgb(92,190,255),Color.FromArgb(255,205,102),Color.FromArgb(112,242,132),Color.FromArgb(196,118,255),Color.FromArgb(255,96,118),Color.FromArgb(172,242,255),Color.FromArgb(255,178,72)};
  static Color BlendProjectileLight285(Color a,Color b,float mix){mix=Math.Max(0f,Math.Min(1f,mix));float inv=1f-mix;return Color.FromArgb(Math.Min(255,(int)(a.R*inv+b.R*mix)),Math.Min(255,(int)(a.G*inv+b.G*mix)),Math.Min(255,(int)(a.B*inv+b.B*mix)));}
  static readonly Color[] PlanetFireflyPreset438={Color.FromArgb(120,255,156),Color.FromArgb(90,236,255),Color.FromArgb(116,170,255),Color.FromArgb(195,120,255),Color.FromArgb(255,210,110),Color.FromArgb(255,126,190),Color.FromArgb(245,245,255)};
  IP PlanetSunDirection438(){float a=SunAngle436();return new IP((float)Math.Cos(a)*.9f,.4f,(float)Math.Sin(a)*.9f).Unit;}
  Color ResolvePlanetFireflyTint438(int index){int preset=Math.Max(0,Math.Min(PlanetFireflyPreset438.Length-1,PlanetFireflyColor438));if(PlanetFireflyColor438<PlanetFireflyPreset438.Length)return PlanetFireflyPreset438[preset];return PlanetFireflyPreset438[Math.Abs(index*37+13)%PlanetFireflyPreset438.Length];}
  V PlanetFireflyPoint438(int index,float time,IP sun,out float nightMask,out float pulse){
   float a=index*2.3999631f+time*(.032f+.0025f*(index%5));
   float y=(float)Math.Sin(index*1.913f+time*(.011f+.001f*(index%7)))*.76f;
   float r=(float)Math.Sqrt(Math.Max(0,1-y*y));
   IP n=new IP((float)Math.Cos(a)*r,y,(float)Math.Sin(a)*r);
   float dot=n.X*sun.X+n.Y*sun.Y+n.Z*sun.Z;
   if(dot>-.08f){n=new IP(n.X-sun.X*(dot+.34f),n.Y-sun.Y*(dot+.34f),n.Z-sun.Z*(dot+.34f)).Unit;dot=n.X*sun.X+n.Y*sun.Y+n.Z*sun.Z;}
   V surface=Sphere67.Coordinates(n);
   float driftA=(float)Math.Sin(time*1.7f+index*2.1f),driftB=(float)Math.Cos(time*1.15f+index*1.3f);
   float glide=.65f+.35f*(.5f+.5f*(float)Math.Sin(time*.83f+index*.71f));
   V point=Sphere67.Offset(surface,new V(driftA*(1.0f+glide*3.2f),driftB*(.8f+glide*2.4f)));
   nightMask=Math.Max(0f,Math.Min(1f,(-dot+.04f)/.62f));
   pulse=.42f+.58f*(.5f+.5f*(float)Math.Sin(time*3.4f+index*1.9f));
   return point;
  }
  void DrawPlanetFireflies438(Game g,bool animated){
   int count=Math.Max(0,Math.Min(120,PlanetFireflyCount438));if(!PlanetLightEnabled436||count<=0)return;
   IP sun=PlanetSunDirection438();float time=(sunAnimated436?sunClock436:g.Time)+(animated?g.Time*.15f:0f);
   for(int i=0;i<count;i++){
    float nightMask,pulse;V point=PlanetFireflyPoint438(i,time,sun,out nightMask,out pulse);
    if(nightMask<=.001f||!VisibleSurface73(point,30*Scale67))continue;
    Color tint=ResolvePlanetFireflyTint438(i);
    float cluster=1f+.35f*(float)Math.Sin(i*.73f+time*.27f);
    PlanetLightLayer170(point,2.6f+pulse*1.5f,tint,.30f*nightMask*(.55f+pulse*.45f),2.1f+pulse*2.0f,12);
    PlanetLightLayer170(point,5.8f+pulse*2.4f,tint,.14f*nightMask*(.65f+pulse*.55f),1.25f+pulse*.85f,14);
    PlanetLightLayer170(point,10.0f+pulse*4.5f,tint,.085f*nightMask*cluster,0.36f,18);
    PlanetLightLayer170(point,18.0f+pulse*7.0f,tint,.034f*nightMask*cluster,0.12f,20);
   }
   depthMask(1);disable(BLEND);
  }
  Color ResolveProjectileLightTint285(Color baseTint){int preset=Math.Max(0,Math.Min(ProjectileLightPreset285.Length-1,ProjectileLightColor285));if(preset==0)return baseTint;Color selected=ProjectileLightPreset285[preset];return ProjectileLightMixed285?BlendProjectileLight285(baseTint,selected,.48f):selected;}
  void ProjectileGroundLight170(V point,float radius,Color tint,float strength,float lift170=1.2f){
   float brightness=Math.Max(0f,ProjectileLightBrightness285),radiusScale=.85f+brightness*.55f,powerScale=Math.Max(0f,brightness*3.2f);
   Color userTint=ResolveProjectileLightTint285(tint);
   PlanetLightLayer170(point,radius*3.9f*radiusScale,userTint,strength*.18f*powerScale,lift170+3.0f,28);
   PlanetLightLayer170(point,radius*2.4f*radiusScale,userTint,strength*.55f*powerScale,lift170+1.35f,24);
   PlanetLightLayer170(point,radius*1.5f*radiusScale,userTint,strength*1.10f*powerScale,lift170+.55f,22);
   PlanetLightLayer170(point,radius*.85f*radiusScale,userTint,strength*1.80f*powerScale,lift170+.10f,18);
  }
  void DrawProjectileGroundLights170(Game g){
   foreach(Bullet bullet in g.Bullets){
    Color tint=ShotTint69(bullet.Kind);
    float radius=bullet.Kind==3?20.5f:bullet.Kind==4?17.5f:bullet.Kind==2?16.0f:14.5f;
    float strength=bullet.Kind==3?.42f:bullet.Kind==4?.32f:bullet.Kind==2?.28f:.24f;
    ProjectileGroundLight170(bullet.P,radius,tint,strength);
   }
   foreach(BossProjectile shot in g.EnemyShots71){
    Color tint=HostileGroundTint170(shot.Kind);
    float radius=shot.Kind==2?17.5f:shot.Kind==3?19.0f:15.5f;
    float strength=shot.Kind==2?.30f:shot.Kind==3?.34f:.26f;
    ProjectileGroundLight170(shot.P,radius,tint,strength,1.6f);
   }
   foreach(BossProjectile shot in g.BossProjectiles){
    if(shot.Kind==1)continue;
    Color tint=HostileGroundTint170(shot.Kind);
    float radius=shot.Kind==2?20.0f:shot.Kind==3?23.0f:17.0f;
    float strength=shot.Kind==2?.38f:shot.Kind==3?.42f:.30f;
    ProjectileGroundLight170(shot.P,radius,tint,strength,1.85f);
   }
   depthMask(1);disable(BLEND);
  }
  void CraftSphere67(Game g,bool second){V p=second?g.Ship62:g.Ship;float inv=second?g.Invincible62:g.Invincible,down=second?g.Down2Time65:g.Down1Time65;if(down<=0&&((second?g.Boost2_71.Time:g.Boost1_71.Time)>0||inv<=0||(int)(g.Time*12)%2==0)){planetPush();StampSphere67(p,second?(g.HeadingReady62?g.Heading62:g.Angle62):(g.VisualReady81?g.VisualHeading81:g.Angle),Game.ShipContactRadius*Scale67*.65f);shipRotate(second?g.Bank62:g.VisualBank,0,1,0);shipRotate(second?g.Pitch62:g.VisualPitch81,1,0,0);FighterLight(false);CraftType=g.ActiveCraft389;planetPush();shipScale(MissionShipScale472,MissionShipScale472,MissionShipScale472);DrawFighterMesh(g.Time,Math.Max(.12f,second?g.Power62_298:g.VisualPower298),0,false);DrawCraftModules95(g);planetPop();planetPop();}}
  // v221: The distant ringed planet is a SKY object at this exact direction
  // (DrawDeepSpace55 in GpuIntro41.cs). The combat wreck follows that same
  // celestial direction, NOT the gameplay camera's forward/focus vector.
  // It is always hundreds of units away from the camera, avoiding a close-up.
  readonly float[] combatWreckBasis272=new float[16];
  void ApplySphereSunLighting67(Game g,bool animated){FighterLight(false);PlanetSun71(g.Time,animated);}
  // v435: moving terminator shared with combat planet's directional sun.
  // Compute in world coordinates BEFORE boss body orientation; do not attach sun to mesh.
  internal static float BossDaylight435(V surface,float seconds,bool animated,int nightBrightness437=30){
   IP n=Sphere67.Normal(surface);
   float a=2.3f+(animated?seconds:0f)*.025f;
   float x=(float)Math.Cos(a)*.9f,y=.4f,z=(float)Math.Sin(a)*.9f;
   float dot=(n.X*x+n.Y*y+n.Z*z)/(float)Math.Sqrt(x*x+y*y+z*z);
   float t=Math.Max(0f,Math.Min(1f,(dot+.14f)/.32f));
   float night=Math.Max(0f,Math.Min(400,nightBrightness437))/400f;return night+(1f-night)*t*t*(3f-2f*t);
  }
  void DrawCombatResearchWreck214(Game g){
   ApplySphereSunLighting67(g,true);
   IP ringSky221=new IP(-.7f,.22f,-.68f).Unit;
   // Derive camera right/up from current view matrix so the small visual offset
   // is stable even when the player flies around the big combat planet.
   IP skyRight221=new IP(introView[0],introView[4],introView[8]).Unit;
   IP skyUp221=new IP(introView[1],introView[5],introView[9]).Unit;
   IP pos=sphereEye67+ringSky221*900f+skyRight221*80f+skyUp221*52f;
   PointF ringPoint221,wreckPoint221;float ringDepth221,wreckDepth221;
   // No invisible offscreen wreck when the ringed planet itself is offscreen.
   if(!SkyProject55(ringSky221*900f,out ringPoint221,out ringDepth221))return;
   if(!IntroProject(pos,out wreckPoint221,out wreckDepth221))return;
   if(wreckPoint221.X<-150||wreckPoint221.X>1430||wreckPoint221.Y<-110||wreckPoint221.Y>830)return;
   planetPush();
   try{
    shipTranslate(pos.X,pos.Y,pos.Z);
    float[] basis221=combatWreckBasis272;
    IP toward221=IntroScene41.Cross(skyRight221,skyUp221).Unit;
    Matrix(basis221,new PlanetCrawler.P(skyRight221.X,skyRight221.Y,skyRight221.Z),
      new PlanetCrawler.P(skyUp221.X,skyUp221.Y,skyUp221.Z),
      new PlanetCrawler.P(toward221.X,toward221.Y,toward221.Z),new PlanetCrawler.P());
    planetMultiply(basis221);
    shipRotate(-11,0,0,1);shipRotate(24,0,1,0);shipRotate(26,1,0,0);
    shipScale(2.20f,2.20f,2.20f);
    disable(0x0B44);disable(TEX);disable(BLEND);enable(DEPTH);depthMask(1);
    weatherTime65=g.Time;
    DrawDetailedResearchWreck211(g.Level+214,false);
   }finally{planetPop();}
  }
  public void SphereScene67(Game g,bool glow,bool nebula,bool rays,bool animated,Bitmap flameBitmap=null,Bitmap glowBitmap=null){UpdatePlanetSunClock436(g.Time,animated);VisibleRocks73=CulledRocks73=CulledFighters73=CulledRings73=LineVertices73=LineDrawCalls73=CulledEffectLines76=0;lineCullActive76=lineCullEnabled76&&(!Software||Environment.GetEnvironmentVariable("ASTEROIDY_FORCE_VIS_CULL")=="1")&&g.Particles.Count>=100;g.UpdateSphereCamera67(0);EnsureIntroPlanet(g.Level);weatherTime65=animated?g.Time:0;float separation=g.CoopEnabled62?Sphere67.Delta(g.Ship62,g.Ship).Length/Sphere67.Radius:0;sphereEye67=g.SphereFocus67*(310+(g.BossActive?65:0)+Math.Min(115,separation*50)+(g.BossArrivalActive86?-100*(float)Math.Sin(g.BossArrivalProgress86*Math.PI):0));
   // v167: victory orbit. The surface visibly turns behind the text while all combat
   // entities and their velocities remain frozen. Entire 3D world is still rendered.
   if(g.SummaryActive166){float radians=Math.Min(500,g.SummaryTime166)*.045f;
    IP orbital=(g.SphereFocus67*(float)Math.Cos(radians)+g.SphereRight67*(float)Math.Sin(radians)).Unit;
    sphereEye67=orbital*sphereEye67.Length;}
   OrbitWorld50.View(sphereEye67,new IP(),g.SphereUp67,introView);deepSpaceTime55=animated?g.Time:0;Flush2D();clearColor(.012f,.021f,.04f,1);depthMask(1);clear(0x4000|0x0100);IntroSky(glow,nebula,rays,true);IntroProjection();enable(DEPTH);depthMask(1);disable(TEX);disable(BLEND);disable(0x0B44);ApplySphereSunLighting67(g,animated);shipMaterial(0x0408,0x1600,none);planetPush();float missionPlanetScale523=MissionPlanetScale523(100f);shipScale(missionPlanetScale523,missionPlanetScale523,missionPlanetScale523);enable(0x0B44);planetSurfacePass436=PlanetLightEnabled436;try{DrawPlanetSolid();}finally{planetSurfacePass436=false;}disable(0x0B44);if(planetGltf463==null&&g.Level!=25 && g.Level!=Vulkaris276.Level && g.Level!=Carbonis277.Level)DrawPlanetCrawler(g.Time,animated);if(planetGltf463==null&&g.Level!=Vulkaris276.Level && g.Level!=Carbonis277.Level)DrawWeather65(planet,g.Time,animated,true);planetPop();disable(0x0B44);if(glow)DrawAtmosphere47(new PlanetCrawler.P(),new PlanetCrawler.P(sphereEye67.X,sphereEye67.Y,sphereEye67.Z),HomeWorldOuterRadius523);DrawCombatResearchWreck214(g);if(g.Level!=25)DrawPlanetShadows170(g,animated);DrawCrabTracks178(g);DrawProjectileGroundLights170(g);DrawPlanetFireflies438(g,animated);
   enable(0x0B44);if(RockInstancingAvailable75&&ToonEnabled60&&g.Rocks.Count>=(g.Level==25?16:24)){if(g.Level==25)DrawAmigaRockInstances269(g);else DrawRockInstances75(g);}else{InstancedRockCount75=InstancedRockDrawCalls75=0;foreach(Rock rock in g.Rocks)RockSphere67(g,rock);}disable(0x0B44);
   RobotTriangles70=0;foreach(Bug bug in g.Bugs){if(bug.Robot70==null&&!VisibleSurface73(bug.P,(bug.Hunter?25:19)*Scale67)){CulledFighters73++;continue;}if(bug.Robot70!=null){DrawRobot70(g,bug);continue;}if(bug.Shooter71>=0){DrawShooter71(g,bug);continue;}V direction=Sphere67.Delta(g.Ship,bug.P);ApplySphereSunLighting67(g,animated);planetPush();StampSphere67(bug.P,(float)Math.Atan2(direction.Y,direction.X),Scale67*(bug.Hunter?20:16));disable(BLEND);disable(TEX);enable(DEPTH);DrawBossMesh65(g,bug.Hunter?3:1);planetPop();}
   DrawRobotDebris70(g);bool scoutDeath173=g.BossType==4&&g.SummaryActive166&&g.SummaryBosses166>0&&g.BossDefeatedAt==g.Level&&g.SummaryTime166<4.8f;
   if((g.BossActive||scoutDeath173)&&VisibleSurface73(g.BossPosition,74*Game.BossSize68*Scale67*g.BossArrivalScale86)){ApplySphereSunLighting67(g,animated);planetPush();StampSphere67(g.BossPosition,g.BossAim,74*Game.BossSize68*Scale67*g.BossArrivalScale86);enable(DEPTH);disable(TEX);disable(BLEND);if(HasCampaignBossAsset83(g)){planetPop();DrawGalleryBossWorld82(g,animated);}else{WarnMissingBossModel87(g);SetBossDaylight435(PlanetLightEnabled436?BossDaylight435(g.BossPosition,sunClock436,sunAnimated436,PlanetNightBrightness437):1f);try{DrawBossMesh65(g,g.BossType);}finally{SetBossDaylight435(1f);planetPop();}}}
   if((g.MissionObjective65==Objective65.Escort||g.MissionObjective65==Objective65.Defend)&&VisibleSurface73(g.ObjectivePosition65,15*Scale67)){planetPush();StampSphere67(g.ObjectivePosition65,-Game.PI/2,7);FighterLight(false);CraftType=2;DrawFighterMesh(g.Time,.15f,0,g.ObjectiveHit65>0);planetPop();}
   DrawCombatPieces125(g);
   if(g.MiningDetached389&&g.ShipType==Game.TransportShipType388&&VisibleSurface73(g.MiningCarrierPos389,18*Scale67)){
    planetPush();StampSphere67(g.MiningCarrierPos389,g.MiningCarrierHeading389,Game.ShipContactRadius*Scale67*.65f*1.15f);
    FighterLight(false);CraftType=7;DrawFighterMesh(g.Time,.10f,0,false);planetPop();
   }
   CraftSphere67(g,false);if(g.CoopEnabled62)CraftSphere67(g,true);DroneSphere305(g);
   disable(TEX);disable(0x0B50);disable(0x0B44);enable(DEPTH);enable(BLEND);depthMask(0);blendFunc(0x0302,1);
   DrawExplosions524(g);
   DrawShipShots69(g,glow);DrawDepthEffects69(g,flameBitmap,glowBitmap,glow);DrawHostileShots72(g,glow,flameBitmap);DrawSpherePlasma146(g);disable(TEX);blendFunc(0x0302,1);
   // v473: remove decorative warning rings around enemy ships; leave combat AI and threat warnings intact.
   DrawThreatWarnings71(g);
   if(g.GuardianOwned&&g.GuardianEnabled298&&g.GuardianLock298&&g.GuardianLaser298>0)SphereLine67(g.GuardianPosition298,g.GuardianLockPoint298,Color.FromArgb(Math.Min(180,(int)(142*g.GuardianLaser298)),255,72,82));
   foreach(Pickup p in g.Pickups){RingSphere67(p.P,p.Trophy78?16:p.Kind==Supply.Boost71?13:p.Kind==Supply.Flame?11:p.Kind==Supply.Tarcza145?17:4.5f,p.Trophy78?Color.Gold:p.Kind==Supply.Boost71?Color.Cyan:p.Kind==Supply.Flame?Color.FromArgb(255,117,54):p.Kind==Supply.Tarcza145?Color.FromArgb(100,255,219):Color.FromArgb(255,222,118));if(p.Kind==Supply.Boost71){SphereLine67(Sphere67.Offset(p.P,new V(-5,-6)),Sphere67.Offset(p.P,new V(4,0)),Color.White);SphereLine67(Sphere67.Offset(p.P,new V(4,0)),Sphere67.Offset(p.P,new V(-5,6)),Color.White);}}
   // v520: boost is still active, but the floating ring is gone.
   if(g.Boost1_71.Time>0)SphereLine67(Sphere67.Offset(g.Ship,Game.Direction(g.Angle)*-65),g.Ship,Color.Cyan);
   if(g.CoopEnabled62&&g.Boost2_71.Time>0)SphereLine67(Sphere67.Offset(g.Ship62,Game.Direction(g.Angle62)*-65),g.Ship62,Color.Cyan);
   foreach(Particle p in g.Particles)SphereLine67(Sphere67.Offset(p.P,p.Velocity*-.024f),p.P,Color.FromArgb(Math.Max(0,Math.Min(255,(int)(255*p.Life/p.MaxLife))),p.Kind==1?Color.Orange:Color.Cyan));
   foreach(LightBurst b in g.Lights)if(b.Life>0&&!(ExplosionReady524&&g.NearDestruction524(b.P)))RingSphere67(b.P,10+(1-b.Life/b.MaxLife)*65,Color.FromArgb((int)(Math.Min(1,b.Life/b.MaxLife)*180),b.Kind==1?Color.Orange:Color.Cyan));
   for(int i=0;i<g.Napalm.Length;i+=3){NapalmParticle p=g.Napalm[i];if(p.Life>0)SphereLine67(Sphere67.Offset(p.P,p.Velocity*-.035f),p.P,Color.FromArgb(Math.Min(255,(int)(p.Life*190)),73,180,255));}
   foreach(NapalmPatch p in g.NapalmPatches)if(p.Life>0)RingSphere67(p.P,p.Radius,Color.FromArgb(180,65,173,255));foreach(SlimePatch p in g.SlimePatches)if(p.Life>0)RingSphere67(p.P,42,Color.FromArgb(150,123,232,60));
   // v473: remove always-visible selection/collision rings around player and co-op craft.
   // v520: NO rings around the player's craft (shield, guardian, invulnerability,
   // recovery). Underlying shields, protection and powerups remain unchanged.
   BossTelegraph159(g);if(g.BossWeakOpen65)RingSphere67(g.BossWeakPoint65,16,Color.FromArgb(255,245,156));
   FlushSphereLines73();depthMask(1);disable(BLEND);shipMaterial(0x0408,0x1600,none);disable(0x0B50);disable(0x0B57);disable(0x0BA1);disable(0x4000);disable(0x4001);disable(0x0B44);Begin2D();SphereFrames67++;
  }
  void DisposeSphere67(){DisposeRockInstancing75();DisposeRobot70();DisposeCombat69();if(amigaRockBuffer263!=0){deleteBuffers(1,ref amigaRockBuffer263);amigaRockBuffer263=0;}amigaRockVertices263=null;for(int i=0;i<sphereRocks67.Length;i++){if(sphereRockBuffers67[i]!=0){deleteBuffers(1,ref sphereRockBuffers67[i]);sphereRockBuffers67[i]=0;}sphereRocks67[i]=null;}}
 }
 public sealed partial class Renderer {
  void SphereRadarPoint67(Canvas c,Game g,V position,Color tint,float size){IP n=Sphere67.Normal(position);float x=100+Sphere67.Dot(n,g.SphereRight67)*63,y=528-Sphere67.Dot(n,g.SphereUp67)*63;float visible=Sphere67.Dot(n,g.SphereFocus67);c.FillEllipse(Brush(Color.FromArgb(visible<0?90:230,tint)),x-size,y-size,size*2,size*2);}
  void DrawSphere67(Canvas c,Game g,int best,bool sound){c.Gpu.SphereScene67(g,GlowEnabled,NebulaEnabled,SolarRaysEnabled,AnimatedBackground,FlameTexture(),glows[2,1]);if(!g.BossArrivalActive86)c.Gpu.FinishWorldPost104();if(g.BossArrivalActive86||g.SummaryActive166)return;PointF p;float scale;RockIntegrity70(c,g);if(!W3NativeEnabled315)BoostHud71(c,g);
   foreach(Pickup coin in g.Pickups)if(c.Gpu.ProjectSphere67(coin.P,out p,out scale)){if(coin.Kind==Supply.Boost71){}else if(coin.Kind==Supply.Flame)NapalmSprite(c,FlameTexture(),new V(p.X,p.Y),12*scale,coin.Angle*57.3f,1);else if(coin.Kind==Supply.Tarcza145){float radius145=Math.Max(8,11*scale);c.FillEllipse(Brush(Color.FromArgb(100,31,145,154)),p.X-radius145,p.Y-radius145,2*radius145,2*radius145);c.DrawEllipse(Stroke(Color.FromArgb(250,128,255,241),2.5f),p.X-radius145,p.Y-radius145,2*radius145,2*radius145);Line(c,new V(p.X-radius145*.4f,p.Y),new V(p.X+radius145*.4f,p.Y),Color.White,2);Line(c,new V(p.X,p.Y-radius145*.4f),new V(p.X,p.Y+radius145*.4f),Color.White,2);}else DrawCoin(c,new V(p.X,p.Y),(coin.Trophy78?15f:4.5f)*scale,coin.Angle+g.Time*2.4f);}
   // Real 3D drone is rendered by DroneSphere305 in the depth-tested world pass.
   /* v520: hide circular shield HUD decoration around ship, not the shield ability */if(c.Gpu.ProjectSphere67(g.Ship,out p,out scale))Text(c,g.Down1Time65>0?"P1 · RATUJ":g.CoopEnabled62?"P1":"",p.X-40,p.Y+20,0,Cyan,80,StringAlignment.Center);if(g.CoopEnabled62&&c.Gpu.ProjectSphere67(g.Ship62,out p,out scale))Text(c,g.Down2Time65>0?"P2 · RATUJ":"P2",p.X-40,p.Y+20,0,Rust,80,StringAlignment.Center);
   if(g.CoopEnabled62&&(g.Down1Time65>0||g.Down2Time65>0)){Box(c,new RectangleF(430,580,420,43),Color.FromArgb(220,26,19,27));Text(c,"RATUNEK · "+g.RescueProgress65.ToString("F1")+" / 2 s · "+Math.Ceiling(Math.Max(g.Down1Time65,g.Down2Time65))+" s",445,590,0,Rust,390,StringAlignment.Center);}
   if(!W3NativeEnabled315){Box(c,new RectangleF(23,448,154,158),Color.FromArgb(200,7,15,27));c.DrawEllipse(Stroke(Color.FromArgb(120,Cyan),1),37,465,126,126);c.DrawEllipse(Stroke(Color.FromArgb(55,Cyan),1),69,497,62,62);foreach(Rock rock in g.Rocks)SphereRadarPoint67(c,g,rock.P,Olive,2);foreach(Bug bug in g.Bugs)SphereRadarPoint67(c,g,bug.P,Rust,3);if(g.BossActive)SphereRadarPoint67(c,g,g.BossPosition,Color.Red,4);foreach(Pickup coin in g.Pickups)SphereRadarPoint67(c,g,coin.P,coin.Kind==Supply.Boost71?Cyan:coin.Kind==Supply.Tarcza145?Color.FromArgb(101,255,223):Color.Gold,2);if(g.MissionObjective65==Objective65.Defend)SphereRadarPoint67(c,g,g.Ship,Cyan,4);if(g.CoopEnabled62)SphereRadarPoint67(c,g,g.Ship62,Color.Orange,4);Text(c,"RADAR PLANETY",30,451,0,Soft,140,StringAlignment.Center);}
   if(g.BossActive&&!c.Gpu.ProjectSphere67(g.BossPosition,out p,out scale)){V d=Sphere67.Delta(g.BossPosition,g.Ship);V screen=g.ScreenVector67(new V(1,0));V down=g.ScreenVector67(new V(0,1));float dx=d.X*screen.X+d.Y*screen.Y,dy=d.X*down.X+d.Y*down.Y;float length=(float)Math.Sqrt(dx*dx+dy*dy);if(length>0){float x=640+dx/length*420,y=360+dy/length*205;Text(c,"BOSS → "+((int)d.Length),x-70,y,0,Rust,140,StringAlignment.Center);}}StyleFrame58(c);DrawOverlay(c,g,best,sound);DrawBossHealth(c,g);DrawObjectiveHud65(c,g);DrawFlameHud(c,g);if(g.Flash>0)Line(c,new V(0,718),new V(1280,718),Rust,5);
  }
 }
}
