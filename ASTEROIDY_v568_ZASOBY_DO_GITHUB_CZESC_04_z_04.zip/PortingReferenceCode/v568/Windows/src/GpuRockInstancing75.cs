using System;
using System.Drawing;
using System.Runtime.InteropServices;
using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  // GL 3.3 core or ARB instanced arrays, with the unchanged per-rock code path
  // as fallback on old drivers, software implementations or without toon shading.
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void InstancedDraw75(uint mode,int first,int vertices,int instances);
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void AttribDivisor75(uint index,uint divisor);
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void AttribPointer75(uint index,int count,uint type,byte normalized,int stride,IntPtr offset);
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void BindAttrib75(uint program,uint index,[MarshalAs(UnmanagedType.LPStr)]string name);
  InstancedDraw75 instancedDraw75;AttribDivisor75 attribDivisor75;AttribPointer75 attribPointer75;
  U enableAttrib75,disableAttrib75;
  uint rockProgram75,instanceBuffer75;
  const int InstanceFloats75=16;
  readonly float[][] rockInstanceMatrices75=new float[80][];
  readonly int[] rockInstanceCounts75=new int[80];
  readonly int[] rockInstanceStarts75=new int[80];
  float[] packedInstances75=new float[512*InstanceFloats75];
  public bool RockInstancingAvailable75{get;private set;}
  public int InstancedRockCount75{get;private set;}
  public int InstancedRockDrawCalls75{get;private set;}
  static IntPtr OptionalARB75(Func<string,IntPtr> resolve,string name){IntPtr address=resolve(name);return address!=IntPtr.Zero?address:resolve(name+"ARB");}
  void InitRockInstancing75(Func<string,IntPtr> resolve){
   if(Environment.GetEnvironmentVariable("ASTEROIDY_DISABLE_INSTANCING")=="1"){
    gpuLog66("v75 instancing disabled for comparison; original renderer retained");return;
   }
   if(Software&&Environment.GetEnvironmentVariable("ASTEROIDY_FORCE_INSTANCING")!="1"){
    gpuLog66("v75 software OpenGL: compatibility renderer selected to avoid shader instancing overhead");return;
   }
   if(genBuffers==null||deleteBuffers==null||bindBuffer==null||bufferData==null)return;
   IntPtr draw=OptionalARB75(resolve,"glDrawArraysInstanced"),div=OptionalARB75(resolve,"glVertexAttribDivisor");
   if(draw==IntPtr.Zero||div==IntPtr.Zero)return;
   try{
    instancedDraw75=(InstancedDraw75)Marshal.GetDelegateForFunctionPointer(draw,typeof(InstancedDraw75));
    attribDivisor75=(AttribDivisor75)Marshal.GetDelegateForFunctionPointer(div,typeof(AttribDivisor75));
    attribPointer75=Fn<AttribPointer75>(resolve,"glVertexAttribPointer");
    enableAttrib75=Fn<U>(resolve,"glEnableVertexAttribArray");disableAttrib75=Fn<U>(resolve,"glDisableVertexAttribArray");
    var create=Fn<CreateShader60>(resolve,"glCreateShader");var source=Fn<Source60>(resolve,"glShaderSource");
    var compile=Fn<U>(resolve,"glCompileShader");var shaderStatus=Fn<Status60>(resolve,"glGetShaderiv");
    var shaderLog=Fn<Log60>(resolve,"glGetShaderInfoLog");var deleteShader=Fn<U>(resolve,"glDeleteShader");
    var createProgram=Fn<CreateProgram60>(resolve,"glCreateProgram");var attach=Fn<UU>(resolve,"glAttachShader");
    var bind=Fn<BindAttrib75>(resolve,"glBindAttribLocation");var link=Fn<U>(resolve,"glLinkProgram");
    var programStatus=Fn<Status60>(resolve,"glGetProgramiv");var programLog=Fn<Log60>(resolve,"glGetProgramInfoLog");
    // The normal toon fragment logic and the light source are unchanged.
    // For v74 glLightfv is called with each asteroid's model matrix active.
    // Re-create that directional light in the vertex shader for each instance.
    string vs="#version 120\nattribute vec4 aRock0;attribute vec4 aRock1;attribute vec4 aRock2;attribute vec4 aRock3;varying vec3 normal60;varying vec3 position60;varying vec4 color60;varying vec3 rockLight75;void main(){mat4 world=mat4(aRock0,aRock1,aRock2,aRock3);vec4 eye=gl_ModelViewMatrix*world*gl_Vertex;position60=eye.xyz;normal60=gl_NormalMatrix*mat3(world)*gl_Normal;color60=gl_Color;rockLight75=(gl_ModelViewMatrix*world*vec4(-0.6,0.8,1.4,0.0)).xyz;gl_Position=gl_ProjectionMatrix*eye;}";
    string fs="#version 120\nvarying vec3 normal60;varying vec3 position60;varying vec4 color60;varying vec3 rockLight75;void main(){vec3 n=normalize(normal60);vec3 l=normalize(rockLight75);float d=max(0.0,dot(n,l));float band=0.25+0.33*smoothstep(0.30,0.32,d)+0.40*smoothstep(0.70,0.72,d);vec3 view=normalize(-position60);float rim=0.10*smoothstep(0.72,0.86,1.0-max(0.0,dot(n,view)))*smoothstep(0.1,0.3,d);vec3 ink=color60.rgb*band+color60.rgb*rim+gl_FrontMaterial.emission.rgb;gl_FragColor=vec4(clamp(ink,0.0,1.0),color60.a);}";
    uint vertex=0,fragment=0,program=0;
    try{
     vertex=CompileToon60(create,source,compile,shaderStatus,shaderLog,deleteShader,0x8B31,vs);
     fragment=CompileToon60(create,source,compile,shaderStatus,shaderLog,deleteShader,0x8B30,fs);
     program=createProgram();attach(program,vertex);attach(program,fragment);
     for(uint i=0;i<4;i++)bind(program,8+i,"aRock"+i);
     link(program);int ok;programStatus(program,0x8B82,out ok);
     if(ok==0)throw new InvalidOperationException("Rock instancing shader link: "+ToonLog60(programLog,program));
     rockProgram75=program;program=0;
    }finally{if(program!=0)deleteProgram60(program);if(vertex!=0)deleteShader(vertex);if(fragment!=0)deleteShader(fragment);}
    genBuffers(1,out instanceBuffer75);
    if(instanceBuffer75==0)throw new InvalidOperationException("glGenBuffers returned 0");
    RockInstancingAvailable75=true;
    gpuLog66("v75 asteroid GPU instancing supported; original meshes, shaders and collision models retained");
   }catch(Exception ex){gpuLog66("v75 instancing unavailable (original renderer active): "+ex.Message);DisposeRockInstancing75();}
  }
  void AddRockInstance75(Rock rock){
   int shape=(rock.Shape&7)*5+Math.Max(0,Math.Min(4,rock.ArmorTier))+(rock.Fragment77?40:0);
   float[] instances=rockInstanceMatrices75[shape];int index=rockInstanceCounts75[shape]*16;
   if(instances==null){instances=new float[16*8];rockInstanceMatrices75[shape]=instances;}
   if(index+16>instances.Length){Array.Resize(ref instances,instances.Length*2);rockInstanceMatrices75[shape]=instances;}
   IP n=Sphere67.Normal(rock.P),forward=Sphere67.Vector(rock.P,Game.Direction(rock.Angle)).Unit,right=Sphere67.Cross(forward,n).Unit;
   float ax=rock.Angle*41*(float)Math.PI/180f,ay=rock.Angle*23*(float)Math.PI/180f;
   float cx=(float)Math.Cos(ax),sx=(float)Math.Sin(ax),cy=(float)Math.Cos(ay),sy=(float)Math.Sin(ay);
   float scale=rock.Radius*Scale67;
   IP col0=(right*cy+forward*(sx*sy)-n*(cx*sy))*scale;
   IP col1=(forward*cx+n*sx)*scale;
   IP col2=(right*sy-forward*(sx*cy)+n*(cx*cy))*scale;
   IP pos=n*Shell67;
   instances[index]=col0.X;instances[index+1]=col0.Y;instances[index+2]=col0.Z;instances[index+3]=0;
   instances[index+4]=col1.X;instances[index+5]=col1.Y;instances[index+6]=col1.Z;instances[index+7]=0;
   instances[index+8]=col2.X;instances[index+9]=col2.Y;instances[index+10]=col2.Z;instances[index+11]=0;
   instances[index+12]=pos.X;instances[index+13]=pos.Y;instances[index+14]=pos.Z;instances[index+15]=1;
   rockInstanceCounts75[shape]++;
  }
  void DrawRockInstances75(Game g){
   InstancedRockCount75=InstancedRockDrawCalls75=0;
   Array.Clear(rockInstanceCounts75,0,rockInstanceCounts75.Length);
   foreach(Rock rock in g.Rocks){
    // Hit-emission rocks must retain their original per-object material state.
    if(rock.HitFlash>0){RockSphere67(g,rock);continue;}
    if(!VisibleSurface73(rock.P,rock.Radius*Scale67*1.4f)){CulledRocks73++;continue;}
    VisibleRocks73++;AddRockInstance75(rock);InstancedRockCount75++;
   }
   if(InstancedRockCount75==0)return;
   int total=0;
   for(int i=0;i<80;i++){rockInstanceStarts75[i]=total;total+=rockInstanceCounts75[i];}
   if(total*16>packedInstances75.Length)Array.Resize(ref packedInstances75,Math.Max(total*16,packedInstances75.Length*2));
   for(int i=0;i<80;i++)if(rockInstanceCounts75[i]>0){
    Array.Copy(rockInstanceMatrices75[i],0,packedInstances75,rockInstanceStarts75[i]*16,rockInstanceCounts75[i]*16);
   }
   GCHandle pin=GCHandle.Alloc(packedInstances75,GCHandleType.Pinned);
   try{
    bindBuffer(0x8892,instanceBuffer75);
    bufferData(0x8892,new IntPtr(total*16*4),pin.AddrOfPinnedObject(),0x88E0);
   }finally{pin.Free();}
   FighterLight(false);disable(TEX);disable(BLEND);enable(DEPTH);shipMaterial(0x0408,0x1600,none);
   useToon60(rockProgram75);
   for(uint i=8;i<12;i++){enableAttrib75(i);attribDivisor75(i,1);}
   enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);
   try{
    for(int shape=0;shape<80;shape++){
     int count=rockInstanceCounts75[shape];if(count==0)continue;
     // Upload each distinct mesh once. Only the 64-byte instance matrices change every frame.
     float[] vertices=RockVertices75(shape);EnsureRockBuffer75(shape);
     bindBuffer(0x8892,instanceBuffer75);
     int start=rockInstanceStarts75[shape]*64;
     for(uint i=0;i<4;i++)attribPointer75(8+i,4,0x1406,0,64,new IntPtr(start+(int)i*16));
     bindBuffer(0x8892,sphereRockBuffers67[shape]);
     vertexPointer(3,0x1406,40,IntPtr.Zero);shipNormal(0x1406,40,new IntPtr(12));colorPointer(4,0x1406,40,new IntPtr(24));
     instancedDraw75(4,0,vertices.Length/10,count);
     DrawCalls++;InstancedRockDrawCalls75++;SubmittedVertices+=vertices.Length/10*count;
    }
   }finally{
    for(uint i=8;i<12;i++){attribDivisor75(i,0);disableAttrib75(i);}
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);
    bindBuffer(0x8892,0);useToon60(0);
   }
  }

  // v269: Amiga showcase balls have one immutable white+red mesh. Previously the
  // scene submitted one DrawArrays per ball; now only the 64-byte transforms
  // change per frame. Keep red letter geometry, sphere bounce and hit feedback.
  void DrawAmigaRockInstances269(Game g){
   InstancedRockCount75=InstancedRockDrawCalls75=0;
   int count=0;
   float[] matrices=rockInstanceMatrices75[0];
   if(matrices==null){matrices=new float[16*64];rockInstanceMatrices75[0]=matrices;}
   foreach(Rock rock in g.Rocks){
    // Preserve the original hit-flash emission for the 0.14s flash window.
    if(rock.HitFlash>0f){RockSphere67(g,rock);continue;}
    if(!VisibleSurface73(rock.P,rock.Radius*Scale67*1.4f+rock.BounceHeight265*Scale67)){CulledRocks73++;continue;}
    VisibleRocks73++;
    int index=count*16;
    if(index+16>matrices.Length){Array.Resize(ref matrices,matrices.Length*2);rockInstanceMatrices75[0]=matrices;}
    IP n=Sphere67.Normal(rock.P),forward=Sphere67.Vector(rock.P,Game.Direction(rock.Angle)).Unit;
    IP right=Sphere67.Cross(forward,n).Unit;
    float scale=rock.Radius*Scale67;
    IP a=right*scale,b=forward*scale,c=n*scale,pos=n*(Shell67+rock.BounceHeight265*Scale67);
    matrices[index]=a.X;matrices[index+1]=a.Y;matrices[index+2]=a.Z;matrices[index+3]=0;
    matrices[index+4]=b.X;matrices[index+5]=b.Y;matrices[index+6]=b.Z;matrices[index+7]=0;
    matrices[index+8]=c.X;matrices[index+9]=c.Y;matrices[index+10]=c.Z;matrices[index+11]=0;
    matrices[index+12]=pos.X;matrices[index+13]=pos.Y;matrices[index+14]=pos.Z;matrices[index+15]=1;
    count++;
   }
   InstancedRockCount75=count;
   if(count==0)return;
   float[] vertices=AmigaRockVertices263();
   if(amigaRockBuffer263==0){
    GCHandle pin=GCHandle.Alloc(vertices,GCHandleType.Pinned);
    try{genBuffers(1,out amigaRockBuffer263);bindBuffer(0x8892,amigaRockBuffer263);
     bufferData(0x8892,new IntPtr(vertices.Length*4),pin.AddrOfPinnedObject(),0x88E4);SphereRockUploads67++;}
    finally{pin.Free();}
   }
   GCHandle instancePin=GCHandle.Alloc(matrices,GCHandleType.Pinned);
   try{bindBuffer(0x8892,instanceBuffer75);
    bufferData(0x8892,new IntPtr(count*16*4),instancePin.AddrOfPinnedObject(),0x88E0);}
   finally{instancePin.Free();}
   FighterLight(false);disable(TEX);disable(BLEND);enable(DEPTH);shipMaterial(0x0408,0x1600,none);
   useToon60(rockProgram75);
   for(uint i=8;i<12;i++){enableAttrib75(i);attribDivisor75(i,1);}
   enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);
   try{
    bindBuffer(0x8892,instanceBuffer75);
    for(uint i=0;i<4;i++)attribPointer75(8+i,4,0x1406,0,64,new IntPtr((int)i*16));
    bindBuffer(0x8892,amigaRockBuffer263);
    vertexPointer(3,0x1406,40,IntPtr.Zero);shipNormal(0x1406,40,new IntPtr(12));colorPointer(4,0x1406,40,new IntPtr(24));
    instancedDraw75(4,0,vertices.Length/10,count);
    DrawCalls++;InstancedRockDrawCalls75++;SubmittedVertices+=vertices.Length/10*count;
   }finally{
    for(uint i=8;i<12;i++){attribDivisor75(i,0);disableAttrib75(i);}
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);
    bindBuffer(0x8892,0);useToon60(0);
   }
  }
  void DisposeRockInstancing75(){RockInstancingAvailable75=false;if(instanceBuffer75!=0&&deleteBuffers!=null)deleteBuffers(1,ref instanceBuffer75);instanceBuffer75=0;if(rockProgram75!=0&&deleteProgram60!=null)deleteProgram60(rockProgram75);rockProgram75=0;}
 }
}
