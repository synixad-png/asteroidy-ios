using System;using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  readonly float[] skinPathValues65=new float[42];readonly PlanetSerpent[] serpents=new PlanetSerpent[2];readonly uint[] serpentBuffers=new uint[2];readonly PlanetCrawler.P[] serpentPoints=new PlanetCrawler.P[PlanetSerpent.PointCount64];
  public int SerpentBufferUploads{get;private set;}
  void DrawPlanetSerpents(float time,bool animated){if(!animated||time<4)return;for(int kind=0;kind<2;kind++){float phase=(time-4+kind*13)%30;if(phase>=22)continue;float progress=phase/22,fade=Math.Min(1,Math.Min(progress*30,(1-progress)*30));if(fade<.05f)continue;PlanetCrawler route=faunaRoutes[3+kind];float radius=(kind==0?.012f:.014f)*fade;
    PlanetSerpent.Points64(planet,route,time,kind,progress,radius,serpentPoints);for(int shadow=1;shadow<14;shadow+=3)FaunaShadow65(planet,serpentPoints[shadow],radius*1.8f,radius*3);
    if(serpents[kind]==null)serpents[kind]=new PlanetSerpent(kind);PlanetSerpent mesh=serpents[kind];GCHandle pin=new GCHandle();IntPtr ptr=IntPtr.Zero;
    try{if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){if(serpentBuffers[kind]==0){genBuffers(1,out serpentBuffers[kind]);pin=GCHandle.Alloc(mesh.Vertices,GCHandleType.Pinned);bindBuffer(0x8892,serpentBuffers[kind]);bufferData(0x8892,new IntPtr(mesh.Vertices.Length*4),pin.AddrOfPinnedObject(),0x88E4);SerpentBufferUploads++;}else bindBuffer(0x8892,serpentBuffers[kind]);}else{pin=GCHandle.Alloc(mesh.Vertices,GCHandleType.Pinned);ptr=pin.AddrOfPinnedObject();}
     enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);vertexPointer(3,0x1406,40,ptr);shipNormal(0x1406,40,new IntPtr(ptr.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(ptr.ToInt64()+24));disable(TEX);shipMaterial(0x0408,0x1202,softSpec);shipShine(0x0408,0x1601,18);
     for(int i=0;i<14;i++){skinPathValues65[i*3]=serpentPoints[i].X;skinPathValues65[i*3+1]=serpentPoints[i].Y;skinPathValues65[i*3+2]=serpentPoints[i].Z;}
     if(SkinGpu65){BeginSkin65(skinPathValues65,radius,kind);drawArrays(4,mesh.SkinStart65,mesh.SkinCount65);EndToon60();}else{DrawSkinCompat66(mesh,radius,kind);if(serpentBuffers[kind]!=0)bindBuffer(0x8892,serpentBuffers[kind]);else ptr=pin.AddrOfPinnedObject();vertexPointer(3,0x1406,40,ptr);shipNormal(0x1406,40,new IntPtr(ptr.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(ptr.ToInt64()+24));}DrawCalls++;SubmittedVertices+=mesh.SkinCount65;
     PlanetCrawler.P head=serpentPoints[0],headForward=(head-serpentPoints[1]).Unit,headUp=head.Unit,headRight=PlanetCrawler.Cross(headForward,headUp).Unit;headForward=PlanetCrawler.Cross(headUp,headRight).Unit;Matrix(boneMatrix,headRight*(radius*1.12f),headForward*(radius*1.12f),headUp*(radius*1.12f),head);planetPush();planetMultiply(boneMatrix);BeginToon60(true,false);drawArrays(4,mesh.HeadStart,mesh.HeadCount);EndToon60();planetPop();DrawCalls++;SubmittedVertices+=mesh.HeadCount;
     disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);if(serpentBuffers[kind]!=0)bindBuffer(0x8892,0);
    }finally{if(pin.IsAllocated)pin.Free();}SerpentsRendered++;FaunaRendered++;CrawlerVisible=true;
   }}
  void DisposeSerpents(){DisposeSkinCompat66();for(int i=0;i<2;i++){if(serpentBuffers[i]!=0){deleteBuffers(1,ref serpentBuffers[i]);serpentBuffers[i]=0;}serpents[i]=null;}}
 }
}
