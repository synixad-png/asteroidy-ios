// v463: one generic glTF 2.0 animation pipeline for all future planet swaps.
// Level 5 defaults to the original unmodified FERROFLUID GLB embedded in EXE.
// Optional planets/level_XX.glb overrides let users replace other levels without recompiling.
using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  H55Scene planetGltf463;int planetGltfLevel463=-1;
  internal float LastPlanetPose463 {get{return planetGltf463==null?0:planetGltf463.PlanetPoseSignature463;}}
  internal int LastPlanetClipChannels463 {get{return planetGltf463==null?0:planetGltf463.PlanetAnimationChannels463;}}
  void DisposePlanetGltf463(){if(planetGltf463!=null){planetGltf463.Dispose();planetGltf463=null;}planetGltfLevel463=-1;}
  static byte[] PlanetAssetBytes463(int level){
   string overrideFile=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"planets","level_"+level.ToString("D2",System.Globalization.CultureInfo.InvariantCulture)+".glb");
   byte[] bytes=null;
   if(File.Exists(overrideFile))bytes=File.ReadAllBytes(overrideFile);
   else if(level==5){using(Stream source=Assembly.GetExecutingAssembly().GetManifestResourceStream("Asteroidy.PlanetBoreas463")){
    if(source==null)throw new InvalidDataException("Boreas v463 embedded GLB resource missing");
    using(MemoryStream memory=new MemoryStream()){source.CopyTo(memory);bytes=memory.ToArray();}
   }}
   if(bytes==null)return null;
   if(bytes.Length<28||BitConverter.ToUInt32(bytes,0)!=0x46546C67||BitConverter.ToUInt32(bytes,4)!=2||BitConverter.ToUInt32(bytes,8)!=bytes.Length)
    throw new InvalidDataException("Planet GLB header invalid: level "+level);
   return bytes;
  }
  void EnsureReplacementPlanet463(){
   if(planetGltfLevel463!=planetLevel){DisposePlanetGltf463();planetGltfLevel463=planetLevel;try{
    byte[] bytes=PlanetAssetBytes463(planetLevel);
    if(bytes!=null){planetGltf463=new H55Scene(this,introResolve135,gpuLog66,false,0,bytes);
     if(!planetGltf463.TryLoad()){gpuLog66("PLANET v463: failed to load level "+planetLevel+" GLB: "+planetGltf463.Failure);DisposePlanetGltf463();planetGltfLevel463=planetLevel;}
     else gpuLog66("PLANET v463: level="+planetLevel+" glTF animation channels="+planetGltf463.PlanetAnimationChannels463+" duration="+planetGltf463.PlanetAnimationDuration463.ToString("F2"));
    }
   }catch(Exception e){gpuLog66("PLANET v463: "+e.ToString());DisposePlanetGltf463();planetGltfLevel463=planetLevel;}}
  }
  // The real NewHome290 GLB's farthest triangle vertex is 1.4419674 units
  // from its centre. In the orbital world it is rendered at x100, giving
  // an outer radius of 144.19674 world units. The v523 planet-only transform
  // maps each mission planet's ACTUAL outermost terrain/GLB vertex to this radius.
  internal const float HomeOuterRadius523=1.4419674f;
  internal const float HomeWorldOuterRadius523=100f*HomeOuterRadius523;
  PlanetMesh importedTerrain523;
  float importedTerrainRadius523;
  float ImportedPlanetRadius523(){
   if(planet==null)return 1f;
   if(importedTerrain523!=planet){
    importedTerrain523=planet;
    // Carbonis/Vulkaris store conservative legacy bounds in MaxRadius;
    // measure their actual terrain triangles once rather than scaling
    // against those old approximations.
    float[] data=planet.Vertices;
    int count=Math.Min(planet.TerrainVertices*10,data.Length);
    float maxSquared=.0001f;
    for(int i=0;i<count;i+=10){
     float r2=data[i]*data[i]+data[i+1]*data[i+1]+data[i+2]*data[i+2];
     if(r2>maxSquared)maxSquared=r2;
    }
    importedTerrainRadius523=(float)Math.Sqrt(maxSquared);
   }
   return importedTerrainRadius523;
  }
  float MissionMeshOuterRadius523(){
   EnsureReplacementPlanet463();
   // A loaded GLB is already centred and normalized to its outer radius by
   // DrawReplacedPlanet463(); procedural meshes keep their measured MaxRadius.
   if(planetGltf463!=null&&planetGltf463.Ready)return 1f;
   return planet==null?1f:Math.Max(.01f,planet.IsCarbonis277||planet.IsVulkaris276?ImportedPlanetRadius523():planet.MaxRadius);
  }
  float MissionPlanetScale523(float originalScale){return originalScale*HomeOuterRadius523/MissionMeshOuterRadius523();}
  bool DrawReplacedPlanet463(float time,bool animated){
   EnsureReplacementPlanet463();
   if(planetGltf463==null||!planetGltf463.Ready)return false;
   planetGltf463.AnimatePlanet463(time,animated);
   planetPush();try{
    // FERROFLUID authored base radius ~7.38. A normalized glTF sphere
    // stays the same apparent size as the old procedural planet.
    float norm=1f/planetGltf463.PlanetModelRadius463;shipScale(norm,norm,norm);shipTranslate(-planetGltf463.PlanetModelCenter463[0],-planetGltf463.PlanetModelCenter463[1],-planetGltf463.PlanetModelCenter463[2]);
    planetGltf463.Render(new float[]{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1},0,0,0,null);
   }finally{planetPop();}
   return true;
  }
 }
}
