using System;using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  uint atmosphereBuffer;float[] atmosphereVertices;readonly float[] atmosphereMatrix=new float[16];
  public int AtmosphereUploads{get;private set;}public int AtmosphereDraws{get;private set;}
  // Camera-oriented 3D atmospheric cap. Standard alpha blending preserves terrain;
  // depth testing keeps foreground craft and asteroids in front of the haze.
  int atmosphereTint296=int.MinValue;
  void AtmosphereVertex(System.Collections.Generic.List<float> data,float r,float angle,System.Drawing.Color tint){
   // v257: the original translucent spherical cap (the "dome"), not just a rim.
   float haze=.058f+.33f*(float)Math.Exp(-Math.Pow((r-1.055f)/.125f,2));
   float edge=Math.Max(0f,Math.Min(1f,(1.34f-r)/.18f));
   haze*=edge*edge*(3f-2f*edge);
   float depth=(float)Math.Sqrt(Math.Max(0,1.34f*1.34f-r*r));
   data.AddRange(new[]{r*(float)Math.Cos(angle),r*(float)Math.Sin(angle),depth,tint.R/255f,tint.G/255f,tint.B/255f,haze});
  }
   void DrawAtmosphere47(PlanetCrawler.P center,PlanetCrawler.P eye,float scale,System.Drawing.Color? tintOverride296=null){
   System.Drawing.Color tint296=tintOverride296.HasValue?tintOverride296.Value:planet.Biome.Glow;
   if(atmosphereTint296!=tint296.ToArgb()){
    if(atmosphereBuffer!=0&&deleteBuffers!=null){deleteBuffers(1,ref atmosphereBuffer);atmosphereBuffer=0;}
    atmosphereVertices=null;atmosphereTint296=tint296.ToArgb();
   }
   if(atmosphereVertices==null){var data=new System.Collections.Generic.List<float>(24*96*6*7);
    for(int ring=0;ring<24;ring++)for(int i=0;i<96;i++){
     float r=ring*1.34f/24,s=(ring+1)*1.34f/24,a=i*(float)Math.PI/48,c=(i+1)*(float)Math.PI/48;
     AtmosphereVertex(data,r,a,tint296);AtmosphereVertex(data,s,a,tint296);AtmosphereVertex(data,s,c,tint296);
     AtmosphereVertex(data,r,a,tint296);AtmosphereVertex(data,s,c,tint296);AtmosphereVertex(data,r,c,tint296);
    }atmosphereVertices=data.ToArray();}
   PlanetCrawler.P z=(eye-center).Unit,x=PlanetCrawler.Cross(Math.Abs(z.Y)<.95f?new PlanetCrawler.P(0,1,0):new PlanetCrawler.P(1,0,0),z).Unit,y=PlanetCrawler.Cross(z,x).Unit;
   Matrix(atmosphereMatrix,x*scale,y*scale,z*scale,center);planetPush();planetMultiply(atmosphereMatrix);
   disable(TEX);disable(0x0B50);disable(0x0B44);enable(DEPTH);depthMask(0);enable(BLEND);blendFunc(0x0302,0x0303);
   GCHandle pin=new GCHandle();IntPtr address=IntPtr.Zero;
   try{if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){if(atmosphereBuffer==0){genBuffers(1,out atmosphereBuffer);pin=GCHandle.Alloc(atmosphereVertices,GCHandleType.Pinned);bindBuffer(0x8892,atmosphereBuffer);bufferData(0x8892,new IntPtr(atmosphereVertices.Length*4),pin.AddrOfPinnedObject(),0x88E4);AtmosphereUploads++;}else bindBuffer(0x8892,atmosphereBuffer);}else{pin=GCHandle.Alloc(atmosphereVertices,GCHandleType.Pinned);address=pin.AddrOfPinnedObject();}
    enableClient(0x8074);enableClient(0x8076);vertexPointer(3,0x1406,28,address);colorPointer(4,0x1406,28,new IntPtr(address.ToInt64()+12));drawArrays(4,0,atmosphereVertices.Length/7);DrawCalls++;AtmosphereDraws++;SubmittedVertices+=atmosphereVertices.Length/7;
    disableClient(0x8074);disableClient(0x8076);if(atmosphereBuffer!=0)bindBuffer(0x8892,0);
   }finally{if(pin.IsAllocated)pin.Free();planetPop();depthMask(1);disable(BLEND);}
  }
  // v136: radial atmosphere is static for each planet. Cache the exact analytic
  // radial falloff in a GPU texture rather than rasterizing 6144 translucent
  // triangles on every combat frame. The original 3D atmosphere is retained
  // for sphere-fight scenes where geometry/depth ordering can differ.
  System.Drawing.Bitmap atmosphereFast136;
  int atmosphereFastLevel136=-1;
  System.Drawing.Bitmap AtmosphereTexture136(){
   if(atmosphereFast136!=null&&atmosphereFastLevel136==planetLevel)return atmosphereFast136;
   InvalidateAtmosphereFast136();
   const int size=512;const float R=1.34f;
   var bmp=new System.Drawing.Bitmap(size,size,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
   byte[] pixels=new byte[size*size*4];
   System.Drawing.Color tint=planet.Biome.Glow;
   for(int y=0;y<size;y++)for(int x=0;x<size;x++){
    float dx=(x+.5f-size*.5f)/(size*.5f)*R;
    float dy=(y+.5f-size*.5f)/(size*.5f)*R;
    float r=(float)Math.Sqrt(dx*dx+dy*dy);
    if(r>=R)continue;
    // v257: restore the old dome's translucent central shell and brighter limb.
    float haze=.058f+.33f*(float)Math.Exp(-Math.Pow((r-1.055f)/.125f,2));
    float edge=Math.Max(0f,Math.Min(1f,(R-r)/.18f));
    haze*=edge*edge*(3f-2f*edge);
    int alpha=Math.Max(0,Math.Min(255,(int)(haze*255+.5f))),i=(y*size+x)*4;
    pixels[i]=(byte)(tint.B*alpha/255);
    pixels[i+1]=(byte)(tint.G*alpha/255);
    pixels[i+2]=(byte)(tint.R*alpha/255);
    pixels[i+3]=(byte)alpha;
   }
   var data=bmp.LockBits(new System.Drawing.Rectangle(0,0,size,size),System.Drawing.Imaging.ImageLockMode.WriteOnly,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
   try{System.Runtime.InteropServices.Marshal.Copy(pixels,0,data.Scan0,pixels.Length);}
   finally{bmp.UnlockBits(data);}
   atmosphereFast136=bmp;atmosphereFastLevel136=planetLevel;
   return bmp;
  }
  void DrawAtmosphereFast136(PlanetCrawler.P center,PlanetCrawler.P eye,float scale){
   System.Drawing.Bitmap bmp=AtmosphereTexture136();
   PlanetCrawler.P z=(eye-center).Unit;
   PlanetCrawler.P x=PlanetCrawler.Cross(Math.Abs(z.Y)<.95f?new PlanetCrawler.P(0,1,0):new PlanetCrawler.P(1,0,0),z).Unit;
   PlanetCrawler.P y=PlanetCrawler.Cross(z,x).Unit;
   Matrix(atmosphereMatrix,x*scale,y*scale,z*scale,center);
   planetPush();planetMultiply(atmosphereMatrix);
   disable(DEPTH);depthMask(0);enable(BLEND);blendFunc(1,0x0303);
   enable(TEX);bindTexture(TEX,Texture(bmp));color(1,1,1,1);
   begin(7); // one camera-facing quad, already premultiplied PArgb
   texCoord(0,0);vertex(-1.34f,-1.34f,1.34f);
   texCoord(1,0);vertex( 1.34f,-1.34f,1.34f);
   texCoord(1,1);vertex( 1.34f, 1.34f,1.34f);
   texCoord(0,1);vertex(-1.34f, 1.34f,1.34f);
   end();DrawCalls++;SubmittedVertices+=4;
   disable(TEX);disable(BLEND);depthMask(1);planetPop();
  }
  void InvalidateAtmosphereFast136(){
   if(atmosphereFast136!=null){InvalidateTexture(atmosphereFast136);atmosphereFast136.Dispose();atmosphereFast136=null;}
   atmosphereFastLevel136=-1;
  }
  void InvalidateAtmosphere47(){InvalidateAtmosphereFast136();if(atmosphereBuffer!=0){deleteBuffers(1,ref atmosphereBuffer);atmosphereBuffer=0;}atmosphereVertices=null;}
  public const float PlanetDegreesPerSecond=2.2f;public static float PlanetRotation(int level,float time,bool animated){return level*29+(animated?time*PlanetDegreesPerSecond:0);}
  PlanetMesh planet;uint planetBuffer;uint carbonisUvBuffer277;System.Drawing.Bitmap carbonisBase277,carbonisEmission277,carbonisIrradiance288,carbonisCombined469;float carbonisCombinedBoost469=-1f;int planetLevel=-1;public int PlanetBufferUploads{get;private set;}public int PlanetTriangles{get{return planet==null?0:planet.Vertices.Length/30;}}
  static readonly float[] planetKey={-.7f,-.9f,1.3f,0},planetDiffuse={.55f,.62f,.57f,1},planetAmbient={.12f,.15f,.20f,1},planetFill={.16f,.23f,.30f,1},waterSpec={.32f,.53f,.60f,1};
  public void PlanetScreen(int level,float time,bool animated,bool glow=true){Flush2D();weatherTime65=animated?time:0;EnsureIntroPlanet(level);UpdatePlanetSunClock436(time,animated);
   disable(TEX);disable(DEPTH);matrixMode(0x1701);loadIdentity();ortho(0,1280,720,0,-2000,2000);matrixMode(0x1700);loadIdentity();
   // v523: actual outer mesh diameter matches the main planet even if an
   // imported GLB / procedural terrain has a different authored radius.
   float radius=MissionPlanetScale523(280f);
   if(planet.Basalt110)UpdateBasaltSun111(animated?time:0);
   // The v522 inline comment accidentally swallowed this existing glow call.
   if(glow)DrawPlanetGlow();
   enable(DEPTH);depthMask(1);clear(0x0100);disable(BLEND);disable(TEX);enable(0x0B44);FighterLight(false);PlanetSun71(time,animated);shipMaterial(0x0408,0x1600,none);
   // Screen Y is inverted in the model as well as the projection, preserving front faces.
   shipTranslate(640,397,0);shipScale(radius,-radius,radius);shipRotate(-18,1,0,0);shipRotate(PlanetRotation(level,time,animated),0,1,0);
   planetSurfacePass436=PlanetLightEnabled436;try{DrawPlanetSolid();}finally{planetSurfacePass436=false;}if(level!=Vulkaris276.Level&&level!=Carbonis277.Level&&planetGltf463==null){DrawPlanetLava116();DrawPlanetCrawler(time,animated);DrawWeather65(planet,time,animated);}DrawLevelResearchWreck210(level,time);disable(0x0B44);disable(0x0B50);disable(0x0B57);disable(0x0BA1);disable(0x4000);disable(0x4001);shipMaterial(0x0408,0x1202,softSpec);if(glow){loadIdentity();DrawAtmosphereFast136(new PlanetCrawler.P(640,397,0),new PlanetCrawler.P(640,397,2000),radius);}Begin2D();
  }

  // v210: depth-tested station geometry inside each ordinary combat level.
  // Fixed in the level scene rather than painted onto the sky bitmap.
  void DrawLevelResearchWreck210(int level,float time){
   planetPush();
   try{
    loadIdentity();
    // v218: place the wreck truly behind the planet: slightly overlapping the rim,
    // farther in depth, smaller on screen, and partially occluded by the globe.
    float sway=(float)Math.Sin(time*.006f+level*.8f)*4.5f;
    shipTranslate(742f+sway,136f+(float)Math.Cos(time*.010f+level)*3.5f,248f);
    shipRotate(-9f,0,0,1);shipRotate(18f,0,1,0);shipRotate(3f,1,0,0);
    shipScale(1.64f,1.64f,1.64f);
    disable(0x0B44);disable(TEX);disable(BLEND);enable(DEPTH);depthMask(1);
    DrawDetailedResearchWreck211(level+211,false);
   }finally{planetPop();}
  }
  void EnsureIntroPlanet(int level){if(planetLevel!=level){DisposePlanetGltf463();DisposeCarbonisUv277();DisposePlanetLava116();if(planetBuffer!=0){deleteBuffers(1,ref planetBuffer);planetBuffer=0;}planet=new PlanetMesh(level);planetLava116=planet.Basalt110?new LavaMesh116(planet):null;if(level!=Vulkaris276.Level&&level!=Carbonis277.Level)PrepareFauna(level);planetLevel=level;InvalidatePlanetGlow();InvalidateAtmosphere47();}}
  readonly float[] planetSun269=new float[4];
  static readonly float[] planetAmbient269={.045f,.06f,.09f,1f},planetFill269={.06f,.09f,.13f,1f};
  public bool PlanetLightEnabled436=true;public int PlanetLightSpeed436=100;public int PlanetNightBrightness437=160;public int PlanetFireflyColor438=0,PlanetFireflyCount438=36;
  // Integrate elapsed gameplay time, not absolute time * slider multiplier;
  // changing speed must not jump the sun across the planet.
  float sunClock436,lastGameTime436=float.NaN;
  bool sunAnimated436;
  void UpdatePlanetSunClock436(float gameTime,bool animated){
   if(!animated){sunAnimated436=false;lastGameTime436=float.NaN;return;}
   if(!sunAnimated436||float.IsNaN(lastGameTime436)||gameTime<lastGameTime436||gameTime-lastGameTime436>5f){sunClock436=gameTime;}
   else sunClock436+=Math.Max(0f,gameTime-lastGameTime436)*Math.Max(0f,Math.Min(400,PlanetLightSpeed436))*.01f;
   lastGameTime436=gameTime;sunAnimated436=true;
  }
  float SunAngle436(){return 2.3f+(sunAnimated436?sunClock436:0f)*.025f;}
  static float SunDaylight436(float nx,float ny,float nz,float sunX,float sunY,float sunZ){
   float v=nx*sunX+ny*sunY+nz*sunZ;
   float t=Math.Max(0f,Math.Min(1f,(v+.14f)/.32f));
   return .075f+.925f*t*t*(3f-2f*t);
  }
  bool planetSurfacePass436;
  void PlanetSun71(float time,bool animated){float a=SunAngle436();planetSun269[0]=(float)Math.Cos(a)*.9f;planetSun269[1]=.4f;planetSun269[2]=(float)Math.Sin(a)*.9f;planetSun269[3]=0;FighterLight(false);shipLight(0x4000,0x1203,planetSun269);shipLight(0x4000,0x1200,planetAmbient269);shipLight(0x4001,0x1201,planetFill269);}
  void DrawPlanetSolid(){if(DrawReplacedPlanet463(weatherTime65,true))return;GCHandle pinned=new GCHandle();IntPtr address=IntPtr.Zero;try{if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){if(planetBuffer==0){genBuffers(1,out planetBuffer);pinned=GCHandle.Alloc(planet.Vertices,GCHandleType.Pinned);bindBuffer(0x8892,planetBuffer);bufferData(0x8892,new IntPtr(planet.Vertices.Length*4),pinned.AddrOfPinnedObject(),0x88E4);PlanetBufferUploads++;}else bindBuffer(0x8892,planetBuffer);}else{pinned=GCHandle.Alloc(planet.Vertices,GCHandleType.Pinned);address=pinned.AddrOfPinnedObject();}
    enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);vertexPointer(3,0x1406,40,address);shipNormal(0x1406,40,new IntPtr(address.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(address.ToInt64()+24));
    if(planet.IsVulkaris276){DrawVulkaris276();}else if(planet.IsCarbonis277){DrawCarbonis277();}
    else{shipMaterial(0x0408,0x1202,none);shipShine(0x0408,0x1601,4);BeginToon60(true,false);if(planet.Basalt110)SetBasalt110(true,false);drawArrays(4,0,planet.TerrainVertices);EndToon60();shipMaterial(0x0408,0x1202,waterSpec);shipShine(0x0408,0x1601,48);BeginWater65(weatherTime65);drawArrays(4,planet.TerrainVertices,planet.WaterVertices);EndToon60();BeginToon60(true,false);shipMaterial(0x0408,0x1202,none);drawArrays(4,planet.TerrainVertices+planet.WaterVertices,planet.NatureVertices);EndToon60();if(planet.LavaVertices>0){shipMaterial(0x0408,0x1202,none);disable(0x0B50);BeginLava113(weatherTime65);drawArrays(4,planet.LavaStart,planet.LavaVertices);EndToon60();DrawCalls++;if(LavaLightBrightness287>0){float lavaBoost287=Math.Max(0f,LavaLightBrightness287);enable(BLEND);blendFunc(1,1);depthMask(0);disable(0x0B44);disableClient(0x8076);color(.54f*lavaBoost287,.18f*lavaBoost287,.05f*lavaBoost287,1f);drawArrays(4,planet.LavaStart,planet.LavaVertices);DrawCalls++;SubmittedVertices+=planet.LavaVertices;if(lavaBoost287>1.25f){color(.22f*(lavaBoost287-1f),.08f*(lavaBoost287-1f),.025f*(lavaBoost287-1f),1f);drawArrays(4,planet.LavaStart,planet.LavaVertices);DrawCalls++;SubmittedVertices+=planet.LavaVertices;}enableClient(0x8076);disable(BLEND);blendFunc(0x0302,0x0303);depthMask(1);color(1,1,1,1);}enable(0x0B50);}DrawCalls+=3;SubmittedVertices+=planet.Vertices.Length/10;}
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);if(planetBuffer!=0)bindBuffer(0x8892,0);
   }finally{if(pinned.IsAllocated)pinned.Free();}}
  // CARBONIS277: authentic glTF UV0, original 4096x2048 base color and
  // emissive maps, original triangle counts, separate untextured rock spires.
  // OpenGL compatibility approximation of glTF PBR, not a full BRDF renderer.
  void DisposeCarbonisUv277(){
   if(carbonisUvBuffer277!=0 && deleteBuffers!=null){deleteBuffers(1,ref carbonisUvBuffer277);carbonisUvBuffer277=0;}
  }
  static System.Drawing.Bitmap DecodeCarbonisImage277(string suffix){
   using(System.IO.Stream src=Carbonis277.Resource(suffix))
   using(System.Drawing.Bitmap decoded=new System.Drawing.Bitmap(src)){
    // Existing GL upload routine requires 32-bit premultiplied BGRA.
    var output=new System.Drawing.Bitmap(decoded.Width,decoded.Height,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
    using(System.Drawing.Graphics g=System.Drawing.Graphics.FromImage(output))g.DrawImage(decoded,0,0,decoded.Width,decoded.Height);
    return output;
   }
  }
  static readonly bool disableCarbonisEmission277=Environment.GetEnvironmentVariable("ASTEROIDY_CARBONIS_DISABLE_EMISSION277")=="1";
  // v469: compose all authored CARBONIS emission/irradiance into the existing
  // textured terrain pass, rather than drawing identical triangles with GL_EQUAL
  // and additive blending (which exposes micro-overlaps and z artifacts).
  // Only CARBONIS uses this bitmap; GLB planets, home and hangar are untouched.
  System.Drawing.Bitmap CarbonisCombined469(){
   float strength=Math.Max(0f,Math.Min(4f,LavaLightBrightness287));
   if(carbonisCombined469!=null && Math.Abs(strength-carbonisCombinedBoost469)<.0001f)return carbonisCombined469;
   if(carbonisCombined469!=null){InvalidateTexture(carbonisCombined469);carbonisCombined469.Dispose();carbonisCombined469=null;}
   System.Drawing.Bitmap source=carbonisBase277,emission=carbonisEmission277,irradiance=carbonisIrradiance288;
   int w=source.Width,h=source.Height;
   if(emission.Width!=w||emission.Height!=h)throw new InvalidOperationException("CARBONIS v469: emission map dimensions mismatch");
   // Authored irradiance is 1024x512 while base/emission are 4096x2048.
   // Resample at source resolution before composing the unique opaque pass.
   System.Drawing.Bitmap irradianceScaled=null;
   if(irradiance.Width!=w||irradiance.Height!=h){
    irradianceScaled=new System.Drawing.Bitmap(w,h,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
    using(var g=System.Drawing.Graphics.FromImage(irradianceScaled)){
     g.InterpolationMode=System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
     g.DrawImage(irradiance,0,0,w,h);
    }
    irradiance=irradianceScaled;
   }
   var result=new System.Drawing.Bitmap(w,h,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
   var rect=new System.Drawing.Rectangle(0,0,w,h);
   var fmt=System.Drawing.Imaging.PixelFormat.Format32bppPArgb;
   var a=source.LockBits(rect,System.Drawing.Imaging.ImageLockMode.ReadOnly,fmt);
   var b=emission.LockBits(rect,System.Drawing.Imaging.ImageLockMode.ReadOnly,fmt);
   var c=irradiance.LockBits(rect,System.Drawing.Imaging.ImageLockMode.ReadOnly,fmt);
   var d=result.LockBits(rect,System.Drawing.Imaging.ImageLockMode.WriteOnly,fmt);
   try{
    // The input bitmaps originate in GDI+; PArgb BGRA layout is used by the GL uploader.
    int stride=a.Stride; if(stride!=b.Stride||stride!=c.Stride||stride!=d.Stride||stride<0)throw new InvalidOperationException("CARBONIS v469 bitmap stride mismatch");
    var baseBytes=new byte[stride*h];var emissionBytes=new byte[stride*h];var nearBytes=new byte[stride*h];var output=new byte[stride*h];
    System.Runtime.InteropServices.Marshal.Copy(a.Scan0,baseBytes,0,baseBytes.Length);
    System.Runtime.InteropServices.Marshal.Copy(b.Scan0,emissionBytes,0,emissionBytes.Length);
    System.Runtime.InteropServices.Marshal.Copy(c.Scan0,nearBytes,0,nearBytes.Length);
    float irradiation=Math.Min(1f,strength*.45f);
    for(int y=0;y<h;y++)for(int x=0;x<w;x++){
     int i=y*stride+x*4;
     // Heat is defined by the emissive MAP, not the basalt texture's warm pixels.
     float heat=Math.Max(emissionBytes[i+2],Math.Max(emissionBytes[i+1],emissionBytes[i]))/255f;
     float mask=Math.Max(0f,Math.Min(1f,(heat-.12f)/.34f));mask=mask*mask*(3f-2f*mask);
     for(int j=0;j<3;j++){
      float e=(disableCarbonisEmission277?0f:emissionBytes[i+j]/255f*strength*mask);
      float reflected=(nearBytes[i+j]/255f)*irradiation*.38f;
      float factor=j==2?1f:j==1?.8f:.5f;
      float v=baseBytes[i+j]/255f+e*factor+reflected;
      output[i+j]=(byte)Math.Max(0,Math.Min(255,(int)(v*255f+.5f)));
     }
     output[i+3]=baseBytes[i+3];
    }
    System.Runtime.InteropServices.Marshal.Copy(output,0,d.Scan0,output.Length);
   }finally{source.UnlockBits(a);emission.UnlockBits(b);irradiance.UnlockBits(c);result.UnlockBits(d);if(irradianceScaled!=null)irradianceScaled.Dispose();}
   carbonisCombinedBoost469=strength;return carbonisCombined469=result;
  }

  void DrawCarbonis277(){
   Carbonis277 mesh=Carbonis277.Get();
   if(carbonisBase277==null)carbonisBase277=DecodeCarbonisImage277("Base");
   if(carbonisEmission277==null)carbonisEmission277=DecodeCarbonisImage277("Emissive");
   if(carbonisIrradiance288==null)carbonisIrradiance288=DecodeCarbonisImage277("Irradiance288");
   System.Runtime.InteropServices.GCHandle uvPin=new System.Runtime.InteropServices.GCHandle();
   try{
    System.IntPtr uvAddress=System.IntPtr.Zero;
    if(genBuffers!=null && bindBuffer!=null && bufferData!=null){
     if(carbonisUvBuffer277==0){
      genBuffers(1,out carbonisUvBuffer277);
      uvPin=System.Runtime.InteropServices.GCHandle.Alloc(mesh.Uv,System.Runtime.InteropServices.GCHandleType.Pinned);
      bindBuffer(0x8892,carbonisUvBuffer277);
      bufferData(0x8892,new System.IntPtr(mesh.Uv.Length*4),uvPin.AddrOfPinnedObject(),0x88E4);
     }else bindBuffer(0x8892,carbonisUvBuffer277);
    }else{
     if(bindBuffer!=null)bindBuffer(0x8892,0);
     uvPin=System.Runtime.InteropServices.GCHandle.Alloc(mesh.Uv,System.Runtime.InteropServices.GCHandleType.Pinned);
     uvAddress=uvPin.AddrOfPinnedObject();
    }
    enableClient(0x8078);uvPointer(2,0x1406,8,uvAddress);
    // glTexCoordPointer retains the UV buffer binding, even after rebinding
    // the packed position/normal/color VBO for the mesh draw calls.
    if(bindBuffer!=null && planetBuffer!=0)bindBuffer(0x8892,planetBuffer);
    disable(0x0B44);disable(BLEND);depthMask(1);
    shipMaterial(0x0408,0x1202,none);shipShine(0x0408,0x1601,5);
    enable(TEX);bindTexture(TEX,Texture(CarbonisCombined469()));
    if(planetSurfacePass436)BeginToon60(true,true);
    drawArrays(4,mesh.Starts[0],mesh.Counts[0]);DrawCalls++;SubmittedVertices+=mesh.Counts[0];
    if(planetSurfacePass436)EndToon60();
    // v469: no second/third coplanar terrain passes. CARBONIS emission is
    // premixed in CarbonisCombined469() and submitted with the base material.
    // Original untextured basalt-spire vertex colours (COLOR_0) remain intact.
    disable(TEX);disableClient(0x8078);shipMaterial(0x0408,0x1202,none);
    if(planetSurfacePass436)BeginToon60(true,false);
    drawArrays(4,mesh.Starts[1],mesh.Counts[1]);DrawCalls++;SubmittedVertices+=mesh.Counts[1];
    if(planetSurfacePass436)EndToon60();
    enable(0x0B44);depthMask(1);
   }finally{
    if(uvPin.IsAllocated)uvPin.Free();
    disableClient(0x8078);disable(TEX);disable(BLEND);depthMask(1);
    if(bindBuffer!=null && planetBuffer!=0)bindBuffer(0x8892,planetBuffer);
   }
  }
  // Seven original independent GLB groups; do not replace cities/forest/lava
  // with generated procedural decorations. Water is composited last with alpha.
  static readonly float[] vulkarisGlowCity276={.19f,.34f,.30f,1f};
  static readonly float[] vulkarisGlowLava276={.80f,.15f,.025f,1f};
  void DrawVulkaris276(){
   Vulkaris276 mesh=Vulkaris276.Get();int[] order={0,2,3,4,5,6,1};
   disable(0x0B44);disable(TEX);
   foreach(int group in order){
    if(group==1){enable(BLEND);blendFunc(0x0302,0x0303);depthMask(0);shipMaterial(0x0408,0x1202,waterSpec);shipShine(0x0408,0x1601,96);}
    else {disable(BLEND);depthMask(1);shipMaterial(0x0408,0x1202,none);shipShine(0x0408,0x1601,group==2?32:4);}
    if(group==3 || group==5){disable(0x0B50);shipMaterial(0x0408,0x1600,group==3?vulkarisGlowCity276:vulkarisGlowLava276);}
    else {enable(0x0B50);shipMaterial(0x0408,0x1600,none);}
    if(mesh.Counts[group]>0){if(planetSurfacePass436&&group!=3&&group!=5)BeginToon60(true,false);drawArrays(4,mesh.Starts[group],mesh.Counts[group]);if(planetSurfacePass436&&group!=3&&group!=5)EndToon60();DrawCalls++;SubmittedVertices+=mesh.Counts[group];if(group==5&&LavaLightBrightness287>0){float lavaBoost287=Math.Max(0f,LavaLightBrightness287);enable(BLEND);blendFunc(1,1);depthMask(0);disable(0x0B44);disable(0x0B50);disableClient(0x8076);color(.58f*lavaBoost287,.16f*lavaBoost287,.04f*lavaBoost287,1f);drawArrays(4,mesh.Starts[group],mesh.Counts[group]);DrawCalls++;SubmittedVertices+=mesh.Counts[group];if(lavaBoost287>1.25f){color(.26f*(lavaBoost287-1f),.08f*(lavaBoost287-1f),.025f*(lavaBoost287-1f),1f);drawArrays(4,mesh.Starts[group],mesh.Counts[group]);DrawCalls++;SubmittedVertices+=mesh.Counts[group];}enableClient(0x8076);disable(BLEND);blendFunc(0x0302,0x0303);depthMask(1);color(1,1,1,1);}}
   }
   depthMask(1);disable(BLEND);enable(0x0B50);shipMaterial(0x0408,0x1600,none);
   shipMaterial(0x0408,0x1202,none);enable(0x0B44);
  }
  void DisposePlanet(){DisposePlanetGltf463();if(carbonisCombined469!=null){InvalidateTexture(carbonisCombined469);carbonisCombined469.Dispose();carbonisCombined469=null;carbonisCombinedBoost469=-1f;}DisposeCarbonisUv277();if(carbonisBase277!=null){InvalidateTexture(carbonisBase277);carbonisBase277.Dispose();carbonisBase277=null;}if(carbonisEmission277!=null){InvalidateTexture(carbonisEmission277);carbonisEmission277.Dispose();carbonisEmission277=null;}if(carbonisIrradiance288!=null){InvalidateTexture(carbonisIrradiance288);carbonisIrradiance288.Dispose();carbonisIrradiance288=null;}DisposePlanetLava116();DisposeWeather65();InvalidateAtmosphere47();DisposePlanetAnimation();if(planetBuffer!=0){deleteBuffers(1,ref planetBuffer);planetBuffer=0;}planet=null;planetLevel=-1;}
 }
}
