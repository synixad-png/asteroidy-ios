using System;using System.Drawing;using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void NormalPointer(uint type,int stride,IntPtr ptr);
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void Vector4(uint light,uint property,[In]float[] value);
  [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void MaterialFloat(uint face,uint property,float value);
  NormalPointer shipNormal;Vector4 shipLight,shipMaterial;MaterialFloat shipShine;F3 shipTranslate,shipScale;F4 shipRotate;UU shipColorMaterial;UI shipLightModel;
  public int CraftType=1;readonly ShipMesh[] fighters={new ShipMesh(0),new ShipMesh(1),new ShipMesh(2),new ShipMesh(3),new ShipMesh(4),new ShipMesh(5),new ShipMesh(6,false),new ShipMesh(7,false)};readonly Bitmap[] fighterSkins=new Bitmap[8];readonly uint[] fighterBuffers=new uint[8];ShipMesh fighter{get{return fighters[Math.Max(0,Math.Min(fighters.Length-1,CraftType))];}}public int FighterBufferUploads{get;private set;}public int FighterTriangles{get{return fighter.Faces.Length;}}
  static readonly float[] hitEmission={.36f,.025f,.01f,1};
  static readonly float[] keyPosition={-.6f,.8f,1.4f,0},fillPosition={1,-.3f,.45f,0},keyDiffuse={.90f,.95f,1,1},fillDiffuse={.30f,.21f,.15f,1},ambient={.17f,.18f,.21f,1},none={0,0,0,1},specular={.82f,.88f,1,1},softSpec={.16f,.19f,.21f,1};
  void InitFighter(Func<string,IntPtr> resolve){shipNormal=Fn<NormalPointer>(resolve,"glNormalPointer");wreckNormalImm223=Fn<F3>(resolve,"glNormal3f");shipLight=Fn<Vector4>(resolve,"glLightfv");shipMaterial=Fn<Vector4>(resolve,"glMaterialfv");shipShine=Fn<MaterialFloat>(resolve,"glMaterialf");shipTranslate=Fn<F3>(resolve,"glTranslatef");shipScale=Fn<F3>(resolve,"glScalef");shipRotate=Fn<F4>(resolve,"glRotatef");shipColorMaterial=Fn<UU>(resolve,"glColorMaterial");shipLightModel=Fn<UI>(resolve,"glLightModeli");}
  void FighterLight(bool tunnel){enable(0x0B50);enable(0x4000);enable(0x4001);enable(0x0BA1);enable(0x0B57);shipColorMaterial(0x0408,0x1602);shipLightModel(0x0B52,0);shipLightModel(0x0B51,1);shipLight(0x4000,0x1203,keyPosition);shipLight(0x4000,0x1200,ambient);shipLight(0x4000,0x1201,keyDiffuse);shipLight(0x4000,0x1202,specular);shipLight(0x4001,0x1203,fillPosition);shipLight(0x4001,0x1200,none);shipLight(0x4001,0x1201,fillDiffuse);shipLight(0x4001,0x1202,softSpec);}
  void DrawFighterMesh(float time,float power,float side,bool hit){int type=Math.Max(0,Math.Min(fighters.Length-1,CraftType));if(fighterSkins[type]==null)fighterSkins[type]=ShipMesh.Skin(type);uint skin=Texture(fighterSkins[type]);GCHandle data=new GCHandle();IntPtr address=IntPtr.Zero;try{
    if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){if(fighterBuffers[type]==0){genBuffers(1,out fighterBuffers[type]);data=GCHandle.Alloc(fighter.Vertices,GCHandleType.Pinned);bindBuffer(0x8892,fighterBuffers[type]);bufferData(0x8892,new IntPtr(fighter.Vertices.Length*4),data.AddrOfPinnedObject(),0x88E4);FighterBufferUploads++;}else bindBuffer(0x8892,fighterBuffers[type]);}else{data=GCHandle.Alloc(fighter.Vertices,GCHandleType.Pinned);address=data.AddrOfPinnedObject();}
    enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);enableClient(0x8078);vertexPointer(3,0x1406,48,address);shipNormal(0x1406,48,new IntPtr(address.ToInt64()+12));colorPointer(4,0x1406,48,new IntPtr(address.ToInt64()+24));uvPointer(2,0x1406,48,new IntPtr(address.ToInt64()+40));
    for(int m=0;m<8;m++){if(fighter.Count[m]==0)continue;bool emissive=m==5||m==6;shipMaterial(0x0408,0x1600,hit&&!emissive?hitEmission:none);if(m==7){enable(BLEND);blendFunc(0x0302,0x0303);depthMask(0);}if(emissive){disable(0x0B50);disable(TEX);}else{enable(0x0B50);if(m==0||m==1||m==3||m==7){enable(TEX);bindTexture(TEX,skin);}else disable(TEX);shipMaterial(0x0408,0x1202,m==2||m==3?specular:softSpec);shipShine(0x0408,0x1601,m==2?92:m==3?64:24);}BeginToon60(!emissive,m==0||m==1||m==3);drawArrays(4,fighter.Start[m],fighter.Count[m]);EndToon60();DrawCalls++;SubmittedVertices+=fighter.Count[m];if(m==7){depthMask(1);disable(BLEND);}}
    disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);disableClient(0x8078);if(fighterBuffers[type]!=0)bindBuffer(0x8892,0);
   }finally{if(data.IsAllocated)data.Free();}
   // v491: engine-side sustained plasma, not the 12 flat blue wedges of v490.
   // EngineCenters retain the correct per-craft placements and chassis transforms.
   shipMaterial(0x0408,0x1600,none);disable(0x0B50);disable(0x0B57);disable(0x0BA1);
   disable(TEX);enable(BLEND);blendFunc(0x0302,1);depthMask(0);
   power=Math.Max(0,Math.Min(1,power));
   begin(4);
   foreach(ShipMesh.P engine in fighter.EngineCenters){
    float x=engine.X,ey=engine.Y,z=engine.Z;
    float sz=ShipMesh.VisualSize172;
    float plume=.17f+power*1.47f; // thrust drives length, idle still burns softly
    for(int layer=0;layer<3;layer++){
     float radial=layer==0?.12f:layer==1?.072f:.030f;
     float alpha=layer==0?.21f:layer==1?.48f:.82f;
     for(int plane=0;plane<3;plane++){
      float angle=plane*(float)Math.PI/3f;
      float dx=(float)Math.Cos(angle),dz=(float)Math.Sin(angle);
      for(int i=0;i<16;i++){
       float u0=i/16f,u1=(i+1)/16f;
       // traveling waves move through the exhaust without jittering its root
       float off0=(float)Math.Sin(u0*11-time*11f+plane*1.9f+x*2f)*u0*u0*.075f*power;
       float off1=(float)Math.Sin(u1*11-time*11f+plane*1.9f+x*2f)*u1*u1*.075f*power;
       float spread0=(float)Math.Pow(Math.Max(.035f,1-u0),.58f)*(1f+.11f*(float)Math.Sin(u0*28-time*21+plane));
       float spread1=(float)Math.Pow(Math.Max(.035f,1-u1),.58f)*(1f+.11f*(float)Math.Sin(u1*28-time*21+plane));
       float width0=sz*radial*spread0,width1=sz*radial*spread1;
       float fade0=alpha*(1-u0*u0)*(.83f+.17f*(float)Math.Sin(time*19-u0*37+plane));
       float fade1=alpha*(1-u1*u1)*(.83f+.17f*(float)Math.Sin(time*19-u1*37+plane));
       float y0=ey-plume*u0,y1=ey-plume*u1;
       float c0x=x+off0,c1x=x+off1;
       // warm white at nozzle -> orange / ember red along the tail
       float r0=1f,g0=layer==2?.96f-.19f*u0:layer==1?.65f-.27f*u0:.27f-.14f*u0;
       float r1=1f,g1=layer==2?.96f-.19f*u1:layer==1?.65f-.27f*u1:.27f-.14f*u1;
       float b0=layer==2?.49f*(1-u0):.035f,b1=layer==2?.49f*(1-u1):.035f;
       color(r0,g0,b0,fade0);vertex(c0x+dx*width0,y0,z+dz*width0);
       color(r0,g0,b0,fade0);vertex(c0x-dx*width0,y0,z-dz*width0);
       color(r1,g1,b1,fade1);vertex(c1x+dx*width1,y1,z+dz*width1);
       color(r1,g1,b1,fade1);vertex(c1x+dx*width1,y1,z+dz*width1);
       color(r0,g0,b0,fade0);vertex(c0x-dx*width0,y0,z-dz*width0);
       color(r1,g1,b1,fade1);vertex(c1x-dx*width1,y1,z-dz*width1);
       SubmittedVertices+=6;
      }
     }
    }
   }
   if(side!=0){float x=-Math.Sign(side)*1.28f;for(int k=0;k<8;k++){float a=k*(float)Math.PI/4,b=(k+1)*(float)Math.PI/4;color(1f,.75f,.24f,.75f);vertex(x,-.77f+(float)Math.Cos(a)*.05f,.02f+(float)Math.Sin(a)*.05f);vertex(x,-.77f+(float)Math.Cos(b)*.05f,.02f+(float)Math.Sin(b)*.05f);color(1f,.26f,.02f,0);vertex(x-Math.Sign(side)*(.28f+.36f*Math.Abs(side)),-.77f,.02f);SubmittedVertices+=3;}}
   end();DrawCalls++;depthMask(1);disable(BLEND);disable(0x4000);disable(0x4001);
  }
  public void FighterScreen(float x,float y,float scale,float yaw,float pitch,float roll,float time,float power,float side){Flush2D();enable(DEPTH);depthMask(1);clear(0x0100);matrixMode(0x1701);loadIdentity();ortho(0,1280,720,0,-2000,2000);matrixMode(0x1700);loadIdentity();FighterLight(false);shipTranslate(x,y,0);shipRotate(yaw,0,0,1);shipRotate(pitch,1,0,0);shipRotate(roll,0,1,0);shipScale(scale,-scale,scale);DrawFighterMesh(time,power,side,false);Begin2D();}
  public void FighterTunnel(Game game,float routeRoll){CraftType=game.ShipType;enable(DEPTH);depthMask(1);disable(BLEND);matrixMode(0x1701);loadIdentity();frustum(-640.0/560,640.0/560,-405.0/560,315.0/560,1,120);matrixMode(0x1700);loadIdentity();FighterLight(true);shipRotate(-routeRoll*180/(float)Math.PI,0,0,1);shipTranslate(game.TunnelX*.6f,-game.TunnelY*.68f-.68f,-5);shipRotate(-game.TunnelBankAngle*180/(float)Math.PI,0,0,1);shipRotate(-90,1,0,0);float scale62=(game.CoopEnabled62?.53f:.78f)*Game.ObjectScale;shipScale(scale62,scale62,scale62);planetPush();shipScale(MissionShipScale472,MissionShipScale472,MissionShipScale472);DrawFighterMesh(game.TunnelTime,1,0,game.TunnelHit>0);DrawCraftModules95(game);planetPop();disable(DEPTH);}
  void DisposeFighter(){for(int type=0;type<fighters.Length;type++){if(fighterBuffers[type]!=0){deleteBuffers(1,ref fighterBuffers[type]);fighterBuffers[type]=0;}if(fighterSkins[type]!=null){InvalidateTexture(fighterSkins[type]);fighterSkins[type].Dispose();fighterSkins[type]=null;}}}
 // v305: single cached GL vertex buffer for an actual 3D quadcopter body and four ducted motors.
 // Animated internal propellers are separate from fixed guard geometry.
 readonly DroneMesh305 escortDrone305=new DroneMesh305();uint escortDroneBuffer305;
 public int EscortDroneTriangles305{get{return escortDrone305.TriangleCount;}}
 public int EscortDroneDraws305{get;private set;}
 void DrawEscortDroneMesh305(float time){
  disable(TEX);disable(BLEND);disable(0x0B44);enable(DEPTH);depthMask(1);FighterLight(false);
  shipMaterial(0x0408,0x1600,none);shipMaterial(0x0408,0x1202,specular);shipShine(0x0408,0x1601,56);
  float[] mesh=escortDrone305.Vertices;GCHandle pin=new GCHandle();IntPtr address=IntPtr.Zero;
  try{
   if(genBuffers!=null&&bindBuffer!=null&&bufferData!=null){if(escortDroneBuffer305==0){genBuffers(1,out escortDroneBuffer305);pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);bindBuffer(0x8892,escortDroneBuffer305);bufferData(0x8892,new IntPtr(mesh.Length*4),pin.AddrOfPinnedObject(),0x88E4);}else bindBuffer(0x8892,escortDroneBuffer305);}
   else {pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);address=pin.AddrOfPinnedObject();}
   enableClient(0x8074);enableClient(0x8075);enableClient(0x8076);
   vertexPointer(3,0x1406,40,address);shipNormal(0x1406,40,new IntPtr(address.ToInt64()+12));colorPointer(4,0x1406,40,new IntPtr(address.ToInt64()+24));
   BeginToon60(true,false);drawArrays(4,0,mesh.Length/10);EndToon60();EscortDroneDraws305++;DrawCalls++;SubmittedVertices+=mesh.Length/10;
   disableClient(0x8074);disableClient(0x8075);disableClient(0x8076);if(escortDroneBuffer305!=0)bindBuffer(0x8892,0);
  }finally{if(pin.IsAllocated)pin.Free();}
  // Each motor spins three narrow blades WITHIN its own cage. The 3D propellers
  // have diameter ~.58, while protective rings have outside diameter .82.
  disable(0x0B50);disable(0x4000);disable(0x4001);disable(TEX);disable(BLEND);
  begin(4);
  int rotorIndex=0;foreach(DroneMesh305.P center in DroneMesh305.RotorCenters305){float phase=time*(rotorIndex%2==0?27f:-27f)+rotorIndex*1.41f;
   for(int blade=0;blade<3;blade++){float a=phase+blade*2*Game.PI/3f,b=a+.24f;float radius=.288f,inner=.095f;
    float x0=center.X+(float)Math.Cos(a)*inner,y0=center.Y+(float)Math.Sin(a)*inner;
    float x1=center.X+(float)Math.Cos(a)*radius,y1=center.Y+(float)Math.Sin(a)*radius;
    float x2=center.X+(float)Math.Cos(b)*radius,y2=center.Y+(float)Math.Sin(b)*radius;
    float x3=center.X+(float)Math.Cos(b)*inner,y3=center.Y+(float)Math.Sin(b)*inner;
    color(.42f,.53f,.61f,1);vertex(x0,y0,.075f);vertex(x1,y1,.077f);vertex(x2,y2,.077f);
    vertex(x0,y0,.075f);vertex(x2,y2,.077f);vertex(x3,y3,.075f);SubmittedVertices+=6;
   }rotorIndex++;
  }end();EscortDroneDraws305++;DrawCalls++;
  shipMaterial(0x0408,0x1600,none);disable(0x0B50);disable(0x0B57);disable(0x0BA1);disable(0x4000);disable(0x4001);
 }
 void DroneSphere305(Game game){if(!game.GuardianOwned||!game.GuardianEnabled298||game.Mode!=Mode.Playing)return;
  V point=game.GuardianPosition298; if(!VisibleSurface73(point,11*Scale67))return;
  V velocity=game.GuardianVelocity298;
  float heading=velocity.Length>6?(float)Math.Atan2(velocity.Y,velocity.X):game.Angle;
  planetPush();try{
   StampSphere67(point,heading,Game.ShipContactRadius*Scale67*.30f,1.25f);
   shipRotate(game.GuardianVisualBank298*1.6f,0,1,0);
   shipRotate(game.GuardianVisualPitch298*1.5f,1,0,0);
   DrawEscortDroneMesh305(game.Time);
  }finally{planetPop();}
 }
 public void DroneScreen305(float x,float y,float scale,V velocity,float pitch,float bank,float time){
  Flush2D();enable(DEPTH);depthMask(1);clear(0x0100);
  matrixMode(0x1701);loadIdentity();ortho(0,1280,720,0,-2000,2000);
  matrixMode(0x1700);loadIdentity();
  float yaw=velocity.Length>5?(float)Math.Atan2(velocity.Y,velocity.X)*180/Game.PI-90:0;
  shipTranslate(x,y,0);shipRotate(yaw,0,0,1);shipRotate(18+pitch*1.5f,1,0,0);
  shipRotate(bank*1.6f,0,1,0);shipScale(scale,-scale,scale);
  DrawEscortDroneMesh305(time);Begin2D();
 }
 void DisposeDrone305(){if(escortDroneBuffer305!=0){deleteBuffers(1,ref escortDroneBuffer305);escortDroneBuffer305=0;}}

 }
}
