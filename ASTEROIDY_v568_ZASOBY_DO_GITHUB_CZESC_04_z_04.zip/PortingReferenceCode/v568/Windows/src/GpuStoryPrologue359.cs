using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {sealed partial class GpuRenderer {
 // v362: a SINGLE battered rocky body. Previous v361 five smooth spheres have been removed.
 float[] storyOreMesh359; Bitmap storyRockTexture362;
 static readonly IP[] storyCraters362={
   new IP(.31f,.47f,.82f),new IP(-.64f,.13f,.72f),new IP(.74f,-.36f,.42f),
   new IP(.09f,-.83f,.56f),new IP(-.52f,.77f,-.27f),new IP(.67f,.58f,-.44f),
   new IP(-.31f,-.2f,-.93f),new IP(-.95f,-.23f,.15f),new IP(.07f,.94f,.33f)
 };
 static float StoryRough362(IP d){
  // Multi-scale tectonic faults rather than the old smoothed pebble noise.
  float low=.19f*(float)Math.Sin(2.9f*d.X+1.7f*d.Y-2.5f*d.Z)
           +.15f*(float)Math.Cos(4.2f*d.Z-2.8f*d.X+1.3f*d.Y);
  float ridge=.065f*(float)Math.Abs(Math.Sin(7.5f*d.X+4.3f*d.Y-6.2f*d.Z))
             -.03f*(float)Math.Abs(Math.Cos(5.1f*d.Y-4.8f*d.Z));
  float sharp=.025f*(float)Math.Sin(12f*d.X-9f*d.Y+8f*d.Z)
             +.012f*(float)Math.Cos(18f*d.Z+11f*d.X-12f*d.Y)
             +.004f*(float)Math.Sin(23f*d.X+18f*d.Y+17f*d.Z);
  float r=1f+low+ridge+sharp;
  for(int i=0;i<storyCraters362.Length;i++){
   IP c=storyCraters362[i].Unit;
   float dot=Math.Max(-1f,Math.Min(1f,IntroScene41.Dot(d,c)));
   float a=(float)Math.Acos(dot);
   float w=.29f+(i%4)*.042f;
   // Impact basin, steep inner wall and a prominent fracture/ejecta rim.
   float inside=Math.Max(0f,1f-a/w);
   float rim=(float)Math.Exp(-Math.Pow((a-w)/.060f,2));
   r-=.19f*inside*inside*(3f-2f*inside);
   r+=.075f*rim;
  }
  return Math.Max(.75f,Math.Min(1.44f,r));
 }
 static IP StoryRockPoint362(IP direction){
  IP d=direction.Unit;
  float r=4.85f*StoryRough362(d);
  // Major-axis asymmetry: broken carbonaceous-metallic shard, not an ellipsoid.
  return new IP(d.X*r*1.20f,d.Y*r*.83f,d.Z*r*1.04f);
 }
 static float StoryOreFactor362(IP d){
  IP vein=new IP(-.28f,.17f,.94f).Unit;
  float dot=IntroScene41.Dot(d,vein);
  float extent=Math.Max(0,Math.Min(1,(dot-.69f)/.22f));
  float zig=(float)Math.Sin(d.X*21f+d.Y*14f+2.1f*(float)Math.Sin(d.Z*22f));
  float seam=1f-Math.Min(1f,Math.Abs(zig)/.22f);
  return extent*seam;
 }
 static IP StoryRockNormal362(IP d){
  // Derivative normals remove saw-tooth shading while retaining true craters.
  IP axis=Math.Abs(d.Y)<.90f?new IP(0,1,0):new IP(1,0,0);
  IP a=IntroScene41.Cross(d,axis).Unit,b=IntroScene41.Cross(d,a).Unit;
  float eps=.008f;
  IP x=StoryRockPoint362((d+a*eps).Unit)-StoryRockPoint362((d-a*eps).Unit);
  IP y=StoryRockPoint362((d+b*eps).Unit)-StoryRockPoint362((d-b*eps).Unit);
  IP n=IntroScene41.Cross(x,y).Unit;
  return IntroScene41.Dot(n,d)<0?n*-1f:n;
 }
 static void StoryUV362(IP d,out float u,out float v){
  u=((float)Math.Atan2(d.Z,d.X)+(float)Math.PI)/((float)Math.PI*2f);
  v=(float)Math.Acos(Math.Max(-1f,Math.Min(1f,d.Y)))/(float)Math.PI;
 }
 void StoryRockFace362(List<float> data,IP a,IP b,IP c){
  IP pa=StoryRockPoint362(a),pb=StoryRockPoint362(b),pc=StoryRockPoint362(c);
  IP center=(a+b+c).Unit;
  IP n=IntroScene41.Cross(pb-pa,pc-pa).Unit;
  if(IntroScene41.Dot(n,center)<0){IP ptemp=pb;pb=pc;pc=ptemp;IP dtemp=b;b=c;c=dtemp;n=n*-1f;}
  IP[] points={pa,pb,pc},directions={a,b,c};
  float[] u=new float[3],v=new float[3];
  for(int j=0;j<3;j++)StoryUV362(directions[j],out u[j],out v[j]);
  float umin=Math.Min(u[0],Math.Min(u[1],u[2])),umax=Math.Max(u[0],Math.Max(u[1],u[2]));
  if(umax-umin>.5f)for(int j=0;j<3;j++)if(u[j]<.5f)u[j]+=1f;
  for(int j=0;j<3;j++){
   IP vpos=points[j],smooth=StoryRockNormal362(directions[j]);
   IP normal=(smooth*.78f+n*.22f).Unit;
   float ore=StoryOreFactor362(directions[j]);
   data.Add(vpos.X);data.Add(vpos.Y);data.Add(vpos.Z);
   data.Add(normal.X);data.Add(normal.Y);data.Add(normal.Z);
   data.Add(1f);data.Add(1f-.23f*ore);data.Add(1f-.68f*ore);data.Add(1f);
   data.Add(u[j]);data.Add(v[j]);
  }
 }
 void StoryRockSubdivide362(List<float> data,IP a,IP b,IP c,int depth){
  if(depth==0){StoryRockFace362(data,a,b,c);return;}
  IP ab=(a+b).Unit,bc=(b+c).Unit,ca=(c+a).Unit;
  StoryRockSubdivide362(data,a,ab,ca,depth-1);StoryRockSubdivide362(data,ab,b,bc,depth-1);
  StoryRockSubdivide362(data,ca,bc,c,depth-1);StoryRockSubdivide362(data,ab,bc,ca,depth-1);
 }
 void LoadStoryRockTexture362(){
  if(storyRockTexture362!=null)return;
  using(Stream imageStream=Assembly.GetExecutingAssembly().GetManifestResourceStream("Asteroidy.StoryRock362")){
   if(imageStream==null)throw new InvalidOperationException("Missing embedded ore asteroid texture");
   using(Bitmap texture=new Bitmap(imageStream))storyRockTexture362=new Bitmap(texture);
  }
 }
 void PrepareStoryOre359(){
  if(storyOreMesh359!=null)return;
  List<float> data=new List<float>(20*256*3*12);
  for(int f=0;f<introFaces.Length;f+=3)
   StoryRockSubdivide362(data,introIco[introFaces[f]].Unit,introIco[introFaces[f+1]].Unit,introIco[introFaces[f+2]].Unit,4);
  storyOreMesh359=data.ToArray();
 }
 void StoryOre359(IP pos,float time){
  PrepareStoryOre359();LoadStoryRockTexture362();
  planetPush();shipTranslate(pos.X,pos.Y,pos.Z);
  // Triplanar-like continuous equirectangular geological albedo, covering 360°.
  enable(0x0B50);enable(TEX);disable(BLEND);bindTexture(TEX,Texture(storyRockTexture362));
  texParameter(TEX,0x2802,0x2901); // repeat U across the longitude seam
  begin(4);
  for(int n=0;n<storyOreMesh359.Length;n+=12){
   wreckNormalImm223(storyOreMesh359[n+3],storyOreMesh359[n+4],storyOreMesh359[n+5]);
   color(storyOreMesh359[n+6],storyOreMesh359[n+7],storyOreMesh359[n+8],1);
   texCoord(storyOreMesh359[n+10],storyOreMesh359[n+11]);
   vertex(storyOreMesh359[n],storyOreMesh359[n+1],storyOreMesh359[n+2]);
  }
  end();DrawCalls++;SubmittedVertices+=storyOreMesh359.Length/12;
  disable(TEX);planetPop();
 }
 void StoryBeam359(IP start,IP target,float time,bool alarm){
  disable(0x0B50);disable(TEX);enable(BLEND);blendFunc(0x0302,1);depthMask(0);
  float flicker=.72f+.28f*(float)Math.Sin(time*17f);
  begin(1);
  if(alarm)color(1f,.08f,.05f,.6f*flicker);else color(.98f,.57f,.12f,.72f*flicker);
  vertex(start.X,start.Y,start.Z);
  if(alarm)color(1f,.36f,.14f,.8f);else color(1f,.91f,.35f,.9f);
  vertex(target.X,target.Y,target.Z);
  end();DrawCalls++;SubmittedVertices+=2;
  depthMask(1);disable(BLEND);
 }
 void StoryAnomaly359(IP center,float t){
  float power=Math.Max(0,Math.Min(1,(t-28f)/10.0f));if(power<=0)return;
  float pulse=(.65f+.35f*(float)Math.Sin(t*4.9f))*power;
  disable(0x0B50);disable(TEX);enable(BLEND);blendFunc(0x0302,1);
  float size=.7f+2.8f*power;
  begin(4);
  for(int f=0;f<6;f++){
   float a=f*(float)Math.PI/3,b=(f+1)*(float)Math.PI/3;
   color(.9f,.04f,.025f,.54f*pulse);vertex(center.X,center.Y+size*1.9f,center.Z);
   color(.85f,.07f,.045f,.64f*pulse);vertex(center.X+(float)Math.Cos(a)*size,center.Y,center.Z+(float)Math.Sin(a)*size);
   color(.3f,.01f,.025f,.48f*pulse);vertex(center.X+(float)Math.Cos(b)*size,center.Y,center.Z+(float)Math.Sin(b)*size);
  }
  end();DrawCalls++;SubmittedVertices+=18;
  disable(BLEND);
 }
 readonly float[] storyCraft359=new float[16];
 void StoryCraftOrientation359(IP from,IP to){
  IP forward=(to-from).Unit,up=new IP(0,1,0);
  if(Math.Abs(IntroScene41.Dot(forward,up))>.95f)up=new IP(1,0,0);
  IP right=IntroScene41.Cross(forward,up).Unit;up=IntroScene41.Cross(right,forward).Unit;
  storyCraft359[0]=right.X;storyCraft359[1]=right.Y;storyCraft359[2]=right.Z;storyCraft359[3]=0;
  storyCraft359[4]=forward.X;storyCraft359[5]=forward.Y;storyCraft359[6]=forward.Z;storyCraft359[7]=0;
  storyCraft359[8]=up.X;storyCraft359[9]=up.Y;storyCraft359[10]=up.Z;storyCraft359[11]=0;
  storyCraft359[12]=storyCraft359[13]=storyCraft359[14]=0;storyCraft359[15]=1;
 }
 void StoryShip359(IP pos,IP aim,float bank,float time,float power,float scale){
  StoryCraftOrientation359(pos,aim);
  planetPush();shipTranslate(pos.X,pos.Y,pos.Z);planetMultiply(storyCraft359);if(bank!=0)shipRotate(bank,0,1,0);
  float sceneScale367=scale*(CraftType==1?.45f:1f);if(Math.Abs(sceneScale367-1f)>.001f)shipScale(sceneScale367,sceneScale367,sceneScale367);DrawFighterMesh(time,power,0,false);planetPop();
 }
 IP StoryLoop359(IP center,float radius,float lift,float speed,float time,float phase){
  float a=time*speed+phase;
  return center+new IP((float)Math.Cos(a)*radius,lift+(float)Math.Sin(a*1.7f)*1.1f,(float)Math.Sin(a)*radius*.7f);
 }
 public void CinematicStoryPrologue359(Game g,bool glow,bool nebula,bool rays){
  float t=g.StoryTime359;
  PrepareIntroBelt();EnsureIntroPlanet(1);CraftType=g.ShipType;deepSpaceTime55=t*.22f;
  IP asteroid=IntroScene41.PlanetCenter+OrbitWorld50.Belt51[0].Center+new IP(0,2,0);

  IP viewAt,eye;
  if(t<18f){
   float q=t/18f;
   viewAt=asteroid+new IP(-1.3f,.3f+(float)Math.Sin(t*.28f)*.25f,0);
   eye=asteroid+new IP(24f-8f*q,8f+(float)Math.Sin(t*.20f)*2.2f,28f-7f*q);
  }else if(t<36f){
   float q=(t-18f)/18f;
   viewAt=asteroid+new IP(1.5f,.5f,.6f);
   eye=asteroid+new IP(20f+(float)Math.Sin(t*.18f)*1.1f,6.2f+q*.8f,23f-5f*q);
  }else if(t<50f){
   float q=(t-36f)/14f;
   viewAt=asteroid+new IP(0,.6f,0);
   eye=asteroid+new IP(17f+q*1.5f,7.4f+q*.7f,18f-2f*q);
  }else{
   float q=(t-50f)/12f;
   IP launchTarget=asteroid+new IP(18f,4f,-8f);
   viewAt=launchTarget+new IP(4f*q,1.5f*q,-5f*q);
   eye=launchTarget+new IP(-12f+14f*q,5.5f+2f*q,10f-8f*q);
  }
  IntroScene41.View(eye,viewAt,introView);
  Flush2D();clearColor(.008f,.013f,.025f,1);depthMask(1);clear(0x4000|0x0100);
  IntroSky(glow,nebula,rays);IntroProjection();enable(DEPTH);depthMask(1);
  disable(BLEND);disable(TEX);disable(0x0B44);FighterLight(false);
  shipMaterial(0x0408,0x1600,none);shipMaterial(0x0408,0x1202,softSpec);
  planetPush();shipTranslate(IntroScene41.PlanetCenter.X,IntroScene41.PlanetCenter.Y,IntroScene41.PlanetCenter.Z);DrawIntroBelt();planetPop();
  planetPush();shipTranslate(IntroScene41.PlanetCenter.X,IntroScene41.PlanetCenter.Y,IntroScene41.PlanetCenter.Z);
  float prologuePlanetScale523=MissionPlanetScale523(24f);shipScale(prologuePlanetScale523,prologuePlanetScale523,prologuePlanetScale523);shipRotate(PlanetRotation(1,t,true),0,1,0);weatherTime65=t;
  DrawPlanetSolid();DrawPlanetLava116();planetPop();
  StoryOre359(asteroid,t);

  // Main miner: broadside and clearly horizontal while working the beam.
  IP miner=asteroid+new IP(-10.8f-(t>46?(t-46)*.32f:0),2.1f+(float)Math.Sin(t*.33f)*.2f,4.3f);
  StoryShip359(miner,asteroid+new IP(-1.4f,.8f,2.0f),-6f,t,.55f,.98f);

  // Dedicated escort near the rock.
  IP escort=asteroid+new IP(11.5f+(t>46?(t-46)*.18f:0),1.3f,4.6f);
  StoryShip359(escort,asteroid+new IP(1.1f,.5f,.2f),5f,t,.48f,.84f);

  // Background traffic around the mining site.
  IP c1=StoryLoop359(asteroid+new IP(0,5,0),18f,2.2f,.24f,t,.3f);
  IP c2=StoryLoop359(asteroid+new IP(0,6.5f,0),24f,-1.2f,-.17f,t,2.2f);
  IP c3=StoryLoop359(asteroid+new IP(0,3f,0),28f,1.4f,.13f,t,4.1f);
  IP c4=StoryLoop359(asteroid+new IP(0,8f,0),34f,-2.0f,-.10f,t,5.7f);
  StoryShip359(c1,c1+new IP(-5f,-.4f,-2f),3f,t,.28f,.62f);
  StoryShip359(c2,c2+new IP(6f,.2f,-2f),-3f,t,.24f,.58f);
  StoryShip359(c3,c3+new IP(4f,-.1f,3f),2f,t,.23f,.54f);
  StoryShip359(c4,c4+new IP(-4f,.3f,4f),-2f,t,.20f,.50f);

  if(t<34f){StoryBeam359(miner+new IP(1.3f,-.15f,-1.4f),asteroid+StoryRockPoint362(new IP(-.28f,.17f,.94f)) * 1.022f,t,false);}
  if(t>28f&&t<46f){StoryBeam359(asteroid+new IP(.4f,1.1f,-.1f),escort+new IP(-.8f,.1f,-.4f),t,true);}
  StoryAnomaly359(asteroid,t);

  // Critical: planet and ship renderers can leave GL_CULL_FACE enabled.
  disable(0x0B44);disable(0x0B50);disable(0x0B57);disable(0x0BA1);disable(0x4000);disable(0x4001);
  shipMaterial(0x0408,0x1600,none);Begin2D();
 }
}}