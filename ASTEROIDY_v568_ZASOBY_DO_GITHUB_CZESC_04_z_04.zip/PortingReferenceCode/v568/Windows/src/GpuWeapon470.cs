using System;
using System.Runtime.InteropServices;
namespace Asteroidy {
 sealed partial class GpuRenderer {
  public int WeaponPreviewMode470;
  public int HangarViewMode471;
  public WeaponViewSettings470 WeaponConfig470;
  public WeaponMaterial477 WeaponMaterialConfig477;
  const float WeaponBaseScale470=.52f;
  static void WeaponWalkOffsets470(float phase,float movement,float visualIntensity,out float x,out float y,out float yaw){
   float strength=Math.Max(0f,Math.Min(1.4f,movement))*Math.Max(0f,Math.Min(1f,visualIntensity));
   x=(float)Math.Sin(phase)*.023f*strength;
   y=(float)Math.Sin(phase*2f)*.0125f*strength;
   yaw=(float)Math.Sin(phase)*1.9f*strength;
  }
  void DrawWeaponMesh470(int kind){
   kind=Math.Max(0,Math.Min(4,kind));
   float[] mesh=gunVertices101[kind];
   GCHandle pin=new GCHandle();IntPtr ptr=IntPtr.Zero;
   try{
    bool vbo=genBuffers!=null&&bindBuffer!=null&&bufferData!=null;
    if(vbo){
      if(gunBuffers101[kind]==0){
       genBuffers(1,out gunBuffers101[kind]);
       pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);
       bindBuffer(0x8892,gunBuffers101[kind]);
       bufferData(0x8892,new IntPtr(mesh.Length*4),pin.AddrOfPinnedObject(),0x88E4);
      }else bindBuffer(0x8892,gunBuffers101[kind]);
    }else{pin=GCHandle.Alloc(mesh,GCHandleType.Pinned);ptr=pin.AddrOfPinnedObject();}
    disable(TEX);disable(0x0B50);disable(0x0B44);
    enableClient(0x8074);enableClient(0x8076);
    vertexPointer(3,0x1406,28,ptr);
    colorPointer(4,0x1406,28,new IntPtr(ptr.ToInt64()+12));
    drawArrays(4,0,mesh.Length/7);DrawCalls++;SubmittedVertices+=mesh.Length/7;
    disableClient(0x8074);disableClient(0x8076);
    if(vbo)bindBuffer(0x8892,0);
   }finally{if(pin.IsAllocated)pin.Free();}
  }
  void ApplyWeaponPose470(WeaponViewSettings470 setting,float sway,float lift,float idle,float yaw,float roll){
   float scale=WeaponBaseScale470*Math.Max(.25f,Math.Min(2.5f,setting.Pose[6]*.01f));
   shipTranslate(setting.Pose[0]*.01f+sway,setting.Pose[1]*.01f+lift+idle,setting.Pose[2]*.01f);
   shipRotate(-90,1,0,0);
   shipRotate(90,0,0,1); // v474 GLB EXP-01 barrel axis X -> view forward -Z
   shipRotate(setting.Pose[3],1,0,0);
   shipRotate(setting.Pose[4]+yaw,0,1,0);
   shipRotate(setting.Pose[5]+roll,0,0,1);
   shipScale(scale,scale,scale);
  }
  public void RenderWeapon470(Game game,WeaponViewSettings470 setting){
   if(setting==null||!setting.Enabled||!game.HubWalk375||game.HubArriving92)return;
   Flush2D();
   enable(DEPTH);depthMask(1);clear(0x0100);disable(BLEND);disable(0x0B50);disable(0x0BA1);disable(0x0B57);
   matrixMode(0x1701);loadIdentity();
   const float near=.06f;float half=near*(float)Math.Tan(GloveFov422*Math.PI/360.0);
   frustum(-half*1.7777778,half*1.7777778,-half,half,near,20);
   matrixMode(0x1700);loadIdentity();
   float walking=setting.Bob?game.HubWalkBobAmount400:0f;
   float intensity=HangarBob400*.01f;
   float sway,lift,yaw;WeaponWalkOffsets470(game.HubWalkBobPhase400,walking,intensity,out sway,out lift,out yaw);
   float idle=setting.Idle?(float)Math.Sin(game.HubTime90*.82f)*0.004f:0f;
   planetPush();
   ApplyWeaponPose470(setting,sway,lift,idle,yaw,0f);
   DrawImportedWeapon474();
   planetPop();
   disable(DEPTH);depthMask(1);Begin2D();
  }
  public void RenderWeaponPreview470(WeaponViewSettings470 setting){
   if(setting==null||!setting.Enabled)return;
   Flush2D();
   int vx=viewX,vy=outputH-viewY-viewH,vw=viewW,vh=viewH;
   int px=vx+(int)(GlovePreviewX422*vw/1280f);
   int py=vy+(int)((720f-GlovePreviewY422-GlovePreviewH422)*vh/720f);
   int pw=Math.Max(1,(int)(GlovePreviewW422*vw/1280f));
   int ph=Math.Max(1,(int)(GlovePreviewH422*vh/720f));
   try{
    viewport(px,py,pw,ph);
    enable(DEPTH);depthMask(1);clear(0x0100);disable(BLEND);disable(0x0B50);disable(0x0BA1);disable(0x0B57);
    matrixMode(0x1701);loadIdentity();
    const float near=.06f;float half=near*(float)Math.Tan(GloveFov422*Math.PI/360.0);
    frustum(-half*GlovePreviewW422/GlovePreviewH422,half*GlovePreviewW422/GlovePreviewH422,-half,half,near,20);
    matrixMode(0x1700);loadIdentity();
    double t=Environment.TickCount/1000.0;
    float sway=0,lift=0,yaw=0,roll=0,idle=0;
    if(WeaponPreviewMode470==1||WeaponPreviewMode470==2||WeaponPreviewMode470==3)idle=setting.Idle?(float)Math.Sin(t*.82)*0.004f:0f;
    if(WeaponPreviewMode470==2||WeaponPreviewMode470==3){float move=WeaponPreviewMode470==2?.55f:1f;WeaponWalkOffsets470((float)t*5f,move,1f,out sway,out lift,out yaw);} 
    if(WeaponPreviewMode470==4){yaw=(float)Math.Sin(t*1.2)*8f;roll=(float)Math.Sin(t*1.4)*6f;idle=setting.Idle?(float)Math.Sin(t*.82)*0.003f:0f;}
    planetPush();
    ApplyWeaponPose470(setting,sway,lift,idle,yaw,roll);
    // Settings preview keeps soft neutral light; the live hangar uses real GLB lamps.
    currentWeaponLightPos482=new float[]{-1,2,-.6f,2,1,-1,0,3,-3,0,0,0};
    currentWeaponLightRgb482=new float[]{.8f,.8f,.8f,.5f,.5f,.6f,.2f,.2f,.25f,0,0,0};
    DrawImportedWeapon474();
    planetPop();
   }finally{depthMask(1);disable(DEPTH);viewport(vx,vy,vw,vh);Begin2D();}
  }
 }
}
