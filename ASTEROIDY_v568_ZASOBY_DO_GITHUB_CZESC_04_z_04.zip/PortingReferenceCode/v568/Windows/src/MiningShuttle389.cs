using System;
using IP=Asteroidy.IntroScene41.P;
namespace Asteroidy {
 public partial class Game {
  // A separate piloted shuttle and stationary carrier. No ore rewards are invented here:
  // mining gameplay is a later feature. Always starts attached after loading a profile.
  public bool MiningDetached389;
  public V MiningCarrierPos389;
  internal IP MiningCarrierOrbit389,MiningCarrierForward389,MiningCarrierRight389;
  public float MiningCarrierHeading389;
  public int ActiveCraft389 { get { return ShipType==TransportShipType388&&MiningDetached389?6:ShipType; } }
  public bool ToggleMiningShuttle389() {
   if(ShipType!=TransportShipType388||SceneBusy||(Mode!=Mode.Playing&&Mode!=Mode.Orbit))return false;
   if(!MiningDetached389){
    MiningCarrierPos389=Ship;MiningCarrierHeading389=Angle;
    MiningCarrierOrbit389=OrbitPosition50;MiningCarrierForward389=OrbitForward50;MiningCarrierRight389=OrbitRight51;
    MiningDetached389=true;
    if(Mode==Mode.Orbit){OrbitPosition50=NewHome290.SafePosition(OrbitPosition50+OrbitRight51*5);OrbitCamera50=OrbitPosition50-OrbitForward50*16+OrbitPosition50.Unit*9;}
    else Ship=WorldOffset67(Ship,Direction(Angle)*18);
    Notice="PROM WIERTNICZY ODŁĄCZONY · WRÓĆ BLISKO TRANSPORTOWCA, ABY ZADOKOWAĆ";
   }else{
    float distance=Mode==Mode.Orbit?(OrbitPosition50-MiningCarrierOrbit389).Length:WorldDelta67(Ship,MiningCarrierPos389).Length;
    float limit=Mode==Mode.Orbit?26f:45f;
    if(distance>limit){Notice="PROM ZA DALEKO OD DOKU: "+Math.Ceiling(distance-limit)+" m";NoticeTime=3;UiRevision++;return false;}
    MiningDetached389=false;
    if(Mode==Mode.Orbit){OrbitPosition50=MiningCarrierOrbit389;OrbitVelocity51=new IP();OrbitSpeed50=0;OrbitCamera50=OrbitPosition50-OrbitForward50*16+OrbitPosition50.Unit*9;}
    else {Ship=MiningCarrierPos389;Velocity=new V();}
    Notice="PROM ZADOKOWANY · TRANSPORTOWIEC GOTOWY DO LOTU";
   }
   NoticeTime=4;UiRevision++;return true;
  }
 }
}
