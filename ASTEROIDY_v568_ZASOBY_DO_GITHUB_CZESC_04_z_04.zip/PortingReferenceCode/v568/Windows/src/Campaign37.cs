using System;
namespace Asteroidy {
 public partial class Game {
  public const int ShopItems=10,ShopContinue=10,ShopNextMission261=11,CustomShipType368=3,CustomShipPrice368=240,CustomShipMission368=13,HeavyShipType387=4,HeavyShipPrice387=420,TransportShipType388=5,TransportShipPrice388=620;public bool HangarOpen;public int ShipType=1,EngineLevel,CollectorLevel,StabilizerLevel,GuardianCharges;public bool GuardianOwned,VanguardXOwned368,HeavyShipOwned387,TransportShipOwned388;
  public static readonly string[] ShipNames={"KESTREL","VANGUARD","BASTION","VANGUARD X","TITAN H-01","MAMMOTH T-06"};
  public bool ShipOwned368(int ship){return ship>=0&&ship<3||ship==CustomShipType368&&VanguardXOwned368||ship==HeavyShipType387&&HeavyShipOwned387||ship==TransportShipType388&&TransportShipOwned388;}
  public bool CustomShipAvailable368{get{return Level>=CustomShipMission368;}}
  public string CustomShipLabel368{get{return ShipNames[CustomShipType368];}}
  public string CustomShipPriceLabel368{get{return VanguardXOwned368?"WYPOSAŻ":!CustomShipAvailable368?"OD MISJI "+CustomShipMission368:CustomShipPrice368+" Ż";}}
  public static readonly string[] ShipRoles={"Zwiadowca · szybki i lekki","Myśliwiec · równowaga","Ciężki · wytrzymały i wolniejszy","Prototyp · odblokowywany w hangarze","Ciężki szturmowiec · opancerzony i bezwładny","Transportowiec · prom górniczy"};
  public float Acceleration{get{return 245*(ShipType==0?1.18f:ShipType==2?.82f:ShipType==CustomShipType368?.79f:ShipType==HeavyShipType387?.67f:ShipType==TransportShipType388?(MiningDetached389?1.30f:.60f):1)*(1+EngineLevel*.06f)*(1+ThrusterRank97*.045f);}}
  public float TopSpeed{get{return 390*(ShipType==0?1.12f:ShipType==2?.86f:ShipType==CustomShipType368?.93f:ShipType==HeavyShipType387?.76f:ShipType==TransportShipType388?(MiningDetached389?1.16f:.70f):1)*(1+EngineLevel*.035f)*(1+ThrusterRank97*.025f);}}
  public float TurnSpeed{get{return 3.8f*(ShipType==0?1.12f:ShipType==2?.84f:ShipType==CustomShipType368?.55f:ShipType==HeavyShipType387?.42f:ShipType==TransportShipType388?(MiningDetached389?1.35f:.35f):1)*(1+StabilizerLevel*.04f);}}
  public float FireRateScale{get{return ShipType==0?1.08f:ShipType==2?.96f:1;}}
  public float ContactRadius{get{return ShipContactRadius*(ShipType==0?.94f:ShipType==2?1.08f:ShipType==CustomShipType368?1.12f:ShipType==HeavyShipType387?1.30f:ShipType==TransportShipType388?(MiningDetached389?.65f:1.46f):1);}}
  public int StartingLives{get{return Math.Min(5,(Difficulty==0?5:3)+(ShipType==0?-1:ShipType==2?1:0));}}
  public void OpenHangar(){if(SceneBusy){QueueMenuAction134(OpenHangar);return;}HangarOpen=true;Mode=Mode.Menu;UiRevision++;}
  public void HangarKey(int key){if(SceneBusy){if(key==13&&HangarOpen)QueueMenuAction134(BeginStoryPrologue359);return;}if(!HangarOpen)return;if(key==9){PlanetHub50=!PlanetHub50;UiRevision++;return;}if(key==37||key==38||key==65||key==87)ShipType=(ShipType+2)%3;else if(key==39||key==40||key==68||key==83)ShipType=(ShipType+1)%3;else if(key>=49&&key<=51)ShipType=key-49;else if(key==27)HangarOpen=false;else if(key==13)BeginStoryPrologue359();UiRevision++;}
  public void HangarClick(float x,float y){if(!HangarOpen)return;if(SceneBusy){if(y>=593&&y<=671&&x>=784&&x<=1194)QueueMenuAction134(BeginStoryPrologue359);return;}float[] left={84,420,756};if(y>=228&&y<=566)for(int i=0;i<3;i++)if(x>=left[i]&&x<=left[i]+278){ShipType=i;UiRevision++;return;}if(y>=593&&y<=671){if(x>=784&&x<=1194)BeginStoryPrologue359();else if(x>=470&&x<=754)HangarOpen=false;else if(x>=84&&x<=454){PlanetHub50=!PlanetHub50;UiRevision++;}}}
  public bool ModuleAvailable(int item){return item==6?EngineLevel<2:item==7?CollectorLevel<2:item==8?!GuardianOwned&&Level>=6:item==9?StabilizerLevel<2:false;}
  public int ModulePrice(int item){return item==6?75+EngineLevel*85:item==7?55+CollectorLevel*65:item==8?190:65+StabilizerLevel*70;}
  public string ModuleDetail(int item){return item==6?"Przyspieszenie +6% · prędkość +3,5% / stopień":item==7?"Zasięg kolektora +30 · szybsze zbieranie / stopień":item==8?(Level<6?"Od sektora 6 · dron bojowy / 1 przechwycenie na sektor":"Stały dron eskortowy · 1 przechwycenie / sektor · działko plazmowe"):"Obrót +4% · mocniejsze hamowanie / stopień";}
  public void BuyModule(int item){if(item==6)EngineLevel++;else if(item==7)CollectorLevel++;else if(item==8){GuardianOwned=true;GuardianCharges=1;}else if(item==9)StabilizerLevel++;}
  void ResetModules(){HangarOpen=false;EngineLevel=CollectorLevel=StabilizerLevel=GuardianCharges=0;GuardianOwned=false;}
  public bool TryGuardian(){if(GuardianCharges<=0)return false;GuardianCharges--;Invincible=1.2f;Light(Ship,1,.35f);Notice="DRON PRZECHWYCIŁ UDERZENIE";NoticeTime=2;UiRevision++;return true;}
 }
}
