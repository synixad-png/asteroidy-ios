using System;using System.Drawing;
namespace Asteroidy {
 sealed class PlanetBiome {
  public readonly int Kind;public readonly string Name;public readonly Color Land,Rock,Water,Shore,Plant,Accent,Glow;public readonly float Sea;
  PlanetBiome(int kind,string name,int land,int rock,int water,int plant,int accent,int glow,float sea){Kind=kind;Name=name;Land=C(land);Rock=C(rock);Water=C(water);Shore=C(kind==0?0x748264:kind==1?0x929E9F:kind==2?0x785045:kind==3?0x91BDA2:kind==4?0xB9DBE5:kind==5?0xC5A267:kind==6?0x866993:kind==8?0x717B80:0x537996);Plant=C(plant);Accent=C(accent);Glow=C(glow);Sea=sea;}
  static Color C(int rgb){return Color.FromArgb((rgb>>16)&255,(rgb>>8)&255,rgb&255);}
  // Geometry families: woodland, alpine, volcanic, archipelago, ice, desert, fungal, crystal.
  static readonly PlanetBiome[] catalog={
   new PlanetBiome(1,"TITAN / GÓRY I ŚNIEG",0x657878,0xAAB6BE,0x3B6885,0x597868,0xCEE8EB,0x91BCE8,.981f),
   new PlanetBiome(2,"IGNIS / WULKANY",0x41372F,0x65504A,0x572D29,0x7C564A,0xFF8D27,0xF5793D,.973f),
   new PlanetBiome(3,"AZURE / ARCHIPELAGI",0x448476,0x71A58A,0x219AAB,0xF09D77,0xE7D4A1,0x61E2EF,1.003f),
   new PlanetBiome(4,"BOREAS / LODOWCE",0xB2D8E5,0xD6ECED,0x518FAF,0x80B8D4,0xE9F6ED,0x95DBFF,.980f),
   new PlanetBiome(5,"SAHARA / WYDMY",0xB7925E,0x9B6348,0x668C80,0x858344,0xE7BB6B,0xE8AD72,.971f),
   new PlanetBiome(6,"MYCEL / LAS GRZYBÓW",0x665086,0x8266A1,0x406F83,0xD36EAC,0x63C7C0,0xCD83EC,.985f),
   new PlanetBiome(7,"PRISM / KRYSZTAŁY",0x354D6C,0x617897,0x235369,0x74B9E8,0xC488E5,0x8FAAFF,.978f),
   new PlanetBiome(0,"AMBER / JESIENNY LAS",0x81704A,0x958263,0x407D83,0xD79249,0xBA555A,0xEDBC67,.985f),
   new PlanetBiome(3,"MIRE / MOKRADŁA",0x465B3D,0x657947,0x4F7970,0x97B357,0xC3C570,0xB9C57A,1.004f),
   new PlanetBiome(1,"RUBRA / CZERWONE SKAŁY",0x8C514C,0xA57973,0x584D72,0xAC7977,0xE4C5A6,0xE5918C,.977f),
   new PlanetBiome(5,"SALINA / SOLNE PUSTKOWIA",0xCDD1C2,0x9FAEA5,0xB37997,0x9D83A4,0xDDD5CA,0xE3B4D6,.969f),
   new PlanetBiome(0,"NYX / BIOLUMINESCENCJA",0x294D64,0x4B657D,0x35538A,0x46A5B1,0xDA74C7,0x758CFF,.985f),
   new PlanetBiome(1,"OBSIDIAN / IGŁY GÓRSKIE",0x463C57,0x78647E,0x413A69,0x736C94,0xE3B6CF,0xAA79D6,.979f),
   new PlanetBiome(2,"INFERNO / MAGMA",0x372B3C,0x62415A,0x702E48,0xAD596E,0xFF5C6D,0xED598F,.973f),
   new PlanetBiome(3,"REEF / KORALOWY OCEAN",0x467A85,0x629998,0x316BC0,0xEF776A,0xCBAEE3,0x549DEA,1.003f),
   new PlanetBiome(4,"AURORA / FIOLETOWY LÓD",0xA9B2DC,0xDCD4F1,0x6869B5,0x7C91D6,0xEAACDA,0xBBA4FF,.980f),
   new PlanetBiome(5,"AUREUM / ZŁOTE KANIONY",0xB7A454,0x897442,0x536D85,0x8DA780,0xF1D97B,0xF5D168,.971f),
   new PlanetBiome(6,"SPORE / OGRODY ZARODNIKÓW",0x675340,0xA07C56,0x4F876E,0xE8A063,0x9AD692,0xEDB777,.985f),
   new PlanetBiome(7,"JADE / SZMARAGDOWE IGŁY",0x2C544C,0x51877A,0x55476F,0x72D3B2,0xC286BC,0x67E2AD,.978f),
   new PlanetBiome(0,"SCARLET / KARMINOWY LAS",0x634B58,0x9A7871,0x356A79,0xC76473,0xE0AB6B,0xE38B99,.985f),
   new PlanetBiome(4,"POLARIS / WIECZNY MRÓZ",0x709AA8,0xA7D4DA,0x2E657D,0x478D9B,0xB8E6D7,0x77CCDA,.982f),
   new PlanetBiome(6,"TOXIN / OBCY EKOSYSTEM",0x3E6554,0x7C956A,0x40735A,0xA5C664,0xC184D2,0xA2E289,.985f),
   new PlanetBiome(2,"SOL / ZŁOTA LAWA",0x454036,0x766648,0x4D4130,0xA28C59,0xFFE077,0xF0C659,.973f)
  };
  static readonly PlanetBiome carbonis=new PlanetBiome(11,"CARBONIS / PBR",0x5B3430,0x8A5653,0xB24F23,0x3F3333,0xDE632A,0xEC4E19,.99f);
  static readonly PlanetBiome vulkaris=new PlanetBiome(10,"VULKARIS / OBCY ŚWIAT",0x655848,0x908579,0x216DA0,0x559A85,0x69F5D5,0xC96A42,.985f);
  static readonly PlanetBiome amiga= new PlanetBiome(9,"AMIGA / BOING BALL",0xF4F0EB,0xD43A39,0x000000,0x1B1B1B,0xC43131,0x94CDE7,1.002f);
  public static PlanetBiome ForLevel(int level){if(level<1||level>Game.AtlasMissionCount276)throw new ArgumentOutOfRangeException("level");if(level==Carbonis277.Level)return carbonis;if(level==25)return amiga;if(level==26)return vulkaris;return catalog[level-2];}
 }
}
