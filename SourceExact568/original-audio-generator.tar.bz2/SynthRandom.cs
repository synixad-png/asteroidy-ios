// PCG XSL RR 128/64 and NumPy-compatible normal distribution.
// PCG: Copyright 2014 Melissa O'Neill, MIT. NumPy tables: BSD-3-Clause.
using System;using System.IO;using System.Reflection;
namespace Asteroidy {
sealed class SynthRandom {
 ulong hi,lo,ih,il;static readonly double[] fi=new double[256],wi=new double[256];static readonly ulong[] ki=new ulong[256];
 static readonly ulong[,] states={{17720626838516207804UL,17604308112068095111UL,13442669393644191452UL,16392051441657752093UL},{1516675780555050764UL,11817444579787549802UL,4171121331024154263UL,4370545984452587435UL},{7317589267772807375UL,8817657662573731448UL,807272480506421524UL,6163486463551129069UL},{14307938573285740446UL,9056080682619171725UL,9201328663824832966UL,14206366224349684113UL},{7364247954233186185UL,9407711808168926477UL,2271866509686706354UL,17793606685775104749UL}};
 static SynthRandom(){using(BinaryReader r=new BinaryReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("Synth.Zig"))){for(int i=0;i<256;i++)fi[i]=r.ReadDouble();for(int i=0;i<256;i++)wi[i]=r.ReadDouble();for(int i=0;i<256;i++)ki[i]=r.ReadUInt64();}}
 public SynthRandom(int track){int seed=track%5;hi=states[seed,0];lo=states[seed,1];ih=states[seed,2];il=states[seed,3];if(track>=5)for(int i=0;i<track*113;i++)Next();}
 static ulong MulHigh(ulong a,ulong b){ulong al=(uint)a,ah=a>>32,bl=(uint)b,bh=b>>32;ulong t=al*bl;ulong t2=ah*bl+(t>>32);ulong low=(uint)t2;ulong high=t2>>32;ulong t3=al*bh+low;return ah*bh+high+(t3>>32);}
 ulong Next(){unchecked{const ulong ml=4865540595714422341UL,mh=2549297995355413924UL;ulong nh=MulHigh(lo,ml)+hi*ml+lo*mh;ulong nl=lo*ml;ulong sum=nl+il;hi=nh+ih+(sum<nl?1UL:0UL);lo=sum;ulong x=hi^lo;int rot=(int)(hi>>58);return (x>>rot)|(x<<((-rot)&63));}}
 public double Uniform(){return (Next()>>11)*(1.0/9007199254740992.0);}
 public double Normal(){for(;;){ulong r=Next();int idx=(int)(r&255);r>>=8;ulong abs=(r>>1)&0x000fffffffffffffUL;double x=abs*wi[idx];if((r&1)!=0)x=-x;if(abs<ki[idx])return x;if(idx==0){for(;;){double xx=-Math.Log(1-Uniform())/3.6541528853610088,yy=-Math.Log(1-Uniform());if(yy+yy>xx*xx)return ((abs>>8)&1)!=0?-(3.6541528853610088+xx):3.6541528853610088+xx;}}else if((fi[idx-1]-fi[idx])*Uniform()+fi[idx]<Math.Exp(-.5*x*x))return x;}}
}}
