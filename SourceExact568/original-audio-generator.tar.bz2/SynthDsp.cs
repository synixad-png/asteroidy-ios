using System;using System.Collections.Generic;
namespace Asteroidy {
static class SynthDsp {
 public const int Rate=44100;public const double Tau=6.283185307179586;
 public static float[] Filter(double[] x,string key){double[] sos=SynthCoefficients.Filters[key];float[] result=new float[x.Length];double[] z=new double[sos.Length/3];for(int i=0;i<x.Length;i++){double v=x[i];for(int j=0;j<sos.Length;j+=6){int q=j/3;double y=sos[j]*v+z[q];z[q]=sos[j+1]*v-sos[j+4]*y+z[q+1];z[q+1]=sos[j+2]*v-sos[j+5]*y;v=y;}result[i]=(float)v;}return result;}
 public static float[] Filter(float[] x,string key){double[] sos=SynthCoefficients.Filters[key];float[] result=new float[x.Length];double[] z=new double[sos.Length/3];for(int i=0;i<x.Length;i++){double v=x[i];for(int j=0;j<sos.Length;j+=6){int q=j/3;double y=sos[j]*v+z[q];z[q]=sos[j+1]*v-sos[j+4]*y+z[q+1];z[q+1]=sos[j+2]*v-sos[j+5]*y;v=y;}result[i]=(float)v;}return result;}
 public static double Frequency(int n){return 440*Math.Pow(2,(n-69)/12.0);}
 public static double Sidechain(int frame,double beat){double phase=(frame/(double)Rate)%beat,down=Math.Min(1,(beat-phase)/.004);down=down*down*(3-2*down);return .35+.65*(1-Math.Exp(-phase/.048))*down;}
 public static float[] NoiseSwell(SynthRandom rng,int count){float[] noise=new float[count];for(int i=0;i<count;i++)noise[i]=(float)(rng.Normal()*.1);float[] swell=Filter(noise,"highpass:1800");for(int i=0;i<count;i++){double end=Math.Min(1,(count-1-i)/(Rate*.012));end=end*end*(3-2*end);swell[i]=(float)(swell[i]*Math.Pow(i/(double)(count-1),2)*end);}return swell;}
 public static float Envelope(int i,int n,double attack,double decay){double e=Math.Min(1,i/(Rate*Math.Max(.0001,attack)))*Math.Exp(-i/(Rate*Math.Max(.01,decay)));int edge=Math.Min(n,220);if(i>=n-edge)e*=(n-1-i)/(double)(edge-1);return (float)e;}
 public static float[] Kick(){int n=(int)(.34*Rate);double[] x=new double[n];double phase=0;for(int i=0;i<n;i++){double t=i/(double)Rate;phase+=Tau*(46+150*Math.Exp(-t/.018)+35*Math.Exp(-t/.075))/Rate;double body=Math.Sin(phase)*Envelope(i,n,.0012,.11);x[i]=Math.Tanh(body*1.55)/1.2+Math.Sin(Tau*3500*t)*Math.Exp(-t/.0019)*.12;}return Filter(x,"lowpass:9000");}
 public static float[] Bass(int note,double seconds){int n=(int)(seconds*Rate);float[] harmonic=new float[n];double f=Frequency(note);for(int h=1;h<=30;h++){double angle=Tau*f*h/Rate,c=Math.Cos(angle),s=Math.Sin(angle),re=Math.Cos(.08),im=Math.Sin(.08);for(int i=0;i<n;i++){double t=i/(double)Rate,cut=230+1800*Math.Exp(-t/.012),ratio=h*f/cut;harmonic[i]+=(float)(im/(h*Math.Sqrt(1+ratio*ratio*ratio*ratio)));double nr=re*c-im*s;im=im*c+re*s;re=nr;}}double[] x=new double[n];for(int i=0;i<n;i++)x[i]=Math.Tanh((harmonic[i]*.58f+.36*Math.Sin(Tau*f*i/Rate))*1.35)*Envelope(i,n,.0035,.14);return Filter(x,"highpass:29");}
 public static float[] Acid(int note,double duration,int index,int variant){int n=(int)(duration*Rate*2);double[] hi=new double[n];double f=Frequency(note),idx=1.2+variant*.24;for(int i=0;i<n;i++){double t=i/(Rate*2.0),e=Math.Min(1,t/.004)*Math.Exp(-t/.11);hi[i]=(Math.Sin(Tau*f*t+idx*Math.Sin(Tau*f*2*t)*Math.Exp(-t/.075))*.68+Math.Sin(Tau*f*1.003*t+.45)*.25)*e;}float[] down=new float[(n+1)/2];double[] fir=SynthCoefficients.Fir;for(int i=0;i<down.Length;i++){double sum=0;for(int k=0;k<fir.Length;k++){int at=i*2+k-20;if(at>=0&&at<n)sum+=hi[at]*fir[k];}down[i]=(float)sum;}int hz=650+((index*17+variant*9)%11)*210;float[] bp=Filter(down,"acid:"+hz),lp=Filter(down,"lowpass:7000");for(int i=0;i<down.Length;i++){double value=lp[i]+bp[i]*.8;if(i>=down.Length-220)value*=(down.Length-1-i)/219.0;down[i]=(float)Math.Tanh(value*1.5);}return down;}
 public static float[] Lead(int note,double duration,int index,int style){
  int family=style,n=(int)(duration*Rate*2);double[] hi=new double[n];double f=Frequency(note),tone=.85+(style/6)*.18;
  for(int i=0;i<n;i++){double t=i/(Rate*2.0),env=Math.Min(1,t/.004)*Math.Exp(-t/(family==6?.065:family==2||family==7?.16:.115)),p=Tau*f*t,value;
   if(family==0)value=Math.Sin(p+(2.5+index*.04)*Math.Sin(p*2)*Math.Exp(-t/.045))*.65+Math.Sin(p*1.006)*.2;
   else if(family==1)value=(Math.Sin(p*.996)+Math.Sin(p*1.004+.4)+Math.Sin(p*1.008+.8))*.25+Math.Sin(p*2)*.15;
   else if(family==2)value=Math.Sin(p+2.1*Math.Sin(p*3)*Math.Exp(-t/.09))*.7+Math.Sin(p*2.001)*.18;
   else if(family==3)value=Math.Sin(p+3*Math.Sin(p*.5))*Math.Sin(Tau*(650+index*35)*t)*.55+Math.Sin(p)*.25;
   else if(family==4)value=Math.Sin(p+2*Math.Sin(p*2+Math.Sin(Tau*11*t)))*.68+Math.Sin(p*2.004)*.14;
   else if(family==5)value=Math.Sin(p+1.3*Math.Sin(p*3.01)*Math.Exp(-t/.07))*.6+Math.Sin(p*2)*.24;
   else if(family==6)value=(Math.Sin(p)+Math.Sin(p*2)*.32+Math.Sin(p*3)*.12)*.6;
   else if(family==7)value=Math.Sin(p+Math.Sin(p*2)*1.5)*.45+Math.Sin(p*2.002+Math.Sin(p*4)*.65)*.35;
   else if(family==8)value=Math.Sin(p+2.6*Math.Sin(p*2)*Math.Exp(-t/.12))*.6+Math.Sin(p*1.002+.7)*.2;
   else value=(Math.Sin(p*.997+Math.Sin(p*2)*.9)+Math.Sin(p*1.003+.8+Math.Sin(p*3)*.8))*.38;
   hi[i]=value*env*tone;
  }
  float[] down=new float[(n+1)/2];double[] fir=SynthCoefficients.Fir;for(int i=0;i<down.Length;i++){double sum=0;for(int k=0;k<fir.Length;k++){int at=i*2+k-20;if(at>=0&&at<n)sum+=hi[at]*fir[k];}down[i]=(float)sum;}
  float[] bp=Filter(down,"acid:"+(650+((index*13+style*7)%11)*210)),lp=Filter(down,"lowpass:7000");for(int i=0;i<down.Length;i++){double value=lp[i]+bp[i]*(family==0||family==4?.8:.35);if(i>=down.Length-220)value*=(down.Length-1-i)/219.0;down[i]=(float)Math.Tanh(value*1.35);}return down;
 }
 public static float[] Percussion(SynthRandom rng,string kind){
  double seconds=kind=="closed"?.07:kind=="open"?.25:kind=="clap"?.19:kind=="shaker"?.095:.2;int n=(int)(seconds*Rate);float[] noise=new float[n];for(int i=0;i<n;i++)noise[i]=(float)rng.Normal();
  if(kind=="tom"){double phase=0;for(int i=0;i<n;i++){phase+=Tau*(95+110*Math.Exp(-i/(Rate*.04)))/Rate;noise[i]=(float)(Math.Sin(phase)*Envelope(i,n,.001,.06)*.7);}return noise;}
  float[] result=new float[n];
  if(kind=="clap"){
   // Snare: pitched membrane plus restrained, filtered wires; no stacked noise bursts.
   float[] wires=Filter(Filter(noise,"highpass:1800"),"lowpass:7500");double phase=0;for(int i=0;i<n;i++){double time=i/(double)Rate;phase+=Tau*(178+40*Math.Exp(-time/.012))/Rate;double body=(Math.Sin(phase)*.68+Math.Sin(Tau*331*time)*.18)*Envelope(i,n,.0015,.042);double wire=wires[i]*.23*Envelope(i,n,.003,.033);result[i]=(float)(body+wire);}NormalizePercussion(result,.64f);return result;
  }
  bool hat=kind=="closed"||kind=="open";float[] air=Filter(Filter(noise,hat?"highpass:6500":"highpass:2500"),"lowpass:9000");double decay=kind=="closed"?.017:kind=="open"?.052:.024;
  for(int i=0;i<n;i++){double time=i/(double)Rate,metal=0;if(hat){metal=(Math.Sin(Tau*3821*time)+Math.Sin(Tau*5179*time+.3)+Math.Sin(Tau*6473*time+.8)+Math.Sin(Tau*8123*time+1.4)+Math.Sin(Tau*10213*time+2.1))*.09;}
   result[i]=(float)((metal+air[i]*(hat?.10:.22))*Envelope(i,n,.0012,decay));}
  NormalizePercussion(result,kind=="closed"?.36f:kind=="open"?.42f:.28f);return result;
 }
 static void NormalizePercussion(float[] voice,float peak){float max=0;foreach(float sample in voice)max=Math.Max(max,Math.Abs(sample));if(max>0)for(int i=0;i<voice.Length;i++)voice[i]*=peak/max;}
 public static float[][] Pad(int key,int variant,int section,double duration){int n=(int)(duration*Rate),root=key+24+new[]{0,0,3,0,7,0,3,0}[section];float[][] x={new float[n],new float[n]};foreach(int note in new[]{root,root+7,root+15})for(int side=0;side<2;side++){double f=Frequency(note)*(side==0?.9985:1.0015);float[] saw=new float[n];int hs=Math.Min(64,(int)(1800/f));for(int h=1;h<=hs;h++){double angle=Tau*f*h/Rate,c=Math.Cos(angle),s=Math.Sin(angle),re=1,im=0;for(int i=0;i<n;i++){saw[i]+=(float)im/h;double nr=re*c-im*s;im=im*c+re*s;re=nr;}}for(int i=0;i<n;i++)x[side][i]+=saw[i]*(float)(2/Math.PI)*.06f;}
 for(int side=0;side<2;side++){for(int i=0;i<n;i++){double t=i/(double)Rate;x[side][i]=(float)(x[side][i]*Math.Pow(Math.Sin(Math.PI*Math.Min(1,t/duration)),1.4)*(.5+.12*Math.Sin(Tau*.13*t)));}x[side]=Filter(x[side],"lowpass:"+(1200+variant*250));}return x;}
 public static void Add(float[][] bus,float[] voice,double start,double gain,double pan){int n=bus[0].Length,at=(int)Math.Round(start*Rate);float g=(float)gain,l=(float)Math.Sqrt((1-pan)/2),r=(float)Math.Sqrt((1+pan)/2);for(int i=0;i<voice.Length&&at<n;i++){float v=voice[i]*g;bus[0][at]+=v*l;bus[1][at]+=v*r;at++;}}
 public static void Add(float[][] bus,float[][] voice,double start,double gain){int n=bus[0].Length,at=(int)Math.Round(start*Rate);for(int i=0;i<voice[0].Length&&at<n;i++){bus[0][at]+=voice[0][i]*(float)gain;bus[1][at]+=voice[1][i]*(float)gain;at++;}}
}
// Overlap-add convolution; both stereo channels share each complex FFT.
sealed class StereoConvolver {
 const int N=131072,Hop=65536;readonly double[] cos=new double[N/2],sin=new double[N/2];readonly int[] rev=new int[N];
 public StereoConvolver(){for(int i=0;i<N/2;i++){cos[i]=Math.Cos(SynthDsp.Tau*i/N);sin[i]=Math.Sin(SynthDsp.Tau*i/N);}for(int i=1,j=0;i<N;i++){int bit=N>>1;while((j&bit)!=0){j^=bit;bit>>=1;}j^=bit;rev[i]=j;}}
 void Fft(double[] re,double[] im,bool inverse){for(int i=0;i<N;i++){int j=rev[i];if(j>i){double t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;}}for(int len=2;len<=N;len<<=1){int half=len>>1,step=N/len;for(int at=0;at<N;at+=len)for(int j=0,k=0;j<half;j++,k+=step){double c=cos[k],s=inverse?sin[k]:-sin[k];int a=at+j,b=a+half;double r=re[b]*c-im[b]*s,t=re[b]*s+im[b]*c;re[b]=re[a]-r;im[b]=im[a]-t;re[a]+=r;im[a]+=t;}}if(inverse)for(int i=0;i<N;i++){re[i]/=N;im[i]/=N;}}
 public float[][] Process(float[][] source,float[][] impulse,Action<string> progress){int n=source[0].Length;double[] hr=new double[N],hi=new double[N];for(int i=0;i<impulse[0].Length;i++){hr[i]=impulse[0][i];hi[i]=impulse[1][i];}Fft(hr,hi,false);double[] lr=new double[N],li=new double[N],rr=new double[N],ri=new double[N];for(int k=0;k<N;k++){int neg=(N-k)%N;lr[k]=(hr[k]+hr[neg])*.5;li[k]=(hi[k]-hi[neg])*.5;rr[k]=(hi[k]+hi[neg])*.5;ri[k]=(hr[neg]-hr[k])*.5;}double[] re=new double[N],im=new double[N];float[][] result={new float[n],new float[n]};for(int at=0;at<n;at+=Hop){if(progress!=null&&(at/Hop)%8==0)progress("Pogłos stereo — "+(at*100L/n)+"%");Array.Clear(re,0,N);Array.Clear(im,0,N);int count=Math.Min(Hop,n-at);for(int i=0;i<count;i++){re[i]=source[0][at+i];im[i]=source[1][at+i];}Fft(re,im,false);for(int k=0;k<=N/2;k++){int neg=(N-k)%N;double ar=re[k],ai=im[k],br=re[neg],bi=im[neg];Multiply(re,im,k,ar,ai,br,bi,lr,li,rr,ri);if(neg!=k)Multiply(re,im,neg,br,bi,ar,ai,lr,li,rr,ri);}Fft(re,im,true);int length=count+impulse[0].Length-1;for(int i=0,pos=at;i<length;i++){if(pos>=n)break;result[0][pos]+=(float)re[i];result[1][pos]+=(float)im[i];pos++;}}return result;}
 static void Multiply(double[] re,double[] im,int k,double ar,double ai,double br,double bi,double[] lr,double[] li,double[] rr,double[] ri){double lre=(ar+br)*.5,lim=(ai-bi)*.5,rre=(ai+bi)*.5,rim=(br-ar)*.5;double leftR=lre*lr[k]-lim*li[k],leftI=lre*li[k]+lim*lr[k],rightR=rre*rr[k]-rim*ri[k],rightI=rre*ri[k]+rim*rr[k];re[k]=leftR-rightI;im[k]=leftI+rightR;}
}}
