using System;
namespace Asteroidy {
// Offline sound design: the music engine's PCG noise, FIR oversampling,
// filters, kick synthesis and stereo FFT convolution feed a cached SFX bank.
static class CombatSound {
 public const int Pickup=30;
 public static int Shot(Weapon w){return 10+(int)w;}
 public static int Blast(int size){return 20+Math.Max(0,Math.Min(2,size));}
 static readonly short[][][] bank=new short[9][][];
 static StereoConvolver convolver;
 public static short[] Get(int code,int variant){
  if(code==60)return BossAlarm86.Get();
  if(code>=40&&code<=45)return EnemySounds79.Get(code-40,variant);
  if(code>=50&&code<=57)return PickupVoice79.Get(code-50);
  int key=code==1?0:code==2?5:code>=10&&code<=14?code-10:code>=20&&code<=22?5+code-20:8;lock(bank){if(bank[key]==null){bank[key]=new short[3][];for(int i=0;i<3;i++)bank[key][i]=Build(key,i);}return bank[key][(variant&int.MaxValue)%3];}}
 public static void Prepare(Action<int> progress=null){for(int k=0;k<9;k++){if(progress!=null)progress(k);Get(k<5?10+k:k<8?20+k-5:30,0);}}
 static double Attack(double t,double seconds){return 1-Math.Exp(-t/seconds);}
 static float[] Downsample(double[] hi){float[] p=new float[hi.Length/2];double[] fir=SynthCoefficients.Fir;for(int i=0;i<p.Length;i++){double value=0;for(int k=0;k<fir.Length;k++){int at=i*2+k-20;if(at>=0&&at<hi.Length)value+=hi[at]*fir[k];}p[i]=(float)value;}return SynthDsp.Filter(SynthDsp.Filter(p,"highpass:29"),"lowpass:9000");}
 static float[] ShotBody(int kind,int variation,SynthRandom rng){const int rate=88200;double duration=kind==3?.48:kind==4?.36:.30;double[] hi=new double[(int)(duration*rate)];double phase=0,sub=0,low=0;double tune=1+(variation-1)*.018;
 for(int i=0;i<hi.Length;i++){double t=i/(double)rate;double start=kind==3?1900:kind==2?870:kind==4?1180:1460,finish=kind==3?95:kind==2?160:kind==4?235:210;double sweep=kind==3?.052:kind==2?.028:.022;double freq=(finish+(start-finish)*Math.Exp(-t/sweep))*tune;phase+=SynthDsp.Tau*freq/rate;sub+=SynthDsp.Tau*(kind==3?61:kind==2?94:115)/rate;double n=rng.Normal()*.5;low+=.16*(n-low);
 double index=(kind==3?3.8:kind==2?2.7:1.9)*Math.Exp(-t/.039),laser=Math.Sin(phase+index*Math.Sin(phase*1.51));double sheen=Math.Sin(phase*1.007+.25+index*.65*Math.Sin(phase*2.03));double env=Attack(t,.0006)*Math.Exp(-t/(kind==3?.095:kind==4?.059:.047));double body=Math.Sin(sub+.4*Math.Sin(sub*2))*Attack(t,.0012)*Math.Exp(-t/(kind==3?.088:.034));double spark=(n-low)*Math.Exp(-t/.0028)*.11;
 double value=(laser*.63+sheen*.21)*env+body*.22+spark;if(kind==2)value+=Math.Sin(phase*.989+index*Math.Sin(phase*1.83))*env*.19;if(kind==4)value*=.85+.15*Math.Sin(SynthDsp.Tau*41*t);hi[i]=Math.Tanh(value*1.25);
 }
 float[] pcm=Downsample(hi);for(int i=pcm.Length-882;i<pcm.Length;i++)pcm[i]*=(pcm.Length-1-i)/881f;return pcm;
 }
 static float[] ExplosionBody(int kind,int variation,SynthRandom rng){int size=kind-5;double duration=.62+size*.35;double[] hi=new double[(int)(duration*88200)];double deep=0,low=0,wide=0,phase=0;double[] when=new double[9],weight=new double[9];for(int g=0;g<9;g++){when[g]=.045+rng.Uniform()*(.20+size*.15);weight[g]=.18+rng.Uniform()*.25;}
 for(int i=0;i<hi.Length;i++){double t=i/88200.0,n=rng.Normal()*.5;deep+=.003*(n-deep);low+=.035*(n-low);double cut=900+5400*Math.Exp(-t/(.05+size*.055)),alpha=1-Math.Exp(-SynthDsp.Tau*cut/88200);wide+=alpha*(n-wide);phase+=SynthDsp.Tau*(39+size*2+80*Math.Exp(-t/.009))/88200;
 double pressure=Math.Sin(phase+5*deep)*Math.Exp(-t/(.12+size*.09))*.45;double eruption=(wide-low)*Math.Exp(-t/(.045+size*.055))*1.9;double rubble=low*Math.Exp(-t/(.19+size*.13))*4.6;double dust=(wide-low)*Math.Exp(-t/(.17+size*.09))*.35;
 double cracks=0;for(int g=0;g<9;g++){double dt=t-when[g];if(dt>=0)cracks+=(wide-low)*Math.Exp(-dt/(.007+size*.004))*weight[g];}
 hi[i]=Math.Tanh((pressure+eruption+rubble+dust+cracks)*1.65)*Attack(t,.00016);
 }
 float[] result=Downsample(hi);for(int i=result.Length-882;i<result.Length;i++)result[i]*=(result.Length-1-i)/881f;return result;
 }
 static float[][] Room(SynthRandom rng,double duration,bool large){int n=(int)(duration*SynthDsp.Rate);float[][] impulse={new float[n],new float[n]};for(int side=0;side<2;side++){double smooth=0;for(int i=0;i<n;i++){double t=i/(double)SynthDsp.Rate;smooth+=.19*(rng.Normal()-smooth);double buildup=Math.Min(1,Math.Max(0,(t-.018)/.025));impulse[side][i]=(float)(smooth*Math.Exp(-t/(large?.19:.036))*buildup*(large?.012:.017));}
 double[] taps=large?new[]{.019,.037,.061,.089}:new[]{.011,.022,.035};for(int k=0;k<taps.Length;k++){int at=(int)((taps[k]+side*.003)*SynthDsp.Rate);if(at<n)impulse[side][at]+=(float)(.16*Math.Pow(.62,k));}impulse[side]=SynthDsp.Filter(impulse[side],"highpass:900");}return impulse;}
 static short[] Build(int kind,int variation){SynthRandom rng=new SynthRandom(kind%5);for(int i=0;i<173+variation*137+kind*47;i++)rng.Uniform();bool blast=kind>=5&&kind<=7;float[] mono;
 if(kind<5)mono=ShotBody(kind,variation,rng);else if(blast)mono=ExplosionBody(kind,variation,rng);else{mono=new float[7056];for(int i=0;i<mono.Length;i++){double t=i/(double)SynthDsp.Rate,f=((1320*Math.Min(t,.045)+1760*Math.Max(0,t-.045))/Math.Max(t,.000001))*(1+(variation-1)*.012);mono[i]=(float)((Math.Sin(SynthDsp.Tau*f*t)+.3*Math.Sin(SynthDsp.Tau*f*1.5*t))*Attack(t,.002)*Math.Exp(-t/.055)*.32);}}
 double roomSeconds=blast?.42+(kind-5)*.28:kind==8?.08:.38;int n=mono.Length+(int)(roomSeconds*SynthDsp.Rate)+1024;float[][] dry={new float[n],new float[n]};for(int i=0;i<mono.Length;i++){dry[0][i]+=mono[i];dry[1][i]+=mono[i];if(kind==1){int at=i+529;if(at<n){dry[0][at]+=mono[i]*.68f;dry[1][at]+=mono[i]*.88f;}}}
 if(kind<5){int[] echo={2999,6174,9702};for(int k=0;k<echo.Length;k++)for(int i=0;i<mono.Length&&i+echo[k]<n;i++){float echoGain=(float)(.23*Math.Pow(.54,k));dry[k%2][i+echo[k]]+=mono[i]*echoGain;dry[1-k%2][i+echo[k]]+=mono[i]*echoGain*.25f;}}
 float[][] wet=null;if(kind!=8){if(convolver==null)convolver=new StereoConvolver();wet=convolver.Process(dry,Room(rng,roomSeconds,blast),null);}
 double peak=0;for(int i=0;i<n;i++)for(int side=0;side<2;side++){double value=dry[side][i]+(wet==null?0:wet[side][i]*(blast?.72:.4));dry[side][i]=(float)Math.Tanh(value*.94);peak=Math.Max(peak,Math.Abs(dry[side][i]));}
 short[] pcm=new short[n*2];double gain=(kind==8?.48:.84)/Math.Max(.001,peak);for(int i=0;i<n;i++){double edge=Math.Min(1,i/20.0)*Math.Min(1,(n-1-i)/880.0);for(int side=0;side<2;side++)pcm[i*2+side]=(short)(dry[side][i]*gain*edge*32767);}return pcm;
 }
}
}
