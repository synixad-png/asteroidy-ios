using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
namespace Asteroidy {
 // Independently synthesized, cached hostile gun sounds. All 6 armed ship
 // types have a distinct pulse; one sound is scheduled per volley, not per bolt.
 internal static class EnemySounds79 {
  static readonly short[][] bank=new short[6][];
  internal static short[] Get(int type,int variant){type=Math.Max(0,Math.Min(5,type));lock(bank){if(bank[type]==null)bank[type]=Build(type);return bank[type];}}
  static short[] Build(int type){
   const int rate=44100;double duration=.135+type*.019;
   int frames=(int)(rate*duration);short[] pcm=new short[frames*2];
   double phase=0,sub=0,noiseLP=0;uint seed=unchecked((uint)(93241+7193*type));
   double start=1100+type*188,finish=195+type*53;
   for(int i=0;i<frames;i++){
    double t=i/(double)rate,env=(1-Math.Exp(-t/.0012))*Math.Exp(-t/(.028+type*.005));
    double frequency=finish+(start-finish)*Math.Exp(-t/(.020+type*.003));
    phase+=Math.PI*2*frequency/rate;sub+=Math.PI*2*(85+type*17)/rate;
    seed=unchecked(seed*1664525u+1013904223u);
    double n=((seed>>8)/8388608.0)-1;noiseLP+=(n-noiseLP)*.085;
    double value=(Math.Sin(phase+Math.Sin(phase*1.4)*(1.1+type*.13))*.58+
      Math.Sin(phase*.503)*.22+Math.Sin(sub)*.13+(n-noiseLP)*.12)*env;
    double fade=Math.Min(1,Math.Max(0,(duration-t)/.020));value=Math.Tanh(value*1.4)*fade;
    short s=(short)(Math.Max(-.98,Math.Min(.98,value))*32767);
    pcm[i*2]=s;pcm[i*2+1]=s;
   }
   return pcm;
  }
 }
 // Pre-rendered offline Polish announcements. No online TTS service or runtime
 // speech engine is required on Windows or SteamOS.
 internal static class PickupVoice79 {
  static readonly short[][] bank=new short[8][];
  internal static short[] Get(int kind){
   if(kind<0||kind>7||kind==5)return new short[0];
   lock(bank){
    if(bank[kind]!=null)return bank[kind];
    string name="Voice79.Pickup"+kind;
    using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream(name)){
     if(stream==null)throw new InvalidOperationException("Missing Polish voice asset: "+name);
     byte[] pcm;
     using(GZipStream gz=new GZipStream(stream,CompressionMode.Decompress))
     using(MemoryStream result=new MemoryStream()){
      gz.CopyTo(result);pcm=result.ToArray();
     }
     if(pcm.Length%4!=0||pcm.Length<4||pcm.Length>4000000)throw new InvalidDataException("Corrupt voice asset "+name);
     short[] samples=new short[pcm.Length/2];
     for(int i=0;i<samples.Length;i++)samples[i]=(short)(pcm[i*2]|pcm[i*2+1]<<8);
     bank[kind]=samples;
    }
    return bank[kind];
   }
  }
 }
}
