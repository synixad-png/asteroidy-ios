using System;
namespace Asteroidy {
// Linear stereo mastering. A waveform-derived gain table is not an envelope:
// applying it to another arrangement causes sample-rate amplitude modulation.
static class MusicMaster {
 public const float Ceiling=.88f,TargetRms=.145f;
 public static short[] Render(float[][] bus,int rate){
  if(bus==null||bus.Length!=2||bus[0]==null||bus[1]==null||bus[0].Length!=bus[1].Length||bus[0].Length<2||rate<=0)throw new ArgumentException("Nieprawidłowy bufor masteringu");
  int n=bus[0].Length;double energy=0,peak=0;
  for(int i=0;i<n;i++){
   double intro=Math.Min(1,i/(rate*2.5)),outro=Math.Min(1,(n-1-i)/(rate*7.0));
   double edge=Math.Sin(intro*Math.PI/2)*Math.Sin(outro*Math.PI/2);
   for(int side=0;side<2;side++){
    double value=bus[side][i]*edge;
    if(double.IsNaN(value)||double.IsInfinity(value))throw new InvalidOperationException("Niefinitywna próbka syntezatora");
    bus[side][i]=(float)value;energy+=value*value;peak=Math.Max(peak,Math.Abs(value));
   }
  }
  double rms=Math.Sqrt(energy/(n*2.0));
  // One gain for both channels and the whole song: no clipping, pumping,
  // phase distortion, rapid limiter gain steps or quantised gain modulation.
  double gain=peak==0?0:Math.Min(Ceiling/peak,TargetRms/Math.Max(rms,1e-12));
  short[] pcm=new short[n*2];
  for(int i=0;i<n;i++)for(int side=0;side<2;side++)pcm[i*2+side]=(short)Math.Round(bus[side][i]*gain*32768);
  pcm[0]=pcm[1]=pcm[pcm.Length-1]=pcm[pcm.Length-2]=0;
  return pcm;
 }
}
}
