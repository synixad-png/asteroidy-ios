using System;using System.IO;
namespace Asteroidy {
 // Original sixteen-second score: pulsing bass, modulated lead, dark pads and echoes
 // and a slowly opening noise veil. Rendered at build time, embedded in the game.
 internal static class IntroMusic43 {
  internal const int Track=15,Rate=44100,Frames=Rate*16;
  internal static short[] Generate(){
   double[][] bus={new double[Frames],new double[Frames]};uint seed=43017;double noise=0;
   double[] notes={110,164.813778,207.652349,246.941651};
   for(int i=0;i<Frames;i++){
    double t=i/(double)Rate;seed=unchecked(seed*1664525+1013904223);
    noise+=(((seed>>8)/8388608.0-1)-noise)*.012;
    double lift=.30+.70*Math.Pow(Math.Sin(Math.PI*t/16),2);
    // 78 BPM: rounded pulses without a kick or sharp transients.
    double beat=t*1.3,beatPhase=beat-Math.Floor(beat);
    double bassEnvelope=.24+.76*Math.Pow(.5-.5*Math.Cos(2*Math.PI*beatPhase),2);
    double bassColour=.20+.12*Math.Sin(2*Math.PI*.18*t);
    double rumble=bassEnvelope*(.125*Math.Sin(2*Math.PI*55*t)
     +.125*bassColour*Math.Sin(2*Math.PI*110*t)+.012*Math.Sin(2*Math.PI*165*t));
    for(int side=0;side<2;side++){
     double pad=0;for(int n=0;n<notes.Length;n++){
      double f=notes[n]*(side==0?.9991:1.0009),phase=2*Math.PI*f*t+.22*Math.Sin(t*.6+n);
      pad+=(Math.Sin(phase)+.22*Math.Sin(phase*2+.6*Math.Sin(t*.23+n)))*(.034-n*.004);
     }
     double breath=.028*noise*(.45+.55*Math.Pow(Math.Sin(t*.55+side*.7),2));
     bus[side][i]=(pad+rumble+breath)*lift;
    }
   }
   // Sparse A-minor phrase. Slow FM colour, vibrato and stereo delays.
   double[] leadStarts={1.05,3.35,5.85,8.45,10.85,13.05};
   double[] leadNotes={329.627557,391.995436,440,349.228231,329.627557,293.664768};
   for(int note=0;note<leadStarts.Length;note++)for(int echo=0;echo<4;echo++){
    int start=(int)((leadStarts[note]+echo*.46)*Rate);
    double decay=Math.Pow(.38,echo),phase=0;
    for(int i=0;i<Rate*3&&start+i<Frames;i++){
     double t=i/(double)Rate,absolute=leadStarts[note]+t;
     double frequency=leadNotes[note]*(1+.0018*Math.Sin(2*Math.PI*4.1*t));
     phase+=2*Math.PI*frequency/Rate;
     double colour=.28+.45*(.5+.5*Math.Sin(2*Math.PI*.32*absolute+note*.7));
     double env=(1-Math.Exp(-t*5))*Math.Exp(-t*1.25);
     double tone=(Math.Sin(phase+colour*Math.Sin(phase*2))
      +.12*colour*Math.Sin(phase*3))*env*.105*decay;
     double pan=.35*Math.Sin(absolute*.65+note)+(echo%2==0?-.18:.18);
     bus[0][start+i]+=tone*Math.Sqrt((1-pan)*.5);
     bus[1][start+i]+=tone*Math.Sqrt((1+pan)*.5);
    }
   }
   double[] starts={.65,2.55,4.65,7.15,10.45,12.95};
   double[] bells={659.255114,622.253967,440,830.609395,493.883301,659.255114};
   for(int note=0;note<starts.Length;note++)for(int echo=0;echo<5;echo++){
    int start=(int)((starts[note]+echo*.37)*Rate);double decay=Math.Pow(.43,echo),pan=(note%2==0?-.6:.6)*(echo%2==0?1:-1);
    for(int i=0;i<Rate*3&&start+i<Frames;i++){
     double t=i/(double)Rate,f=bells[note],env=(1-Math.Exp(-t*35))*Math.Exp(-t*1.7);
     double tone=(Math.Sin(2*Math.PI*f*t+.45*Math.Sin(2*Math.PI*f*2.01*t))*Math.Exp(-t*.4)+.20*Math.Sin(2*Math.PI*f*2.73*t))*env*.035*decay;
     bus[0][start+i]+=tone*Math.Sqrt((1-pan)*.5);bus[1][start+i]+=tone*Math.Sqrt((1+pan)*.5);
    }
   }
   double energy=0,peak=0;
   for(int i=0;i<Frames;i++){
    double t=i/(double)Rate,attack=Math.Min(1,t/.55),release=Math.Min(1,(16-t)/2.0);
    double envelope=Math.Pow(Math.Sin(attack*Math.PI*.5)*Math.Sin(release*Math.PI*.5),2);
    for(int side=0;side<2;side++){bus[side][i]*=envelope;energy+=bus[side][i]*bus[side][i];peak=Math.Max(peak,Math.Abs(bus[side][i]));}
   }
   double gain=Math.Min(.80/peak,.14/Math.Sqrt(energy/(Frames*2)));short[] pcm=new short[Frames*2];
   for(int i=0;i<Frames;i++)for(int side=0;side<2;side++)pcm[i*2+side]=(short)Math.Round(bus[side][i]*gain*32767);
   pcm[0]=pcm[1]=pcm[pcm.Length-2]=pcm[pcm.Length-1]=0;return pcm;
  }
  internal static void WritePcm(string path,short[] pcm){byte[] bytes=new byte[pcm.Length*2];Buffer.BlockCopy(pcm,0,bytes,0,bytes.Length);File.WriteAllBytes(path,bytes);}
  internal static void WriteWav(string path,short[] pcm){using(BinaryWriter w=new BinaryWriter(File.Create(path))){w.Write(new byte[]{82,73,70,70});w.Write(36+pcm.Length*2);w.Write(new byte[]{87,65,86,69,102,109,116,32});w.Write(16);w.Write((short)1);w.Write((short)2);w.Write(Rate);w.Write(Rate*4);w.Write((short)4);w.Write((short)16);w.Write(new byte[]{100,97,116,97});w.Write(pcm.Length*2);foreach(short sample in pcm)w.Write(sample);}}
 }
}
