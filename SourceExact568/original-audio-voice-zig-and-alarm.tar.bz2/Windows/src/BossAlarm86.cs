using System;
namespace Asteroidy {
 // Prebuilt offline synthesized warning, low-frequency rumble + alternating radar tones.
 internal static class BossAlarm86 {
  static short[] buffer;
  internal static short[] Get(){if(buffer!=null)return buffer;const int rate=44100;const double length=2.1;int frames=(int)(rate*length);short[] pcm=new short[frames*2];double ph=0,rumble=0;uint seed=532857u;
   for(int i=0;i<frames;i++){
    double t=i/(double)rate,fade=Math.Min(1,t/.03)*Math.Min(1,(length-t)/.20),env=.55+.45*Math.Sin(2*Math.PI*1.6*t);
    double freq=430+155*Math.Sin(2*Math.PI*.80*t);ph+=2*Math.PI*freq/rate;rumble+=2*Math.PI*52/rate;
    seed=unchecked(seed*1664525u+1013904223u);double noise=((seed>>9)/4194304.0)-1;
    double v=fade*(Math.Sin(ph)*.27*env+Math.Sin(rumble)*.12+.038*noise);
    v=Math.Tanh(v*1.45);short q=(short)(Math.Max(-.8,Math.Min(.8,v))*32767);pcm[i*2]=pcm[i*2+1]=q;
   }buffer=pcm;return buffer;
  }
 }
}
